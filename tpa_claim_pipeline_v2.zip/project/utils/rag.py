"""
utils/rag.py
------------
Query a Vertex AI RAG Corpus using vertexai.preview.rag.

Replaces the Discovery Engine backend. Uses the ragCorpora resource name
directly, e.g.:
  projects/my-project/locations/us-central1/ragCorpora/1234567890
"""

from __future__ import annotations

import vertexai
from vertexai.preview import rag
from vertexai.preview.generative_models import GenerativeModel, Tool

# ── Module-level state ────────────────────────────────────────────────────────

_rag_initialised = False


def _ensure_init(project_id: str, location: str) -> None:
    """Initialise Vertex AI SDK once (idempotent)."""
    global _rag_initialised
    if not _rag_initialised:
        vertexai.init(project=project_id, location=location)
        _rag_initialised = True


# ── Public API ────────────────────────────────────────────────────────────────

def query_rag_datastore(
    query: str,
    project_id: str,
    location: str,
    datastore_id: str,          # accepted for API compatibility; ignored here
    rag_corpus_resource: str = "",
    max_results: int = 5,
    vector_distance_threshold: float = 0.5,
) -> str:
    """
    Retrieve relevant chunks from a Vertex AI RAG Corpus.

    Parameters
    ----------
    query : str
        Natural-language question / search string.
    project_id : str
        GCP project ID.
    location : str
        Region where the corpus lives, e.g. 'us-central1'.
    datastore_id : str
        Ignored (kept for interface compatibility with the rest of the code).
    rag_corpus_resource : str
        Full resource name of the RAG corpus, e.g.
        'projects/my-proj/locations/us-central1/ragCorpora/123456789'
    max_results : int
        Maximum number of chunks to retrieve (1-20).
    vector_distance_threshold : float
        Similarity threshold; lower = stricter (0.0-1.0).

    Returns
    -------
    str
        Concatenated text chunks from the corpus.
        Returns empty string on error or no results.
    """
    if not rag_corpus_resource:
        print("[RAG] Warning – rag_corpus_resource is empty; skipping retrieval.")
        return ""

    try:
        _ensure_init(project_id, location)

        # Build the retrieval config pointing at the corpus
        rag_resource = rag.RagResource(rag_corpus=rag_corpus_resource)

        retrieval_config = rag.RagRetrievalConfig(
            top_k=max(1, min(max_results, 20)),
            filter=rag.utils.resources.Filter(
                vector_distance_threshold=vector_distance_threshold
            ),
        )

        # Execute retrieval
        response = rag.retrieval_query(
            rag_resources=[rag_resource],
            text=query,
            rag_retrieval_config=retrieval_config,
        )

        # Extract text from retrieved contexts
        snippets: list[str] = []
        for i, ctx in enumerate(response.contexts.contexts):
            text = (ctx.text or "").strip()
            if text:
                source = ctx.source_uri or f"chunk-{i+1}"
                snippets.append(f"[Chunk {i+1} | source: {source}]\n{text}")

        combined = "\n\n".join(snippets)
        print(f"[RAG] Query='{query[:60]}…' → {len(snippets)} chunk(s) retrieved")
        return combined

    except Exception as exc:
        print(f"[RAG] Warning – RAG corpus query failed: {exc}")
        return ""
