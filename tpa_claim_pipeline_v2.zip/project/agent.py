"""
agent.py  (Orchestrator)
------------------------
Main pipeline entry point for the Multi-Agent Medical Insurance TPA Claim
Processing System.

Pipeline flow
-------------
1.  Read all PDFs from GCS folder
2.  Extract text from each PDF
3.  Merge text → single corpus
4.  extractor_agent   → structured claim data
5.  classifier_agent  → claim type (cashless / reimbursement)
6.  validator_agent   → document completeness check
7.  (If incomplete)   → return early with validation result
8.  medical_agent     → policy, clinical, fraud checks (RAG-powered)
9.  decision_agent    → approval / rejection + approved amount
10. report_agent      → consolidated report
11. Save report JSON to GCS
"""

import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import PurePosixPath

# ── Add project root to path (needed when running from Jupyter) ───────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── Utilities ─────────────────────────────────────────────────────────────────
from utils.llm import init_llm
from utils.gcs import list_pdfs, download_blob_to_bytes, upload_json
from utils.pdf_loader import extract_text_from_bytes, merge_texts

# ── Agents ────────────────────────────────────────────────────────────────────
from agents import extractor, classifier, validator, medical, decision, report


# ── Helper ────────────────────────────────────────────────────────────────────

def _derive_claim_id(gcs_folder_uri: str) -> str:
    """
    Derive a stable claim ID from the GCS folder path.
    Falls back to a UUID if the folder name is empty.

    Examples
    --------
    gs://bucket/claims/CLAIM-001/  →  CLAIM-001
    gs://bucket/claims/            →  <uuid>
    """
    parts = gcs_folder_uri.rstrip("/").split("/")
    folder_name = parts[-1] if parts[-1] else parts[-2] if len(parts) > 1 else ""
    return folder_name if folder_name else str(uuid.uuid4())


def _build_output_uri(gcs_folder_uri: str, claim_id: str) -> str:
    """
    Derive the GCS output URI for the report.

    Pattern: gs://<bucket>/output/<claim_id>/report.json
    """
    bucket = gcs_folder_uri[5:].split("/")[0]
    return f"gs://{bucket}/output/{claim_id}/report.json"


# ── Core pipeline ─────────────────────────────────────────────────────────────

def run_pipeline(
    gcs_folder_uri: str,
    project_id: str,
    location: str = "us-central1",
    rag_location: str = "us-central1",
    datastore_id: str = "",
    rag_corpus_resource: str = "",
    model_name: str = "gemini-2.0-flash-001",
    skip_incomplete: bool = True,
) -> dict:
    """
    Execute the end-to-end claim processing pipeline.

    Parameters
    ----------
    gcs_folder_uri : str
        GCS folder containing the claim PDFs, e.g.
        'gs://my-bucket/claims/CLAIM-001/'
    project_id : str
        GCP project ID.
    location : str
        Vertex AI region for Gemini, default 'us-central1'.
    rag_location : str
        Discovery Engine datastore location, e.g. 'global' or 'us'.
    datastore_id : str
        ID of the existing Vertex AI Search datastore.
    model_name : str
        Gemini model to use.
    skip_incomplete : bool
        If True, stop and return when the validator finds missing documents.

    Returns
    -------
    dict
        The final report dict (also saved to GCS).
    """
    run_ts = datetime.now(timezone.utc).isoformat()
    print(f"\n{'='*60}")
    print(f"  TPA Claim Processing Pipeline")
    print(f"  Started : {run_ts}")
    print(f"  Input   : {gcs_folder_uri}")
    print(f"  Project : {project_id}")
    print(f"{'='*60}\n")

    # ── 0. Initialise LLM ─────────────────────────────────────────────────────
    init_llm(project_id=project_id, location=location, model_name=model_name)

    claim_id = _derive_claim_id(gcs_folder_uri)
    print(f"[Orchestrator] Claim ID: {claim_id}\n")

    # ── 1. Discover PDFs ──────────────────────────────────────────────────────
    pdf_uris = list_pdfs(gcs_folder_uri)
    if not pdf_uris:
        raise FileNotFoundError(f"No PDFs found in: {gcs_folder_uri}")

    # ── 2. Download + extract text ────────────────────────────────────────────
    texts: list[str] = []
    for uri in pdf_uris:
        raw_bytes = download_blob_to_bytes(uri)
        text = extract_text_from_bytes(raw_bytes, source_label=uri)
        texts.append(text)

    # ── 3. Merge all PDF texts ────────────────────────────────────────────────
    combined_text = merge_texts(texts)

    # ── 4. Extractor Agent ────────────────────────────────────────────────────
    print("\n[Orchestrator] → Extractor Agent")
    extracted_data = extractor.run(combined_text)

    # ── 5. Classifier Agent ───────────────────────────────────────────────────
    print("\n[Orchestrator] → Classifier Agent")
    classifier_result = classifier.run(extracted_data, combined_text)
    claim_type = classifier_result["claim_type"]

    # ── 6. Validator Agent ────────────────────────────────────────────────────
    print("\n[Orchestrator] → Validator Agent")
    validation_result = validator.run(claim_type, combined_text)

    # ── 7. Early exit if incomplete ───────────────────────────────────────────
    if not validation_result["is_complete"] and skip_incomplete:
        print("\n[Orchestrator] ⚠  Incomplete documents — halting pipeline.")
        early_result = {
            "claim_id": claim_id,
            "claim_type": claim_type,
            "status": "incomplete",
            "validation_result": validation_result,
            "message": (
                "Claim processing halted: required documents are missing. "
                "Please resubmit with all required documents."
            ),
        }
        output_uri = _build_output_uri(gcs_folder_uri, claim_id)
        upload_json(early_result, output_uri)
        return early_result

    # ── 8. Medical Agent (RAG-powered) ────────────────────────────────────────
    print("\n[Orchestrator] → Medical Agent (RAG-powered)")
    rag_config = {
        "project_id": project_id,
        "location": rag_location,
        "datastore_id": datastore_id,
        "rag_corpus_resource": rag_corpus_resource,
    }
    medical_result = medical.run(extracted_data, rag_config)

    # ── 9. Decision Agent ─────────────────────────────────────────────────────
    print("\n[Orchestrator] → Decision Agent")
    decision_result = decision.run(
        claim_type=claim_type,
        extracted_data=extracted_data,
        validation_result=validation_result,
        medical_result=medical_result,
    )

    # ── 10. Report Agent ──────────────────────────────────────────────────────
    print("\n[Orchestrator] → Report Agent")
    final_report = report.run(
        claim_id=claim_id,
        claim_type=claim_type,
        extracted_data=extracted_data,
        validation_result=validation_result,
        medical_result=medical_result,
        decision_result=decision_result,
    )

    # Attach run metadata
    final_report["_meta"] = {
        "pipeline_run_at": run_ts,
        "source_folder": gcs_folder_uri,
        "pdf_count": len(pdf_uris),
        "model": model_name,
    }

    # ── 11. Save to GCS ───────────────────────────────────────────────────────
    output_uri = _build_output_uri(gcs_folder_uri, claim_id)
    upload_json(final_report, output_uri)

    print(f"\n{'='*60}")
    print(f"  Pipeline Complete")
    print(f"  Claim ID : {claim_id}")
    print(f"  Decision : {decision_result['status'].upper()}")
    print(f"  Approved : {decision_result['approved_amount']:,.2f}")
    print(f"  Report   : {output_uri}")
    print(f"{'='*60}\n")

    return final_report


# ── Convenience wrapper (for Jupyter) ─────────────────────────────────────────

def process_claim(
    gcs_folder_uri: str,
    project_id: str,
    rag_corpus_resource: str,
    location: str = "us-central1",
    rag_location: str = "us-central1",
    datastore_id: str = "",
    model_name: str = "gemini-2.0-flash-001",
) -> dict:
    """
    Simplified entry point for Jupyter notebooks.

    Example
    -------
    >>> from agent import process_claim
    >>> result = process_claim(
    ...     gcs_folder_uri      = "gs://my-bucket/claims/CLAIM-001/",
    ...     project_id          = "my-gcp-project",
    ...     rag_corpus_resource = "projects/my-gcp-project/locations/us-central1/ragCorpora/1234567890",
    ... )
    >>> print(result["final_decision"])
    """
    return run_pipeline(
        gcs_folder_uri=gcs_folder_uri,
        project_id=project_id,
        location=location,
        rag_location=rag_location,
        datastore_id=datastore_id,
        rag_corpus_resource=rag_corpus_resource,
        model_name=model_name,
    )


# ── CLI / direct execution ────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="TPA Medical Insurance Claim Processing Pipeline"
    )
    parser.add_argument("--gcs-folder", required=True,
                        help="GCS folder URI containing claim PDFs")
    parser.add_argument("--project-id", required=True,
                        help="GCP project ID")
    parser.add_argument("--datastore-id", required=True,
                        help="Vertex AI Search datastore ID")
    parser.add_argument("--location", default="us-central1",
                        help="Vertex AI region (default: us-central1)")
    parser.add_argument("--rag-location", default="global",
                        help="Discovery Engine location (default: global)")
    parser.add_argument("--model", default="gemini-2.0-flash-001",
                        help="Gemini model name")

    args = parser.parse_args()

    result = run_pipeline(
        gcs_folder_uri=args.gcs_folder,
        project_id=args.project_id,
        location=args.location,
        rag_location=args.rag_location,
        datastore_id=args.datastore_id,
        model_name=args.model,
    )
    print(json.dumps(result, indent=2))
