"""
utils/llm.py
------------
Thin wrapper around Vertex AI Gemini.
Initialises the SDK once and exposes a single call_llm() helper used by all agents.
"""

import json
import re
import vertexai
from vertexai.generative_models import GenerativeModel, GenerationConfig

# ── Module-level state ────────────────────────────────────────────────────────

_model: GenerativeModel | None = None


def init_llm(project_id: str, location: str = "us-central1",
             model_name: str = "gemini-2.0-flash-001") -> None:
    """
    Initialise Vertex AI and create the shared GenerativeModel instance.
    Call this once from the orchestrator before any agent runs.
    """
    global _model
    vertexai.init(project=project_id, location=location)
    _model = GenerativeModel(model_name)
    print(f"[LLM] Initialised model: {model_name} | project: {project_id} | location: {location}")


def call_llm(prompt: str, temperature: float = 0.1, max_output_tokens: int = 4096) -> str:
    """
    Send *prompt* to Gemini and return the raw text response.

    Parameters
    ----------
    prompt : str
        Full prompt string (system + user content combined).
    temperature : float
        Sampling temperature; keep low (0.0-0.2) for structured JSON outputs.
    max_output_tokens : int
        Hard cap on output length.

    Returns
    -------
    str
        Raw text from the model.
    """
    if _model is None:
        raise RuntimeError("LLM not initialised. Call init_llm() first.")

    config = GenerationConfig(
        temperature=temperature,
        max_output_tokens=max_output_tokens,
    )
    response = _model.generate_content(prompt, generation_config=config)
    return response.text


def parse_json_response(raw: str) -> dict:
    """
    Robustly parse a JSON object from a model response.

    Handles:
    - Pure JSON strings
    - JSON wrapped in ```json … ``` fences
    - Stray leading/trailing whitespace or newlines

    Raises
    ------
    ValueError
        If no valid JSON object can be extracted.
    """
    # Strip markdown fences if present
    cleaned = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()

    # Attempt direct parse
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Try to find the first {...} or [...] block
    match = re.search(r"(\{.*\}|\[.*\])", cleaned, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass

    raise ValueError(f"Could not parse JSON from LLM response:\n{raw[:500]}")
