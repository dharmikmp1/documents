"""
utils/rag.py
------------
Query an existing Vertex AI Search (Discovery Engine) datastore.

Uses google.cloud.discoveryengine_v1.SearchServiceClient to perform
a search and extract relevant text snippets from the results.
"""

from __future__ import annotations
from google.cloud import discoveryengine_v1 as discoveryengine
from google.protobuf.struct_pb2 import Struct


# ── Internal helpers ──────────────────────────────────────────────────────────

def _safe_struct_to_dict(struct: Struct) -> dict:
    """
    Convert a protobuf Struct to a plain Python dict without raising.
    Returns an empty dict on any error.
    """
    try:
        from google.protobuf.json_format import MessageToDict
        return MessageToDict(struct)
    except Exception:
        return {}


def _extract_snippet(result: discoveryengine.SearchResponse.SearchResult) -> str:
    """
    Pull the best available text snippet from a single search result.

    Priority:
      1. document.derived_struct_data["snippets"][*]["snippet"]
      2. document.struct_data (any string field)
      3. document.content.raw_bytes decoded as UTF-8
    """
    doc = result.document

    # 1. derived_struct_data → snippets
    derived = _safe_struct_to_dict(doc.derived_struct_data)
    snippets = derived.get("snippets", [])
    if snippets:
        texts = [s.get("snippet", "") for s in snippets if s.get("snippet")]
        if texts:
            return " ".join(texts)

    # 2. struct_data — concatenate all string values
    struct_data = _safe_struct_to_dict(doc.struct_data)
    str_values = [
        str(v) for v in struct_data.values() if isinstance(v, (str, int, float))
    ]
    if str_values:
        return " | ".join(str_values)

    # 3. raw content bytes
    try:
        raw = doc.content.raw_bytes
        if raw:
            return raw.decode("utf-8", errors="replace")[:2000]
    except Exception:
        pass

    return ""


# ── Public API ────────────────────────────────────────────────────────────────

def query_rag_datastore(
    query: str,
    project_id: str,
    location: str,
    datastore_id: str,
    max_results: int = 5,
) -> str:
    """
    Search the Discovery Engine datastore and return a consolidated
    context string built from the top-*max_results* results.

    Parameters
    ----------
    query : str
        Natural-language query (e.g. diagnosis or treatment name).
    project_id : str
        GCP project ID.
    location : str
        Datastore location, e.g. 'global' or 'us'.
    datastore_id : str
        The ID of the existing Discovery Engine datastore.
    max_results : int
        How many results to retrieve (1-10).

    Returns
    -------
    str
        Concatenated relevant text from the search results.
        Returns empty string if nothing found or on error.
    """
    try:
        client = discoveryengine.SearchServiceClient()

        serving_config = (
            f"projects/{project_id}/locations/{location}/"
            f"collections/default_collection/dataStores/{datastore_id}/"
            f"servingConfigs/default_config"
        )

        request = discoveryengine.SearchRequest(
            serving_config=serving_config,
            query=query,
            page_size=max(1, min(max_results, 10)),
            query_expansion_spec=discoveryengine.SearchRequest.QueryExpansionSpec(
                condition=discoveryengine.SearchRequest.QueryExpansionSpec.Condition.AUTO
            ),
            spell_correction_spec=discoveryengine.SearchRequest.SpellCorrectionSpec(
                mode=discoveryengine.SearchRequest.SpellCorrectionSpec.Mode.AUTO
            ),
        )

        response = client.search(request=request)

        snippets: list[str] = []
        for i, result in enumerate(response.results):
            snippet = _extract_snippet(result)
            if snippet:
                snippets.append(f"[Result {i+1}] {snippet}")

        combined = "\n\n".join(snippets)
        print(f"[RAG] Query='{query[:60]}…' → {len(snippets)} snippet(s) retrieved")
        return combined

    except Exception as exc:
        print(f"[RAG] Warning – datastore query failed: {exc}")
        return ""
