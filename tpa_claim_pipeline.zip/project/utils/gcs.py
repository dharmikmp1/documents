"""
utils/gcs.py
------------
Google Cloud Storage helpers:
  - list PDFs inside a GCS folder
  - download a blob to an in-memory bytes buffer
  - upload a JSON string to a GCS path
"""

import io
import json
from typing import Generator

from google.cloud import storage

# ── Internal helpers ──────────────────────────────────────────────────────────

def _parse_gcs_uri(uri: str) -> tuple[str, str]:
    """Split 'gs://bucket/prefix' into ('bucket', 'prefix')."""
    if not uri.startswith("gs://"):
        raise ValueError(f"Invalid GCS URI: {uri}")
    parts = uri[5:].split("/", 1)
    bucket = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""
    return bucket, prefix


def _get_client() -> storage.Client:
    """Return an authenticated GCS client (uses ADC)."""
    return storage.Client()


# ── Public API ────────────────────────────────────────────────────────────────

def list_pdfs(gcs_folder_uri: str) -> list[str]:
    """
    Return a list of full GCS URIs for every PDF inside *gcs_folder_uri*.

    Parameters
    ----------
    gcs_folder_uri : str
        E.g. 'gs://my-bucket/claims/claim-001/'

    Returns
    -------
    list[str]
        Sorted list of 'gs://<bucket>/<blob_name>' strings.
    """
    client = _get_client()
    bucket_name, prefix = _parse_gcs_uri(gcs_folder_uri)
    bucket = client.bucket(bucket_name)

    blobs = bucket.list_blobs(prefix=prefix)
    pdf_uris = sorted(
        f"gs://{bucket_name}/{blob.name}"
        for blob in blobs
        if blob.name.lower().endswith(".pdf")
    )
    print(f"[GCS] Found {len(pdf_uris)} PDF(s) in {gcs_folder_uri}")
    return pdf_uris


def download_blob_to_bytes(gcs_uri: str) -> bytes:
    """
    Download a GCS object and return its raw bytes.

    Parameters
    ----------
    gcs_uri : str
        Full GCS URI, e.g. 'gs://bucket/path/to/file.pdf'

    Returns
    -------
    bytes
    """
    client = _get_client()
    bucket_name, blob_name = _parse_gcs_uri(gcs_uri)
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    buffer = io.BytesIO()
    blob.download_to_file(buffer)
    buffer.seek(0)
    print(f"[GCS] Downloaded: {gcs_uri} ({blob.size:,} bytes)")
    return buffer.read()


def upload_json(data: dict, gcs_uri: str) -> None:
    """
    Serialise *data* to JSON and upload it to *gcs_uri*.

    Parameters
    ----------
    data : dict
        The payload to serialise.
    gcs_uri : str
        Destination URI, e.g. 'gs://bucket/output/claim-001/report.json'
    """
    client = _get_client()
    bucket_name, blob_name = _parse_gcs_uri(gcs_uri)
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    json_str = json.dumps(data, indent=2, ensure_ascii=False)
    blob.upload_from_string(json_str, content_type="application/json")
    print(f"[GCS] Uploaded report → {gcs_uri}")
