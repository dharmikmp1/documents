"""
utils/pdf_loader.py
-------------------
Extract plain text from PDF bytes using PyPDF.
Handles encrypted / malformed pages gracefully.
"""

import io
from pypdf import PdfReader


def extract_text_from_bytes(pdf_bytes: bytes, source_label: str = "") -> str:
    """
    Parse *pdf_bytes* with PyPDF and return concatenated page text.

    Parameters
    ----------
    pdf_bytes : bytes
        Raw PDF file content.
    source_label : str
        Optional label used in log messages (e.g. the GCS URI).

    Returns
    -------
    str
        Extracted text with pages separated by form-feed characters.
        Returns empty string if no text could be extracted.
    """
    reader = PdfReader(io.BytesIO(pdf_bytes))
    pages_text: list[str] = []

    for page_num, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
            pages_text.append(text)
        except Exception as exc:
            print(f"[PDF] Warning – could not extract page {page_num} "
                  f"from '{source_label}': {exc}")
            pages_text.append("")  # keep page count consistent

    combined = "\f".join(pages_text)  # form-feed as page separator
    total_chars = len(combined)
    print(f"[PDF] Extracted {total_chars:,} chars from "
          f"{len(reader.pages)} page(s) | source: '{source_label}'")
    return combined


def merge_texts(texts: list[str]) -> str:
    """
    Merge text from multiple PDFs into a single string.

    Parameters
    ----------
    texts : list[str]
        One entry per PDF file.

    Returns
    -------
    str
        All texts concatenated, separated by a clear delimiter.
    """
    delimiter = "\n\n" + ("=" * 60) + "\n\n"
    merged = delimiter.join(texts)
    print(f"[PDF] Merged {len(texts)} document(s) → {len(merged):,} total chars")
    return merged
