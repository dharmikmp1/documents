"""
agents/validator.py
-------------------
Validator Agent: check whether all required documents are present for the
claim type identified by the classifier.

Required documents:
  REIMBURSEMENT → discharge summary, final bill, prescriptions, lab reports
  CASHLESS      → pre-authorization form

Output schema
-------------
{
  "missing_documents": ["<doc name>", ...],
  "is_complete": true | false
}
"""

from utils.llm import call_llm, parse_json_response

# ── Document checklists ───────────────────────────────────────────────────────

REQUIRED_DOCS = {
    "reimbursement": [
        "discharge summary",
        "final bill",
        "prescriptions",
        "lab reports / diagnostic reports",
    ],
    "cashless": [
        "pre-authorization form",
    ],
}

# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM = """You are a medical insurance document validation specialist.
Your job is to determine which required documents are present or missing
in the provided claim text.

RULES:
1. Return ONLY a valid JSON object — no markdown fences, no explanation.
2. missing_documents must be a list of strings (document names).
3. is_complete must be true only when missing_documents is an empty list.
"""

_USER_TEMPLATE = """Claim type: {claim_type}

Required documents for this claim type:
{required_docs}

DOCUMENT TEXT (first 5000 chars):
{text_snippet}

Check each required document and list any that appear to be ABSENT from the text.
Return ONLY:
{{
  "missing_documents": ["<missing doc 1>", ...],
  "is_complete": true | false
}}
"""


# ── Public API ────────────────────────────────────────────────────────────────

def run(claim_type: str, combined_text: str) -> dict:
    """
    Validate document completeness for the given claim type.

    Parameters
    ----------
    claim_type : str
        "cashless" or "reimbursement".
    combined_text : str
        Merged PDF text.

    Returns
    -------
    dict
        {"missing_documents": [...], "is_complete": bool}
    """
    print(f"[Validator] Validating documents for '{claim_type}' claim …")

    required = REQUIRED_DOCS.get(claim_type, REQUIRED_DOCS["reimbursement"])
    required_str = "\n".join(f"  - {d}" for d in required)
    text_snippet = combined_text[:5000]

    prompt = (
        f"{_SYSTEM}\n\n"
        f"{_USER_TEMPLATE.format(claim_type=claim_type, required_docs=required_str, text_snippet=text_snippet)}"
    )
    raw = call_llm(prompt, temperature=0.0)
    result = parse_json_response(raw)

    # Normalise output
    missing = result.get("missing_documents", [])
    if not isinstance(missing, list):
        missing = []
    is_complete = len(missing) == 0

    result = {
        "missing_documents": missing,
        "is_complete": is_complete,
    }
    print(f"[Validator] Done. Missing: {missing} | Complete: {is_complete}")
    return result
