"""
agents/extractor.py
-------------------
Extractor Agent: parse raw claim text into a structured claim object.

Output schema
-------------
{
  "patient_name": str,
  "age": str,
  "hospital": str,
  "diagnosis": str,
  "treatment": str,
  "medicines": list[str],
  "bill_items": [{"name": str, "cost": float}],
  "total_amount": float
}
"""

from utils.llm import call_llm, parse_json_response

# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM = """You are a medical insurance claim data extraction specialist.
You will receive raw text extracted from one or more PDF documents belonging
to a single insurance claim. Your job is to extract key structured information.

RULES:
1. Return ONLY a valid JSON object — no markdown fences, no explanation.
2. If a field cannot be determined, use null.
3. cost values must be numbers (not strings).
4. medicines is a list of strings.
5. bill_items is a list of objects with "name" (string) and "cost" (number).
6. total_amount is a single number representing the grand total billed.
"""

_USER_TEMPLATE = """Extract claim information from the following document text.

DOCUMENT TEXT:
{text}

Return ONLY this JSON structure:
{{
  "patient_name": "<full name>",
  "age": "<age as string, e.g. '45 years'>",
  "hospital": "<hospital or clinic name>",
  "diagnosis": "<primary diagnosis>",
  "treatment": "<primary treatment or procedure>",
  "medicines": ["<medicine 1>", "<medicine 2>"],
  "bill_items": [
    {{"name": "<item name>", "cost": <amount>}}
  ],
  "total_amount": <grand total>
}}
"""


# ── Public API ────────────────────────────────────────────────────────────────

def run(combined_text: str) -> dict:
    """
    Extract structured claim data from *combined_text*.

    Parameters
    ----------
    combined_text : str
        All PDF text merged into one string by pdf_loader.merge_texts().

    Returns
    -------
    dict
        Parsed claim data matching the output schema above.

    Raises
    ------
    ValueError
        If the LLM response cannot be parsed as valid JSON.
    """
    print("[Extractor] Running extraction …")

    # Truncate extremely large inputs to avoid token limits
    # (~3 chars per token; Gemini Flash supports 1 M tokens)
    max_chars = 900_000
    truncated = combined_text[:max_chars]
    if len(combined_text) > max_chars:
        print(f"[Extractor] Warning: text truncated to {max_chars:,} chars")

    prompt = f"{_SYSTEM}\n\n{_USER_TEMPLATE.format(text=truncated)}"
    raw = call_llm(prompt, temperature=0.0)

    result = parse_json_response(raw)

    # Coerce types for safety
    result.setdefault("patient_name", None)
    result.setdefault("age", None)
    result.setdefault("hospital", None)
    result.setdefault("diagnosis", None)
    result.setdefault("treatment", None)
    result.setdefault("medicines", [])
    result.setdefault("bill_items", [])
    result.setdefault("total_amount", 0.0)

    # Ensure total_amount is numeric
    try:
        result["total_amount"] = float(result["total_amount"] or 0)
    except (TypeError, ValueError):
        result["total_amount"] = 0.0

    # Ensure bill_items costs are numeric
    for item in result.get("bill_items", []):
        try:
            item["cost"] = float(item.get("cost") or 0)
        except (TypeError, ValueError):
            item["cost"] = 0.0

    print(f"[Extractor] Done. Patient: {result.get('patient_name')} | "
          f"Total: {result.get('total_amount')}")
    return result
