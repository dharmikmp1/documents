"""
agents/decision.py
------------------
Decision Agent: produce the final claim decision (approval or rejection)
and calculate the approved amount.

For CASHLESS: pre-authorisation decision.
For REIMBURSEMENT: final reimbursement approval decision.

Output schema
-------------
{
  "status": "approved" | "partially_approved" | "rejected",
  "approved_amount": float,
  "reason": str
}
"""

import json
from utils.llm import call_llm, parse_json_response


# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM = """You are a senior insurance claims decision officer.
Based on the complete claim dossier provided, you must issue a final binding
decision: APPROVED, PARTIALLY APPROVED, or REJECTED.

RULES:
1. Return ONLY a valid JSON object — no markdown fences, no explanation.
2. approved_amount must be a number.
3. Be fair but firm. Apply all deductions identified by the medical agent.
4. If the claim is rejected in full, approved_amount = 0.
5. Reason must be a concise, professional sentence.
"""

_USER_TEMPLATE = """=== CLAIM TYPE ===
{claim_type}

=== EXTRACTED CLAIM DATA ===
{claim_data}

=== VALIDATION RESULT ===
{validation_result}

=== MEDICAL AGENT FINDINGS ===
{medical_result}

=== DECISION INSTRUCTIONS ===
For {claim_type} claims:
{decision_instructions}

Calculate approved_amount as:
  total_amount - sum(deductions[*].claimed - deductions[*].approved)

Return ONLY:
{{
  "status": "approved" | "partially_approved" | "rejected",
  "approved_amount": <number>,
  "reason": "<concise professional reason>"
}}
"""

_CASHLESS_INSTRUCTIONS = """- Decide whether to pre-authorise the treatment.
- Approve if: policy is valid, hospital is in network, and no major anomalies.
- Partially approve if: minor anomalies or some items are above GIPSA rates.
- Reject if: policy is invalid, hospital is non-network, or major fraud detected."""

_REIMBURSEMENT_INSTRUCTIONS = """- Decide the final reimbursement amount.
- Approve if: all documents present, policy valid, no fraud.
- Partially approve if: some items are inadmissible or above GIPSA rates.
- Reject if: policy exclusion applies, fraud detected, or documents incomplete."""


# ── Internal: compute approved amount ────────────────────────────────────────

def _compute_approved_amount(extracted_data: dict, medical_result: dict) -> float:
    """
    Approved amount = total_amount − sum of (claimed − approved) per deduction.
    """
    total = float(extracted_data.get("total_amount") or 0)
    total_deductions = sum(
        float(d.get("claimed", 0)) - float(d.get("approved", 0))
        for d in medical_result.get("deductions", [])
    )
    return max(0.0, total - total_deductions)


# ── Public API ────────────────────────────────────────────────────────────────

def run(
    claim_type: str,
    extracted_data: dict,
    validation_result: dict,
    medical_result: dict,
) -> dict:
    """
    Issue the final claim decision.

    Parameters
    ----------
    claim_type : str
        "cashless" or "reimbursement".
    extracted_data : dict
        Output of extractor agent.
    validation_result : dict
        Output of validator agent.
    medical_result : dict
        Output of medical agent.

    Returns
    -------
    dict
        {"status": str, "approved_amount": float, "reason": str}
    """
    print(f"[Decision] Making final decision for '{claim_type}' claim …")

    instructions = (
        _CASHLESS_INSTRUCTIONS if claim_type == "cashless" else _REIMBURSEMENT_INSTRUCTIONS
    )
    computed_amount = _compute_approved_amount(extracted_data, medical_result)

    prompt = (
        f"{_SYSTEM}\n\n"
        f"{_USER_TEMPLATE.format(claim_type=claim_type, claim_data=json.dumps(extracted_data, indent=2), validation_result=json.dumps(validation_result, indent=2), medical_result=json.dumps(medical_result, indent=2), decision_instructions=instructions)}"
    )
    raw = call_llm(prompt, temperature=0.0)
    result = parse_json_response(raw)

    # Normalise
    status = result.get("status", "rejected").lower().strip()
    if status not in ("approved", "partially_approved", "rejected"):
        status = "rejected"

    # Trust the LLM's approved_amount but cap it at computed ceiling
    try:
        approved_amount = float(result.get("approved_amount") or 0)
        # Never exceed what the math allows
        approved_amount = min(approved_amount, computed_amount)
        approved_amount = max(0.0, approved_amount)
    except (TypeError, ValueError):
        approved_amount = computed_amount if status != "rejected" else 0.0

    result = {
        "status": status,
        "approved_amount": round(approved_amount, 2),
        "reason": str(result.get("reason", "")),
    }
    print(f"[Decision] Done. Status: {status} | Approved: {approved_amount:.2f}")
    return result
