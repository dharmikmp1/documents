"""
agents/medical.py
-----------------
Medical Agent (Core Intelligence): perform deep clinical and policy validation
using both the extracted claim data and RAG-retrieved policy context.

Checks performed:
  1. Policy inclusion / exclusion validation
  2. GIPSA package rate validation
  3. Network hospital validation
  4. Diagnosis ↔ treatment coherence
  5. Treatment ↔ medicines coherence
  6. Fraud / anomaly detection

Output schema
-------------
{
  "policy_valid": bool,
  "hospital_network_valid": bool,
  "anomalies": ["<description>", ...],
  "deductions": [
    {
      "item": str,
      "claimed": float,
      "approved": float,
      "reason": str
    }
  ]
}
"""

import json
from utils.llm import call_llm, parse_json_response
from utils.rag import query_rag_datastore

# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM = """You are a senior medical insurance claims adjudicator with expertise in:
- Insurance policy interpretation (inclusions, exclusions, waiting periods)
- GIPSA (General Insurance Public Sector Association) package rates
- Hospital network verification
- Clinical coding (ICD-10, CPT)
- Medical fraud detection

You will receive:
1. Structured claim data
2. Policy / guidelines context retrieved from a RAG datastore

Perform a thorough medical and policy review and return STRICT JSON.

RULES:
1. Return ONLY a valid JSON object — no markdown fences, no preamble.
2. All amount fields must be numbers.
3. Be conservative: flag any anomaly you are even slightly uncertain about.
4. Deductions must list every line item you are reducing, with a clear reason.
"""

_USER_TEMPLATE = """=== EXTRACTED CLAIM DATA ===
{claim_data}

=== POLICY / GUIDELINES CONTEXT (from RAG) ===
{rag_context}

=== INSTRUCTIONS ===
Perform ALL of the following checks:

1. POLICY VALIDATION
   - Is the diagnosis covered under the policy?
   - Are any listed treatments/medicines on the exclusion list?
   - Check for waiting-period violations (e.g., pre-existing conditions).

2. GIPSA PACKAGE VALIDATION
   - Compare billed amounts against standard GIPSA package rates.
   - Flag any item billed significantly above GIPSA rates.

3. HOSPITAL NETWORK VALIDATION
   - Is the hospital a recognised network/empanelled hospital?
   - Flag if unknown or suspected non-network.

4. DIAGNOSIS ↔ TREATMENT COHERENCE
   - Are the treatments clinically appropriate for the stated diagnosis?
   - Flag any mismatch.

5. TREATMENT ↔ MEDICINES COHERENCE
   - Are the prescribed medicines appropriate for the treatment and diagnosis?
   - Flag unnecessary, duplicate, or inappropriate medicines.

6. FRAUD / ANOMALY DETECTION
   - Inflated bill amounts
   - Duplicate charges
   - Treatments inconsistent with patient age
   - Unusually short or long hospital stay
   - Any other red flags

Return ONLY this JSON:
{{
  "policy_valid": true | false,
  "hospital_network_valid": true | false,
  "anomalies": ["<anomaly description>", ...],
  "deductions": [
    {{
      "item": "<bill item name>",
      "claimed": <amount>,
      "approved": <amount>,
      "reason": "<reason for deduction>"
    }}
  ]
}}
"""


# ── Internal: build RAG query from claim data ─────────────────────────────────

def _build_rag_query(extracted_data: dict) -> str:
    """Compose a focused query string for the RAG datastore."""
    parts = []
    if d := extracted_data.get("diagnosis"):
        parts.append(f"diagnosis: {d}")
    if t := extracted_data.get("treatment"):
        parts.append(f"treatment: {t}")
    if h := extracted_data.get("hospital"):
        parts.append(f"hospital: {h}")
    if m := extracted_data.get("medicines"):
        parts.append(f"medicines: {', '.join(m[:5])}")
    return "; ".join(parts) if parts else "insurance claim policy coverage"


# ── Public API ────────────────────────────────────────────────────────────────

def run(
    extracted_data: dict,
    rag_config: dict,
) -> dict:
    """
    Run the medical intelligence agent.

    Parameters
    ----------
    extracted_data : dict
        Output from extractor_agent.run().
    rag_config : dict
        Must contain keys: project_id, location, datastore_id.

    Returns
    -------
    dict
        Matching the output schema defined above.
    """
    print("[Medical] Running medical & policy validation …")

    # ── Step 1: RAG retrieval ─────────────────────────────────────────────────
    rag_query = _build_rag_query(extracted_data)
    rag_context = query_rag_datastore(
        query=rag_query,
        project_id=rag_config["project_id"],
        location=rag_config["location"],
        datastore_id=rag_config["datastore_id"],
    )

    if not rag_context:
        rag_context = "No specific policy guidelines retrieved. Apply general insurance norms."

    # ── Step 2: LLM analysis ──────────────────────────────────────────────────
    claim_data_str = json.dumps(extracted_data, indent=2)
    prompt = (
        f"{_SYSTEM}\n\n"
        f"{_USER_TEMPLATE.format(claim_data=claim_data_str, rag_context=rag_context)}"
    )
    raw = call_llm(prompt, temperature=0.1, max_output_tokens=4096)
    result = parse_json_response(raw)

    # ── Step 3: Normalise output ──────────────────────────────────────────────
    result.setdefault("policy_valid", True)
    result.setdefault("hospital_network_valid", True)
    result.setdefault("anomalies", [])
    result.setdefault("deductions", [])

    # Ensure types
    result["policy_valid"] = bool(result["policy_valid"])
    result["hospital_network_valid"] = bool(result["hospital_network_valid"])

    if not isinstance(result["anomalies"], list):
        result["anomalies"] = []

    deductions = []
    for d in result.get("deductions", []):
        try:
            deductions.append({
                "item": str(d.get("item", "")),
                "claimed": float(d.get("claimed") or 0),
                "approved": float(d.get("approved") or 0),
                "reason": str(d.get("reason", "")),
            })
        except (TypeError, ValueError):
            pass
    result["deductions"] = deductions

    print(f"[Medical] Done. Policy valid: {result['policy_valid']} | "
          f"Anomalies: {len(result['anomalies'])} | "
          f"Deductions: {len(result['deductions'])}")
    return result
