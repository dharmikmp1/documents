"""
agents/report.py
----------------
Report Agent: assemble all agent outputs into a single, human-readable
structured report.

Output schema
-------------
{
  "claim_id": str,
  "claim_type": str,
  "patient_summary": str,
  "diagnosis_summary": str,
  "treatment_summary": str,
  "bill_breakdown": [{"name": str, "cost": float}],
  "anomalies": [str],
  "deductions": [{"item": str, "claimed": float, "approved": float, "reason": str}],
  "validation_status": {"missing_documents": [...], "is_complete": bool},
  "final_decision": {"status": str, "approved_amount": float, "reason": str},
  "processing_metadata": {"total_claimed": float, "total_deductions": float}
}
"""

import json
from utils.llm import call_llm, parse_json_response


# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM = """You are a professional medical insurance claims report writer.
Synthesise all the information below into clear, concise professional summaries.
The summaries will be read by both claims officers and medical reviewers.

RULES:
1. Return ONLY a valid JSON object — no markdown fences, no explanation.
2. patient_summary: 2-3 sentence narrative about the patient and admission.
3. diagnosis_summary: 1-2 sentences explaining the diagnosis clinically.
4. treatment_summary: 1-2 sentences describing the treatment course.
"""

_USER_TEMPLATE = """Synthesise the following claim processing data into a report.

EXTRACTED DATA:
{extracted_data}

CLAIM TYPE: {claim_type}

MEDICAL FINDINGS:
{medical_result}

FINAL DECISION:
{decision_result}

Return ONLY:
{{
  "patient_summary": "<2-3 sentence narrative>",
  "diagnosis_summary": "<1-2 sentence clinical explanation>",
  "treatment_summary": "<1-2 sentence treatment description>"
}}
"""


# ── Internal helpers ──────────────────────────────────────────────────────────

def _compute_totals(extracted_data: dict, medical_result: dict) -> dict:
    """Calculate financial summary figures."""
    total_claimed = float(extracted_data.get("total_amount") or 0)
    total_deductions = sum(
        float(d.get("claimed", 0)) - float(d.get("approved", 0))
        for d in medical_result.get("deductions", [])
    )
    return {
        "total_claimed": round(total_claimed, 2),
        "total_deductions": round(total_deductions, 2),
    }


# ── Public API ────────────────────────────────────────────────────────────────

def run(
    claim_id: str,
    claim_type: str,
    extracted_data: dict,
    validation_result: dict,
    medical_result: dict,
    decision_result: dict,
) -> dict:
    """
    Generate the final consolidated report.

    Parameters
    ----------
    claim_id : str
        Unique identifier for this claim (used in GCS path).
    claim_type : str
        "cashless" or "reimbursement".
    extracted_data : dict
        Extractor agent output.
    validation_result : dict
        Validator agent output.
    medical_result : dict
        Medical agent output.
    decision_result : dict
        Decision agent output.

    Returns
    -------
    dict
        Complete report matching the output schema.
    """
    print("[Report] Generating final report …")

    # ── LLM-generated narrative summaries ────────────────────────────────────
    prompt = (
        f"{_SYSTEM}\n\n"
        f"{_USER_TEMPLATE.format(extracted_data=json.dumps(extracted_data, indent=2), claim_type=claim_type, medical_result=json.dumps(medical_result, indent=2), decision_result=json.dumps(decision_result, indent=2))}"
    )
    raw = call_llm(prompt, temperature=0.2)
    narratives = parse_json_response(raw)

    # ── Assemble full report ──────────────────────────────────────────────────
    totals = _compute_totals(extracted_data, medical_result)

    report = {
        "claim_id": claim_id,
        "claim_type": claim_type,
        # Narrative summaries from LLM
        "patient_summary": narratives.get("patient_summary", ""),
        "diagnosis_summary": narratives.get("diagnosis_summary", ""),
        "treatment_summary": narratives.get("treatment_summary", ""),
        # Structured data pass-through
        "bill_breakdown": extracted_data.get("bill_items", []),
        "anomalies": medical_result.get("anomalies", []),
        "deductions": medical_result.get("deductions", []),
        "validation_status": validation_result,
        "final_decision": decision_result,
        "processing_metadata": totals,
    }

    print(f"[Report] Done. Decision: {decision_result.get('status')} | "
          f"Approved: {decision_result.get('approved_amount')}")
    return report
