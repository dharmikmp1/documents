"""
agents/classifier.py
--------------------
Classifier Agent: determine whether the claim is cashless or reimbursement.

Output schema
-------------
{
  "claim_type": "cashless" | "reimbursement"
}
"""

from utils.llm import call_llm, parse_json_response

# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM = """You are a medical insurance claim classification specialist.
Your task is to determine whether a claim is a CASHLESS claim or a REIMBURSEMENT claim.

Definitions:
- CASHLESS: The insured receives treatment at a network hospital and the
  insurer settles the bill directly with the hospital.  Documents typically
  include a pre-authorization (pre-auth) request/approval form.
- REIMBURSEMENT: The insured pays the hospital and then submits bills to the
  insurer for reimbursement after discharge.  Documents typically include
  a final hospital bill, discharge summary, prescriptions, and lab reports.

RULES:
1. Return ONLY a valid JSON object — no markdown fences, no explanation.
2. Choose exactly one of "cashless" or "reimbursement".
"""

_USER_TEMPLATE = """Classify the following insurance claim.

EXTRACTED CLAIM DATA:
{claim_data}

RAW DOCUMENT SNIPPET (first 3000 chars):
{text_snippet}

Return ONLY:
{{"claim_type": "cashless" | "reimbursement"}}
"""


# ── Public API ────────────────────────────────────────────────────────────────

def run(extracted_data: dict, combined_text: str) -> dict:
    """
    Classify the claim type.

    Parameters
    ----------
    extracted_data : dict
        Output from extractor_agent.run().
    combined_text : str
        Raw merged PDF text (used for additional context).

    Returns
    -------
    dict
        {"claim_type": "cashless" | "reimbursement"}
    """
    print("[Classifier] Classifying claim type …")

    import json
    claim_data_str = json.dumps(extracted_data, indent=2)
    text_snippet = combined_text[:3000]

    prompt = f"{_SYSTEM}\n\n{_USER_TEMPLATE.format(claim_data=claim_data_str, text_snippet=text_snippet)}"
    raw = call_llm(prompt, temperature=0.0)

    result = parse_json_response(raw)

    # Validate and default
    claim_type = result.get("claim_type", "reimbursement").lower().strip()
    if claim_type not in ("cashless", "reimbursement"):
        print(f"[Classifier] Unexpected value '{claim_type}', defaulting to 'reimbursement'")
        claim_type = "reimbursement"

    result = {"claim_type": claim_type}
    print(f"[Classifier] Done. Claim type: {claim_type}")
    return result
