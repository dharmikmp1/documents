"""
tools/pdf_tools.py
------------------
PDF text extraction using PyPDF.
Accepts hex-encoded bytes from gcs_tools.download_pdf_bytes so all data
stays serialisable through the ADK session state.
"""

from __future__ import annotations
import io
import logging

from pypdf import PdfReader
from pypdf.errors import PdfReadError

logger = logging.getLogger(__name__)

_MAX_MERGED_CHARS = 900_000   # ~225 k tokens — safe Gemini Flash ceiling


def extract_text_from_pdf_hex(hex_bytes: str, source_label: str = "") -> dict:
    """
    Extract plain text from a PDF supplied as a hex-encoded byte string.

    Args:
        hex_bytes:    Hex-encoded raw PDF bytes (from download_pdf_bytes tool).
        source_label: Optional label for log messages (e.g. GCS URI).

    Returns:
        dict with:
          - text       (str):       Extracted text, pages separated by form-feeds.
          - page_count (int):       Number of pages processed.
          - char_count (int):       Total characters extracted.
          - error      (str|None):  Error message if extraction failed.
    """
    if not hex_bytes:
        return {"text": "", "page_count": 0, "char_count": 0,
                "error": "hex_bytes is empty — download may have failed"}
    try:
        raw = bytes.fromhex(hex_bytes)
    except ValueError as exc:
        return {"text": "", "page_count": 0, "char_count": 0,
                "error": f"Invalid hex encoding: {exc}"}

    try:
        reader = PdfReader(io.BytesIO(raw))
    except PdfReadError as exc:
        return {"text": "", "page_count": 0, "char_count": 0,
                "error": f"PDF parse error for {source_label!r}: {exc}"}
    except Exception as exc:
        return {"text": "", "page_count": 0, "char_count": 0,
                "error": f"Unexpected PDF error for {source_label!r}: {exc}"}

    pages: list[str] = []
    for i, page in enumerate(reader.pages, 1):
        try:
            pages.append(page.extract_text() or "")
        except Exception as exc:
            logger.warning("[PDF] page %d failed (%s): %s", i, source_label, exc)
            pages.append("")   # keep slot so page numbering stays intact

    text = "\f".join(pages)
    logger.info("[PDF] %s → %d pages, %d chars", source_label, len(pages), len(text))
    return {
        "text":       text,
        "page_count": len(pages),
        "char_count": len(text),
        "error":      None,
    }


def merge_pdf_texts(texts: list[str]) -> dict:
    """
    Merge text from multiple PDFs into one corpus string, clamped to token limit.

    Args:
        texts: List of text strings, one per PDF document.

    Returns:
        dict with:
          - merged_text  (str): All texts joined with a separator.
          - doc_count    (int): Number of documents merged.
          - total_chars  (int): Total character count after clamping.
          - was_truncated (bool): True if text was truncated to fit token limit.
    """
    sep = "\n\n" + ("=" * 60) + "\n\n"
    merged = sep.join(t for t in texts if t and t.strip())

    truncated = False
    if len(merged) > _MAX_MERGED_CHARS:
        logger.warning("[PDF] merged text truncated from %d → %d chars",
                       len(merged), _MAX_MERGED_CHARS)
        merged = merged[:_MAX_MERGED_CHARS]
        truncated = True

    return {
        "merged_text":   merged,
        "doc_count":     len(texts),
        "total_chars":   len(merged),
        "was_truncated": truncated,
    }
