"""
tools/rag_tools.py
------------------
Vertex AI RAG Engine retrieval — stable vertexai.rag API.

Compatible with google-cloud-aiplatform >= 1.112.0

The Filter class path has changed across SDK versions:
  - Old (<=1.91):  rag.utils.resources.Filter
  - New (>=1.112): rag.RagRetrievalConfig accepts filter as a direct param
                   using rag.utils.resources.Filter OR just passing top_k only

We handle both with a safe import fallback so the code works across versions.
"""

from __future__ import annotations
import logging

import vertexai
from vertexai import rag

from tools.ssl_fix import apply_ssl_fix

logger = logging.getLogger(__name__)

_INIT_KEYS: set[str] = set()


def _ensure_init(project_id: str, location: str) -> None:
    key = f"{project_id}:{location}"
    if key not in _INIT_KEYS:
        apply_ssl_fix()
        vertexai.init(project=project_id, location=location)
        _INIT_KEYS.add(key)


def _build_retrieval_config(top_k: int, vector_distance_threshold: float):
    """
    Build RagRetrievalConfig with a safe Filter import fallback.

    The Filter path changed between SDK versions. We try each path in order.
    """
    top_k = max(1, min(int(top_k), 50))

    # Attempt 1: new path (aiplatform >= 1.112)
    try:
        return rag.RagRetrievalConfig(
            top_k=top_k,
            filter=rag.utils.resources.Filter(
                vector_distance_threshold=float(vector_distance_threshold)
            ),
        )
    except AttributeError:
        pass

    # Attempt 2: direct attribute on rag module
    try:
        filter_cls = getattr(rag, "Filter", None)
        if filter_cls:
            return rag.RagRetrievalConfig(
                top_k=top_k,
                filter=filter_cls(
                    vector_distance_threshold=float(vector_distance_threshold)
                ),
            )
    except Exception:
        pass

    # Attempt 3: top_k only — omit filter entirely (always works)
    logger.warning("[RAG] Could not import Filter class; using top_k only")
    return rag.RagRetrievalConfig(top_k=top_k)


def query_rag_corpus(
    query_text: str,
    rag_corpus_resource: str,
    project_id: str,
    location: str = "us-central1",
    top_k: int = 5,
    vector_distance_threshold: float = 0.5,
) -> dict:
    """
    Retrieve relevant text chunks from a Vertex AI RAG Corpus.

    Args:
        query_text: Natural-language search string.
        rag_corpus_resource: Full resource name:
            projects/<PROJECT>/locations/<LOC>/ragCorpora/<ID>
        project_id: GCP project ID.
        location: Region matching the corpus location.
        top_k: Number of chunks to retrieve (1-50).
        vector_distance_threshold: Similarity cutoff (0.0-1.0).

    Returns:
        dict with keys: context (str), chunk_count (int),
                        sources (list[str]), error (str|None)
    """
    if not rag_corpus_resource or not rag_corpus_resource.strip():
        return {"context": "", "chunk_count": 0, "sources": [],
                "error": "rag_corpus_resource is empty"}

    if not query_text or not query_text.strip():
        return {"context": "", "chunk_count": 0, "sources": [],
                "error": "query_text is empty"}

    try:
        _ensure_init(project_id, location)

        retrieval_config = _build_retrieval_config(top_k, vector_distance_threshold)

        response = rag.retrieval_query(
            rag_resources=[rag.RagResource(rag_corpus=rag_corpus_resource)],
            text=query_text.strip(),
            rag_retrieval_config=retrieval_config,
        )

        # Safe response parsing
        contexts_wrapper = getattr(response, "contexts", None)
        raw_contexts = getattr(contexts_wrapper, "contexts", []) if contexts_wrapper else []

        chunks: list[str] = []
        sources: list[str] = []

        for i, ctx in enumerate(raw_contexts):
            text   = (getattr(ctx, "text",       None) or "").strip()
            source = (getattr(ctx, "source_uri", None) or f"chunk-{i+1}").strip()
            score  = getattr(ctx, "score", None)
            if not text:
                continue
            score_str = f"  score={score:.3f}" if score is not None else ""
            chunks.append(f"[Source: {source}{score_str}]\n{text}")
            sources.append(source)

        combined = "\n\n---\n\n".join(chunks)
        logger.info("[RAG] '%s' → %d chunk(s)", query_text[:60], len(chunks))
        return {"context": combined, "chunk_count": len(chunks),
                "sources": sources, "error": None}

    except Exception as exc:
        err = str(exc)
        logger.error("[RAG] retrieval_query failed: %s", err)
        if "NOT_FOUND" in err or "404" in err:
            logger.error("[RAG] Hint: verify rag_corpus_resource and location match.")
        elif "PERMISSION_DENIED" in err or "403" in err:
            logger.error("[RAG] Hint: grant 'Vertex AI User' role to the service account.")
        return {"context": "", "chunk_count": 0, "sources": [], "error": err}
