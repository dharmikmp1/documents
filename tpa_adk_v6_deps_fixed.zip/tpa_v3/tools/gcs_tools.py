"""
tools/gcs_tools.py
------------------
GCS read / write tools compatible with google-cloud-storage >= 3.0.0

Changes vs v4:
  - Removed google.cloud.exceptions import (moved in 3.x; not needed)
  - Removed unused imports (time, Any)
  - Retry uses google.api_core.retry (unchanged, still correct in 3.x)
  - upload uses blob.upload_from_string with bytes (avoids encoding issues in 3.x)
  - _GCS_RETRY now uses keyword-only construction compatible with api_core >= 2.x
"""

from __future__ import annotations

import io
import json
import logging

from google.cloud import storage
from google.api_core import retry as api_retry

from tools.ssl_fix import apply_ssl_fix

logger = logging.getLogger(__name__)

_SSL_FIXED = False


def _ensure_ssl() -> None:
    global _SSL_FIXED
    if not _SSL_FIXED:
        _SSL_FIXED = apply_ssl_fix()


# google.api_core.retry.Retry — stable across api_core 1.x and 2.x
_GCS_RETRY = api_retry.Retry(
    predicate=api_retry.if_transient_error,
    initial=1.0,
    maximum=32.0,
    multiplier=2.0,
    deadline=120.0,
)


def _parse_uri(uri: str) -> tuple[str, str]:
    if not uri.startswith("gs://"):
        raise ValueError(f"URI must start with gs://, got: {uri!r}")
    without_scheme = uri[5:]
    parts = without_scheme.split("/", 1)
    return parts[0], (parts[1] if len(parts) > 1 else "")


def _make_client() -> storage.Client:
    _ensure_ssl()
    return storage.Client()


def _classify_error(exc: Exception) -> str:
    msg = str(exc).lower()
    if "ssl" in msg or "certificate" in msg:
        return "SSL_ERROR"
    if "403" in msg or "permission" in msg or "access denied" in msg:
        return "PERMISSION_ERROR"
    if "404" in msg or "not found" in msg:
        return "NOT_FOUND"
    if "401" in msg or "unauthorized" in msg or "credentials" in msg:
        return "AUTH_ERROR"
    if "timeout" in msg or "timed out" in msg:
        return "TIMEOUT"
    return "UNKNOWN_ERROR"


# ── tool functions ────────────────────────────────────────────────────────────

def list_pdfs_in_folder(gcs_folder_uri: str) -> dict:
    """
    List all PDF files inside a GCS folder.

    Args:
        gcs_folder_uri: GCS folder URI, e.g. 'gs://bucket/claims/CLAIM-001/'

    Returns:
        dict with keys:
          - pdf_uris  (list[str]): sorted list of gs:// URIs for every PDF found
          - count     (int):       number of PDFs found
          - error     (str|None):  error message if the operation failed
    """
    for attempt in range(2):
        try:
            client = _make_client()
            bucket_name, prefix = _parse_uri(gcs_folder_uri)
            blobs = client.bucket(bucket_name).list_blobs(
                prefix=prefix, retry=_GCS_RETRY
            )
            uris = sorted(
                f"gs://{bucket_name}/{b.name}"
                for b in blobs
                if b.name.lower().endswith(".pdf")
            )
            logger.info("[GCS] %d PDF(s) in %s", len(uris), gcs_folder_uri)
            return {"pdf_uris": uris, "count": len(uris), "error": None}
        except Exception as exc:
            category = _classify_error(exc)
            logger.error("[GCS] list_pdfs attempt %d [%s]: %s", attempt + 1, category, exc)
            if category == "SSL_ERROR" and attempt == 0:
                global _SSL_FIXED
                _SSL_FIXED = False
                _ensure_ssl()
                continue
            return {"pdf_uris": [], "count": 0, "error": f"[{category}] {exc}"}
    return {"pdf_uris": [], "count": 0, "error": "list_pdfs failed after SSL retry"}


def download_pdf_bytes(gcs_uri: str) -> dict:
    """
    Download a single PDF from GCS and return its raw bytes as a hex string.

    Args:
        gcs_uri: Full GCS URI of the PDF, e.g. 'gs://bucket/path/file.pdf'

    Returns:
        dict with keys:
          - hex_bytes  (str):      hex-encoded PDF bytes
          - size_bytes (int):      file size in bytes
          - error      (str|None): error message if the operation failed
    """
    for attempt in range(2):
        try:
            client = _make_client()
            bucket_name, blob_name = _parse_uri(gcs_uri)
            buf = io.BytesIO()
            client.bucket(bucket_name).blob(blob_name).download_to_file(
                buf, retry=_GCS_RETRY
            )
            raw = buf.getvalue()
            logger.info("[GCS] Downloaded %s (%d bytes)", gcs_uri, len(raw))
            return {"hex_bytes": raw.hex(), "size_bytes": len(raw), "error": None}
        except Exception as exc:
            category = _classify_error(exc)
            logger.error("[GCS] download attempt %d [%s]: %s", attempt + 1, category, exc)
            if category == "SSL_ERROR" and attempt == 0:
                global _SSL_FIXED
                _SSL_FIXED = False
                _ensure_ssl()
                continue
            return {"hex_bytes": "", "size_bytes": 0, "error": f"[{category}] {exc}"}
    return {"hex_bytes": "", "size_bytes": 0, "error": "download failed after SSL retry"}


def upload_report_to_gcs(report_json: str, output_gcs_uri: str) -> dict:
    """
    Upload a JSON report string to a GCS path.

    Args:
        report_json:    JSON string of the final report.
        output_gcs_uri: Destination URI, e.g. 'gs://bucket/output/CLAIM-001/report.json'

    Returns:
        dict with keys:
          - success (bool)
          - uri     (str)
          - error   (str|None)
    """
    # Validate + pretty-print JSON before uploading
    try:
        report_json = json.dumps(json.loads(report_json), indent=2, ensure_ascii=False)
    except (json.JSONDecodeError, TypeError) as exc:
        return {"success": False, "uri": output_gcs_uri,
                "error": f"Invalid JSON: {exc}"}

    for attempt in range(2):
        try:
            client = _make_client()
            bucket_name, blob_name = _parse_uri(output_gcs_uri)
            blob = client.bucket(bucket_name).blob(blob_name)
            # Pass bytes explicitly — avoids string encoding ambiguity in gcs 3.x
            blob.upload_from_string(
                report_json.encode("utf-8"),
                content_type="application/json",
                retry=_GCS_RETRY,
            )
            logger.info("[GCS] Report uploaded → %s", output_gcs_uri)
            return {"success": True, "uri": output_gcs_uri, "error": None}
        except Exception as exc:
            category = _classify_error(exc)
            logger.error("[GCS] upload attempt %d [%s]: %s", attempt + 1, category, exc)
            if category == "SSL_ERROR" and attempt == 0:
                global _SSL_FIXED
                _SSL_FIXED = False
                _ensure_ssl()
                continue
            return {"success": False, "uri": output_gcs_uri,
                    "error": f"[{category}] {exc}"}
    return {"success": False, "uri": output_gcs_uri,
            "error": "upload failed after SSL retry"}
