"""
agent.py  —  TPA Medical Insurance Claim Processing (v4)
---------------------------------------------------------
Google ADK SequentialAgent pipeline deployable to Vertex AI Agent Engine.

Pipeline stages (strictly sequential):
  1. IngestAgent      — GCS PDF discovery + download + text extraction
  2. ExtractorAgent   — structured claim data from merged text
  3. ClassifierAgent  — cashless vs reimbursement
  4. ValidatorAgent   — content-driven document completeness check
  5. MedicalAgent     — RAG-powered GIPSA, policy, clinical, fraud review
  6. DecisionAgent    — final approval + line-wise bill breakdown
  7. ReportAgent      — professional narrative summaries
  8. OutputAgent      — assemble full report JSON + write to GCS

Invoke locally (Jupyter):
    result = await run_local(
        gcs_folder_uri      = "gs://bucket/claims/CLAIM-001/",
        project_id          = "my-project",
        rag_corpus_resource = "projects/.../ragCorpora/...",
    )

Deploy to Agent Engine:
    remote = deploy_to_agent_engine(project_id, location, staging_bucket)
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

import vertexai
from google.adk.agents import LlmAgent, SequentialAgent
from vertexai.agent_engines import AdkApp

from agents.extractor_agent  import extractor_agent
from agents.classifier_agent import classifier_agent
from agents.validator_agent  import validator_agent
from agents.medical_agent    import medical_agent
from agents.decision_agent   import decision_agent
from agents.report_agent     import report_agent

from tools.gcs_tools  import list_pdfs_in_folder, download_pdf_bytes, upload_report_to_gcs
from tools.pdf_tools  import extract_text_from_pdf_hex, merge_pdf_texts
from tools.json_utils import parse_llm_json

logger = logging.getLogger(__name__)
MODEL = "gemini-2.0-flash-001"


# ══════════════════════════════════════════════════════════════════════════════
# Stage 1 — IngestAgent
# ══════════════════════════════════════════════════════════════════════════════

INGEST_INSTRUCTION = """
You are a document ingestion agent for a TPA claim processing system.

SESSION STATE KEY "input_payload" contains a JSON string with:
  { "gcs_folder_uri", "project_id", "rag_corpus_resource", "rag_location" }

YOUR STEPS (execute ALL in order):
  1. Parse "input_payload" to get the four fields above.
  2. Call list_pdfs_in_folder(gcs_folder_uri) to discover all PDFs.
     If count = 0 → output error JSON and stop.
  3. For EACH PDF URI in pdf_uris (process every one, do not skip):
     a. Call download_pdf_bytes(gcs_uri) → get hex_bytes.
     b. If hex_bytes is empty (download error) → log error, continue to next PDF.
     c. Call extract_text_from_pdf_hex(hex_bytes, source_label=gcs_uri) → get text.
  4. Collect all non-empty texts into a list.
  5. Call merge_pdf_texts(texts) → get merged_text.
  6. Extract claim_id from the last non-empty path segment of gcs_folder_uri.
  7. Output the result JSON below.

STRICT RULES:
  1. Output ONLY a valid JSON object. NO markdown fences. NO explanation.
  2. Process EVERY PDF — do not stop after the first.
  3. If a PDF fails, include its URI in pdf_errors list and continue.

REQUIRED OUTPUT FORMAT:
{
  "gcs_folder_uri": "<folder URI>",
  "project_id": "<project ID>",
  "rag_corpus_resource": "<RAG corpus resource name>",
  "rag_location": "<RAG location>",
  "claim_id": "<last folder segment>",
  "pdf_uris": ["<uri1>", "<uri2>"],
  "pdf_errors": ["<uri of any failed PDF>"],
  "merged_text": "<combined text>",
  "doc_count": <integer>,
  "total_chars": <integer>
}
"""

ingest_agent = LlmAgent(
    name="IngestAgent",
    model=MODEL,
    description="Discovers PDFs in GCS, downloads, extracts and merges all text.",
    instruction=INGEST_INSTRUCTION,
    tools=[list_pdfs_in_folder, download_pdf_bytes,
           extract_text_from_pdf_hex, merge_pdf_texts],
    output_key="ingest_result",
)


# ══════════════════════════════════════════════════════════════════════════════
# Stage 8 — OutputAgent
# ══════════════════════════════════════════════════════════════════════════════

OUTPUT_INSTRUCTION = """
You are the final output assembly agent for a TPA claim processing pipeline.

Read and PARSE these session state keys (all are JSON strings):
  "ingest_result"      — {gcs_folder_uri, claim_id, project_id, doc_count, ...}
  "extracted_data"     — structured claim data
  "classifier_result"  — {claim_type, confidence, reason}
  "validation_result"  — {required_documents, missing_documents, is_complete, document_check_details}
  "medical_result"     — {bill_items_reviewed, total_claimed, total_approved, total_deduction,
                          deductions, non_payable_items, anomalies, fraud_risk, ...}
  "decision_result"    — {status, approved_amount, bill_breakdown, settlement_summary, ...}
  "report_summaries"   — {patient_summary, clinical_summary, treatment_summary, adjudication_summary}

STEP 1 — Assemble the final report JSON (structure shown below).
STEP 2 — Derive output_gcs_uri:
    bucket   = second segment of gcs_folder_uri (after gs://)
    claim_id = from ingest_result
    output_gcs_uri = "gs://<bucket>/output/<claim_id>/report.json"
STEP 3 — Call upload_report_to_gcs(report_json=<JSON string of report>, output_gcs_uri=<uri>)
STEP 4 — Output the final report as your response.

STRICT RULES:
  1. Output ONLY a valid JSON object. NO markdown fences. NO explanation.
  2. bill_breakdown must include EVERY line item with claimed AND approved amounts.
  3. settlement_summary must have total_claimed, total_approved, total_deduction.
  4. All amounts must be numbers (float).

REQUIRED OUTPUT FORMAT:
{
  "claim_id": "<claim_id>",
  "claim_type": "<cashless|reimbursement>",
  "processing_date": "<today's date>",
  "patient_summary": "<from report_summaries>",
  "clinical_summary": "<from report_summaries>",
  "treatment_summary": "<from report_summaries>",
  "adjudication_summary": "<from report_summaries>",
  "document_validation": {
    "is_complete": true | false,
    "required_documents": ["<doc>"],
    "missing_documents": ["<doc>"],
    "document_check_details": {}
  },
  "bill_breakdown": [
    {
      "name": "<item>",
      "category": "<category>",
      "claimed_amount": <number>,
      "approved_amount": <number>,
      "difference": <number>,
      "status": "approved|partial|excluded|deducted",
      "note": "<reason or null>"
    }
  ],
  "settlement_summary": {
    "total_claimed": <number>,
    "total_approved": <number>,
    "total_deduction": <number>,
    "deduction_breakdown": {
      "gipsa_excess": <number>,
      "non_payable": <number>,
      "missing_documents": <number>,
      "fraud_hold": <number>,
      "other": <number>
    }
  },
  "deductions": [
    {
      "item": "<item>",
      "category": "<category>",
      "claimed": <number>,
      "approved": <number>,
      "reason": "<reason>"
    }
  ],
  "non_payable_items": ["<item>"],
  "anomalies": ["<finding>"],
  "missing_mandatory_investigations": ["<test>"],
  "clinical_coherence_issues": ["<issue>"],
  "fraud_risk": "low|medium|high",
  "final_decision": {
    "status": "approved|partially_approved|rejected",
    "approved_amount": <number>,
    "reason": "<decision rationale>",
    "next_steps": "<what happens next>"
  },
  "metadata": {
    "pdf_count": <number>,
    "source_folder": "<gcs_folder_uri>",
    "report_uri": "<output_gcs_uri>"
  }
}
"""

output_agent = LlmAgent(
    name="OutputAgent",
    model=MODEL,
    description="Assembles the complete TPA claim report with line-wise bill breakdown and saves to GCS.",
    instruction=OUTPUT_INSTRUCTION,
    tools=[upload_report_to_gcs],
    output_key="final_report",
)


# ══════════════════════════════════════════════════════════════════════════════
# Root — SequentialAgent pipeline
# ══════════════════════════════════════════════════════════════════════════════

root_agent = SequentialAgent(
    name="TPAClaimOrchestrator",
    description=(
        "End-to-end TPA medical insurance claim pipeline: "
        "ingest PDFs → extract → classify → validate (content-driven) → "
        "medical review with RAG → decision with line-wise breakdown → report → GCS."
    ),
    sub_agents=[
        ingest_agent,
        extractor_agent,
        classifier_agent,
        validator_agent,
        medical_agent,
        decision_agent,
        report_agent,
        output_agent,
    ],
)


# ══════════════════════════════════════════════════════════════════════════════
# Deployment helpers
# ══════════════════════════════════════════════════════════════════════════════

def build_adk_app() -> AdkApp:
    return AdkApp(agent=root_agent, enable_tracing=True)


def deploy_to_agent_engine(
    project_id: str,
    location: str,
    staging_bucket: str,
    display_name: str = "TPA-Claim-Processor",
) -> Any:
    """
    Deploy the agent to Vertex AI Agent Engine.

    Returns the remote agent resource object.
    Print remote.resource_name to get the resource ID.
    """
    vertexai.init(project=project_id, location=location)
    client = vertexai.Client(project=project_id, location=location)
    app = build_adk_app()
    remote = client.agent_engines.create(
        agent=app,
        config={
            "display_name": display_name,
            "requirements": [
                "google-cloud-aiplatform[agent_engines,adk]>=1.112.0",
                
                "google-cloud-storage>=3.0.0",
                
                "pypdf>=6.0.0",
                "certifi>=2024.8.30",
            ],
            "staging_bucket": staging_bucket,
        },
    )
    print(f"[Deploy] Resource: {remote.resource_name}")
    return remote


# ══════════════════════════════════════════════════════════════════════════════
# Local run (Jupyter / Workbench)
# ══════════════════════════════════════════════════════════════════════════════

async def run_local(
    gcs_folder_uri: str,
    project_id: str,
    rag_corpus_resource: str,
    rag_location: str = "us-central1",
    user_id: str = "local-user",
) -> dict:
    """
    Run the full pipeline locally inside Vertex AI Workbench.

    Usage in Jupyter (event loop already running):
        from agent import run_local
        result = await run_local(
            gcs_folder_uri      = "gs://my-bucket/claims/CLAIM-001/",
            project_id          = "my-gcp-project",
            rag_corpus_resource = "projects/my-gcp-project/locations/us-central1/ragCorpora/123",
        )
        print(result["final_decision"])
        # Print line-wise breakdown:
        for row in result["bill_breakdown"]:
            print(f"{row['name']:40s}  claimed={row['claimed_amount']:>10,.2f}  approved={row['approved_amount']:>10,.2f}  diff={row['difference']:>10,.2f}  [{row['status']}]")
    """
    from tools.ssl_fix import apply_ssl_fix
    apply_ssl_fix()

    vertexai.init(project=project_id, location="us-central1")
    app = build_adk_app()
    session_id = f"claim-{uuid.uuid4().hex[:8]}"

    payload = json.dumps({
        "gcs_folder_uri":      gcs_folder_uri,
        "project_id":          project_id,
        "rag_corpus_resource": rag_corpus_resource,
        "rag_location":        rag_location,
    })

    print(f"\n{'='*65}")
    print(f"  TPA Claim Pipeline  |  Session: {session_id}")
    print(f"  Folder : {gcs_folder_uri}")
    print(f"{'='*65}\n")

    final_event = None
    async for event in app.async_stream_query(
        user_id=user_id,
        session_id=session_id,
        message=payload,
    ):
        author = event.get("author", "")
        for part in event.get("content", {}).get("parts", []):
            if "text" in part and part["text"].strip():
                print(f"  [{author}] {part['text'][:250]}")
        final_event = event

    if final_event:
        for part in final_event.get("content", {}).get("parts", []):
            if "text" in part:
                return parse_llm_json(part["text"], fallback={"error": "parse failed"})

    return {"error": "No final event received from pipeline"}


if __name__ == "__main__":
    import asyncio, sys
    if len(sys.argv) < 4:
        print("Usage: python agent.py <gcs_folder> <project_id> <rag_corpus_resource> [rag_location]")
        sys.exit(1)
    result = asyncio.run(run_local(
        gcs_folder_uri      = sys.argv[1],
        project_id          = sys.argv[2],
        rag_corpus_resource = sys.argv[3],
        rag_location        = sys.argv[4] if len(sys.argv) > 4 else "us-central1",
    ))
    print(json.dumps(result, indent=2))
