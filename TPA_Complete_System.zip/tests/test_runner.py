#!/usr/bin/env python3
# tests/test_runner.py
"""
Local test runner for MedVerify agents.
Tests the orchestrator with sample claim scenarios without deploying.

Usage:
    python tests/test_runner.py

Or test interactively:
    adk web   (then open http://localhost:8000)
"""
import asyncio
import os
import sys

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from medverify.agent import root_agent

APP_NAME = "medverify_tpa"
USER_ID  = "test_hospital_tpa"


async def run_test(test_name: str, message: str):
    """Run a single test scenario."""
    print(f"\n{'='*60}")
    print(f"TEST: {test_name}")
    print(f"{'='*60}")
    print(f"INPUT: {message[:200]}...")
    print(f"{'─'*60}")

    session_service = InMemorySessionService()
    session = await session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
    )

    runner = Runner(
        agent=root_agent,
        app_name=APP_NAME,
        session_service=session_service,
    )

    content = types.Content(
        role="user",
        parts=[types.Part(text=message)],
    )

    print("AGENT RESPONSE:")
    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session.id,
        new_message=content,
    ):
        if event.is_final_response():
            response = event.content.parts[0].text if event.content.parts else ""
            print(response[:2000])
            print(f"\n{'─'*60}")
            print(f"✓ Test '{test_name}' completed")
        else:
            # Show intermediate events (tool calls, sub-agent handoffs)
            if hasattr(event, 'content') and event.content:
                for part in event.content.parts:
                    if hasattr(part, 'function_call') and part.function_call:
                        print(f"  → Tool: {part.function_call.name}()")
                    elif hasattr(part, 'function_response') and part.function_response:
                        print(f"  ← Result: {part.function_response.name}")


async def main():
    """Run all test scenarios."""

    print("\n" + "="*60)
    print("  MedVerify AI — Agent System Test Runner")
    print("  Using: Google ADK + Gemini")
    print("="*60)

    # ── Test 1: Cashless Pre-Auth ─────────────────────────────────
    await run_test(
        "Cashless Pre-Authorization — Cardiac Surgery",
        """
        CASHLESS PRE-AUTHORIZATION REQUEST

        Patient: Rajesh Kumar
        Date of Birth: 14-Sep-1973 (Age: 52)
        Policy Number: HLTH-GRP-4521
        Member ID: MEM-002
        Hospital: Apollo Hospitals Chennai (Hospital ID: APOLLO-CHN-001)
        Hospital Tier: 1
        Admission Date: 10-Mar-2026 (Emergency)

        Provisional Diagnosis: Acute ST-Elevation Myocardial Infarction (STEMI)
        ICD-10 Code: I21.9

        Proposed Procedure: Emergency PTCA with Drug-Eluting Stent Placement
        CPT Code: 92928
        Estimated Cost: Rs. 4,69,000

        Planned Implant: Xience Sierra Drug-Eluting Stent
        Stent Quoted Price: Rs. 1,20,000 (NPPA cap reference: Rs. 65,000)

        Documents Submitted:
        1. Pre-authorization request form (signed by Dr. Priya Venkataraman)
        2. Admission note with provisional diagnosis STEMI
        3. ECG report showing ST elevation V1-V6
        4. Blood investigation report (Troponin I: 8.42 ng/mL - CRITICAL HIGH)
        5. Patient ID (Aadhaar) and Policy card copy

        Please process this emergency cashless pre-authorization request.
        """
    )

    # ── Test 2: Enhancement Request ──────────────────────────────
    await run_test(
        "Enhancement Request — Dialysis for AKI",
        """
        ENHANCEMENT REQUEST — Active Cashless Admission

        Original Session: SESS-2026-DEMO-001
        Original Authorization: AUTH-2026-047821 (PTCA+Stent, Day 0)

        Enhancement Type: Condition Escalation
        New Condition: Acute Kidney Injury (AKI) post-PTCA
        ICD-10 (new): N17.9

        Clinical Justification:
        Patient Rajesh Kumar (Day 3 post-PTCA) developed acute kidney injury.
        Serum Creatinine risen from 1.1 to 8.2 mg/dL. Urine output: 30ml/hr (oliguria).
        Blood culture: pending. Nephrology consultation done.
        Standard protocol for post-cardiac AKI: Renal Replacement Therapy (Dialysis).

        Proposed Treatment:
        - Haemodialysis: 6 sessions planned
        - Nephrology consultation: 3 visits

        New documents submitted:
        1. Nephrology consultation note with creatinine trend chart
        2. Dialysis prescription order
        3. Updated cost estimate: Rs. 65,500 additional

        Please process enhancement authorization.
        """
    )

    # ── Test 3: Reimbursement Claim ───────────────────────────────
    await run_test(
        "Reimbursement Claim — Non-Network Hospital",
        """
        REIMBURSEMENT CLAIM SUBMISSION

        This is a REIMBURSEMENT claim. Patient paid out of pocket.
        No prior cashless session exists.

        Patient: Meera Nair
        Date of Birth: 22-Jun-1991 (Age: 34)
        Policy Number: HLTH-IND-7823
        Member ID: MEM-IND-004

        Hospital: City Care Hospital, Baner Road, Pune
        Hospital ID: CITY-CARE-PUN-001
        Network Status: NON-NETWORK (reimbursement basis)

        Admission: 05-Feb-2026 (Emergency)
        Discharge: 09-Feb-2026 (4 days)

        Diagnosis: Acute Appendicitis with Perforation (ICD-10: K35.2)
        Procedure: Emergency Laparoscopic Appendicectomy + Peritoneal Lavage (CPT: 44960)

        Total Amount Paid: Rs. 2,67,388
        Payment: UPI Rs. 1,17,388 + NEFT Rs. 1,50,000 (receipts attached)

        Documents Submitted:
        1. Reimbursement claim form (signed)
        2. Discharge summary (Dr. Vikram Desai, City Care Hospital)
        3. Ultrasound report (perforated appendix confirmed)
        4. Blood reports (WBC 18,400, CRP 142 - acute infection)
        5. Operation theatre notes
        6. Daily progress notes (4 days)
        7. Final itemized hospital bill (PAID)
        8. Payment receipts (UPI + NEFT)
        9. Patient Aadhaar copy
        10. Policy card copy

        Bank details for settlement:
        Account: HDFC Bank, Aundh Pune
        IFSC: HDFC0001234

        Please process this reimbursement claim.
        """
    )

    print(f"\n{'='*60}")
    print("  All tests completed!")
    print("  Run 'adk web' to test interactively in browser.")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    asyncio.run(main())
