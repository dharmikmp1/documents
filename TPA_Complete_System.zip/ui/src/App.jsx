// ui/src/App.jsx
import { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, onSnapshot,
         doc, updateDoc, query, orderBy, serverTimestamp } from "firebase/firestore";
import ClaimList   from "./components/ClaimList";
import ClaimDetail from "./components/ClaimDetail";
import Header      from "./components/Header";
import "./App.css";

// Firebase config — fill from Firebase Console → Project Settings
const firebaseConfig = {
  apiKey:            process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain:        process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  projectId:         process.env.REACT_APP_GCP_PROJECT,
  storageBucket:     process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId:             process.env.REACT_APP_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
const db  = getFirestore(app);

export default function App() {
  const [claims,       setClaims]       = useState([]);
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [filter,       setFilter]       = useState("PENDING");
  const [loading,      setLoading]      = useState(true);
  const [doctorName,   setDoctorName]   = useState(
    localStorage.getItem("doctorName") || "Dr. Physician"
  );

  // ── Real-time Firestore listener ─────────────────────────────
  useEffect(() => {
    const q = query(
      collection(db, "claim_sessions"),
      orderBy("triggered_at", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setClaims(data);
      setLoading(false);

      // Auto-refresh selected claim if it changed
      if (selectedClaim) {
        const updated = data.find(c => c.claim_id === selectedClaim.claim_id);
        if (updated) setSelectedClaim(updated);
      }
    });

    return () => unsubscribe();
  }, [selectedClaim?.claim_id]);

  // ── Physician approval action ─────────────────────────────────
  const handleDecision = async (claimId, decision, comments) => {
    try {
      const docRef = doc(db, "claim_sessions", claimId);
      await updateDoc(docRef, {
        status:                decision === "APPROVE"  ? "APPROVED"
                             : decision === "PARTIAL"  ? "PARTIAL_APPROVED"
                             : decision === "REJECT"   ? "DECLINED"
                             : "QUERY_SENT",
        physician_decision:    decision,
        physician_name:        doctorName,
        physician_comments:    comments,
        physician_reviewed_at: serverTimestamp(),
        pending_review:        false,
        ready_for_physician:   false,
        last_updated:          serverTimestamp(),
      });

      // Move to next pending claim
      const pending = filteredClaims.filter(
        c => c.claim_id !== claimId && isPending(c)
      );
      setSelectedClaim(pending[0] || null);

    } catch (err) {
      console.error("Decision failed:", err);
      alert("Failed to save decision. Check console.");
    }
  };

  // ── Filtering ─────────────────────────────────────────────────
  const isPending = (c) =>
    c.ready_for_physician && !c.physician_decision;

  const filteredClaims = claims.filter(c => {
    if (filter === "PENDING")    return isPending(c);
    if (filter === "PROCESSING") return c.agent_processing;
    if (filter === "APPROVED")   return c.physician_decision === "APPROVE";
    if (filter === "PARTIAL")    return c.physician_decision === "PARTIAL";
    if (filter === "DECLINED")   return c.physician_decision === "REJECT";
    if (filter === "ALL")        return true;
    return true;
  });

  const counts = {
    PENDING:    claims.filter(isPending).length,
    PROCESSING: claims.filter(c => c.agent_processing).length,
    APPROVED:   claims.filter(c => c.physician_decision === "APPROVE").length,
    PARTIAL:    claims.filter(c => c.physician_decision === "PARTIAL").length,
    DECLINED:   claims.filter(c => c.physician_decision === "REJECT").length,
    ALL:        claims.length,
  };

  return (
    <div className="app">
      <Header
        doctorName={doctorName}
        onDoctorNameChange={(n) => {
          setDoctorName(n);
          localStorage.setItem("doctorName", n);
        }}
        pendingCount={counts.PENDING}
        processingCount={counts.PROCESSING}
      />

      <div className="main-layout">
        {/* Left: Claim list */}
        <aside className="sidebar">
          {/* Filter tabs */}
          <div className="filter-tabs">
            {[
              { key: "PENDING",    label: "Pending Review" },
              { key: "PROCESSING", label: "Processing"     },
              { key: "APPROVED",   label: "Approved"       },
              { key: "PARTIAL",    label: "Partial"        },
              { key: "DECLINED",   label: "Declined"       },
              { key: "ALL",        label: "All Claims"     },
            ].map(({ key, label }) => (
              <button
                key={key}
                className={`tab ${filter === key ? "active" : ""} tab-${key.toLowerCase()}`}
                onClick={() => setFilter(key)}
              >
                {label}
                {counts[key] > 0 && (
                  <span className="badge">{counts[key]}</span>
                )}
              </button>
            ))}
          </div>

          <ClaimList
            claims={filteredClaims}
            selectedId={selectedClaim?.claim_id}
            onSelect={setSelectedClaim}
            loading={loading}
          />
        </aside>

        {/* Right: Claim detail */}
        <main className="detail-pane">
          {selectedClaim ? (
            <ClaimDetail
              claim={selectedClaim}
              doctorName={doctorName}
              onDecision={handleDecision}
            />
          ) : (
            <div className="empty-state">
              <div className="empty-icon">⚕</div>
              <h2>Select a claim to review</h2>
              <p>
                {counts.PENDING > 0
                  ? `${counts.PENDING} claim${counts.PENDING > 1 ? "s" : ""} pending your review`
                  : "No claims pending review"}
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
