// ui/src/components/Header.jsx
import { useState } from "react";

export default function Header({
  doctorName, onDoctorNameChange, pendingCount, processingCount
}) {
  const [editing, setEditing] = useState(false);
  const [draft,   setDraft]   = useState(doctorName);

  return (
    <header className="app-header">
      <div className="header-left">
        <span className="logo">⬡</span>
        <div>
          <h1>MedVerify AI</h1>
          <p>Physician Review Portal</p>
        </div>
      </div>

      <div className="header-center">
        {pendingCount > 0 && (
          <div className="header-alert pending">
            {pendingCount} claim{pendingCount > 1 ? "s" : ""} pending review
          </div>
        )}
        {processingCount > 0 && (
          <div className="header-alert processing">
            <span className="spinner-sm">⟳</span>
            {processingCount} processing
          </div>
        )}
      </div>

      <div className="header-right">
        {editing ? (
          <div className="doctor-edit">
            <input
              value={draft}
              onChange={e => setDraft(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter") {
                  onDoctorNameChange(draft);
                  setEditing(false);
                }
                if (e.key === "Escape") setEditing(false);
              }}
              autoFocus
            />
            <button onClick={() => { onDoctorNameChange(draft); setEditing(false); }}>
              Save
            </button>
          </div>
        ) : (
          <button className="doctor-name" onClick={() => setEditing(true)}>
            ⚕ {doctorName}
          </button>
        )}
      </div>
    </header>
  );
}
