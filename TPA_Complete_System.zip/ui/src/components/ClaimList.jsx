// ui/src/components/ClaimList.jsx
export default function ClaimList({ claims, selectedId, onSelect, loading }) {
  if (loading) return <div className="list-loading">Loading claims...</div>;
  if (!claims.length) return <div className="list-empty">No claims found</div>;

  const statusIcon = (c) => {
    if (c.agent_processing)          return { icon: "⟳", cls: "processing" };
    if (c.status === "TRIGGER_RECEIVED") return { icon: "↓", cls: "received" };
    if (c.physician_decision === "APPROVE")  return { icon: "✓", cls: "approved" };
    if (c.physician_decision === "PARTIAL")  return { icon: "◑", cls: "partial"  };
    if (c.physician_decision === "REJECT")   return { icon: "✗", cls: "declined" };
    if (c.ready_for_physician)       return { icon: "●", cls: "pending"    };
    return { icon: "○", cls: "unknown" };
  };

  const claimTypeLabel = (t) => ({
    cashless_preauth: "Cashless Pre-Auth",
    enhancement:      "Enhancement",
    cashless_final:   "Final Settlement",
    reimbursement:    "Reimbursement",
  }[t] || t || "—");

  return (
    <div className="claim-list">
      {claims.map(claim => {
        const { icon, cls } = statusIcon(claim);
        const isSelected = claim.claim_id === selectedId;
        return (
          <div
            key={claim.claim_id}
            className={`claim-row ${isSelected ? "selected" : ""} ${cls}`}
            onClick={() => onSelect(claim)}
          >
            <div className="claim-row-top">
              <span className={`status-dot ${cls}`}>{icon}</span>
              <span className="claim-id">{claim.claim_id}</span>
              <span className={`claim-type-badge ${cls}`}>
                {claimTypeLabel(claim.claim_type)}
              </span>
            </div>
            <div className="claim-row-patient">{claim.patient_name || "—"}</div>
            <div className="claim-row-hospital">
              {claim.hospital_name || "—"} · {claim.diagnosis_icd10 || ""}
            </div>
            <div className="claim-row-time">
              {claim.triggered_at
                ? new Date(claim.triggered_at).toLocaleString("en-IN")
                : "—"}
            </div>
          </div>
        );
      })}
    </div>
  );
}
