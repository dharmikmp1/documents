// ui/src/components/ClaimDetail.jsx
import { useState } from "react";

export default function ClaimDetail({ claim, doctorName, onDecision }) {
  const [comments,  setComments]  = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("summary");

  const handleDecision = async (decision) => {
    if (submitting) return;
    const msg = {
      APPROVE:  "Approve this claim?",
      PARTIAL:  "Approve partial amount?",
      REJECT:   "Decline this claim?",
      QUERY:    "Send query to hospital?",
    }[decision];
    if (!window.confirm(msg)) return;

    setSubmitting(true);
    await onDecision(claim.claim_id, decision, comments);
    setSubmitting(false);
    setComments("");
  };

  const alreadyDecided = !!claim.physician_decision;
  const isProcessing   = claim.agent_processing;

  // Parse AI response sections
  const aiResponse = claim.ai_response || "";
  const sections   = parseAIResponse(aiResponse);

  const claimTypeLabel = {
    cashless_preauth: "Cashless Pre-Authorization",
    enhancement:      "Enhancement Request",
    cashless_final:   "Final Settlement",
    reimbursement:    "Reimbursement Claim",
  }[claim.claim_type] || claim.claim_type;

  return (
    <div className="claim-detail">

      {/* ── Header ───────────────────────────────── */}
      <div className="detail-header">
        <div className="detail-header-left">
          <div className="detail-claim-id">{claim.claim_id}</div>
          <div className="detail-type-badge">{claimTypeLabel}</div>
        </div>
        <div className="detail-header-right">
          <StatusBadge claim={claim} />
        </div>
      </div>

      {/* ── Patient & Policy Strip ────────────────── */}
      <div className="info-strip">
        <InfoPill label="Patient"  value={claim.patient_name}  />
        <InfoPill label="Policy"   value={claim.policy_id}     />
        <InfoPill label="Hospital" value={claim.hospital_name} />
        <InfoPill label="ICD-10"   value={claim.diagnosis_icd10} />
        <InfoPill label="Tier"     value={`Tier ${claim.hospital_tier}`} />
        <InfoPill
          label="Submitted"
          value={claim.triggered_at
            ? new Date(claim.triggered_at).toLocaleString("en-IN")
            : "—"}
        />
      </div>

      {/* ── Processing indicator ─────────────────── */}
      {isProcessing && (
        <div className="processing-banner">
          <span className="spinner">⟳</span>
          AI agents are processing this claim… Live updates will appear below.
        </div>
      )}

      {/* ── Already decided banner ───────────────── */}
      {alreadyDecided && (
        <div className={`decision-banner ${claim.physician_decision.toLowerCase()}`}>
          <strong>{decisionLabel(claim.physician_decision)}</strong>
          {" by "}{claim.physician_name}
          {claim.physician_reviewed_at
            ? ` · ${new Date(claim.physician_reviewed_at.toDate()).toLocaleString("en-IN")}`
            : ""}
          {claim.physician_comments && (
            <div className="decision-comments">"{claim.physician_comments}"</div>
          )}
        </div>
      )}

      {/* ── Tabs ─────────────────────────────────── */}
      <div className="tabs">
        {[
          { key: "summary",   label: "AI Analysis"   },
          { key: "financial", label: "Financials"     },
          { key: "anomalies", label: "Anomaly Flags"  },
          { key: "raw",       label: "Full AI Output" },
        ].map(({ key, label }) => (
          <button
            key={key}
            className={`tab-btn ${activeTab === key ? "active" : ""}`}
            onClick={() => setActiveTab(key)}
          >
            {label}
            {key === "anomalies" && sections.highAnomalies > 0 && (
              <span className="tab-alert">{sections.highAnomalies}</span>
            )}
          </button>
        ))}
      </div>

      <div className="tab-content">

        {/* Summary Tab */}
        {activeTab === "summary" && (
          <div className="tab-summary">
            {sections.recommendation && (
              <div className={`ai-recommendation ${sections.recommendation.toLowerCase().replace(" ", "_")}`}>
                <strong>AI Recommendation:</strong> {sections.recommendation}
                {sections.confidence && (
                  <span className="confidence">
                    Confidence: {sections.confidence}
                  </span>
                )}
              </div>
            )}
            {sections.treatmentSummary && (
              <div className="section-block">
                <h4>Treatment Summary</h4>
                <p>{sections.treatmentSummary}</p>
              </div>
            )}
            {sections.claimSnapshot && (
              <div className="section-block">
                <h4>Claim Snapshot</h4>
                <pre className="snapshot">{sections.claimSnapshot}</pre>
              </div>
            )}
            {!sections.recommendation && !sections.treatmentSummary && (
              <pre className="raw-output">{aiResponse || "No AI output yet."}</pre>
            )}
          </div>
        )}

        {/* Financials Tab */}
        {activeTab === "financial" && (
          <div className="tab-financial">
            {sections.financials ? (
              <pre className="financial-block">{sections.financials}</pre>
            ) : (
              <p className="no-data">Financial summary not yet available.</p>
            )}
          </div>
        )}

        {/* Anomalies Tab */}
        {activeTab === "anomalies" && (
          <div className="tab-anomalies">
            {sections.anomalies.length > 0 ? (
              sections.anomalies.map((a, i) => (
                <div key={i} className={`anomaly-card ${a.severity.toLowerCase()}`}>
                  <div className="anomaly-header">
                    <span className={`severity-badge ${a.severity.toLowerCase()}`}>
                      {a.severity}
                    </span>
                    <span className="anomaly-category">{a.category}</span>
                  </div>
                  <div className="anomaly-desc">{a.description}</div>
                  {a.action && (
                    <div className="anomaly-action">
                      Recommended action: {a.action}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p className="no-data">
                {isProcessing
                  ? "Anomaly detection in progress…"
                  : "No anomalies flagged."}
              </p>
            )}
          </div>
        )}

        {/* Raw Output Tab */}
        {activeTab === "raw" && (
          <div className="tab-raw">
            <pre className="raw-output">
              {aiResponse || "No AI output yet."}
            </pre>
          </div>
        )}
      </div>

      {/* ── Decision Panel ────────────────────────── */}
      {!alreadyDecided && !isProcessing && claim.ready_for_physician && (
        <div className="decision-panel">
          <h3>Physician Decision</h3>
          <div className="comments-row">
            <textarea
              className="comments-input"
              placeholder="Add comments or query details (optional)…"
              value={comments}
              onChange={e => setComments(e.target.value)}
              rows={3}
            />
          </div>
          <div className="decision-buttons">
            <button
              className="btn-approve"
              onClick={() => handleDecision("APPROVE")}
              disabled={submitting}
            >
              ✓ Approve
            </button>
            <button
              className="btn-partial"
              onClick={() => handleDecision("PARTIAL")}
              disabled={submitting}
            >
              ◑ Partial Approve
            </button>
            <button
              className="btn-query"
              onClick={() => handleDecision("QUERY")}
              disabled={submitting}
            >
              ? Send Query
            </button>
            <button
              className="btn-reject"
              onClick={() => handleDecision("REJECT")}
              disabled={submitting}
            >
              ✗ Decline
            </button>
          </div>
          <div className="decision-footer">
            Approving as: <strong>{doctorName}</strong>
          </div>
        </div>
      )}

    </div>
  );
}

// ── Helper components ────────────────────────────────────────────
function InfoPill({ label, value }) {
  return (
    <div className="info-pill">
      <span className="pill-label">{label}</span>
      <span className="pill-value">{value || "—"}</span>
    </div>
  );
}

function StatusBadge({ claim }) {
  const configs = {
    APPROVED:              { label: "Approved",        cls: "approved"   },
    PARTIAL_APPROVED:      { label: "Partial Approved",cls: "partial"    },
    DECLINED:              { label: "Declined",        cls: "declined"   },
    PENDING_PHYSICIAN_REVIEW:{ label: "Pending Review",cls: "pending"    },
    AGENT_PROCESSING:      { label: "AI Processing",   cls: "processing" },
    TRIGGER_RECEIVED:      { label: "Received",        cls: "received"   },
    AGENT_ERROR:           { label: "Error",           cls: "error"      },
  };
  const { label, cls } = configs[claim.status] || { label: claim.status, cls: "unknown" };
  return <span className={`status-badge-large ${cls}`}>{label}</span>;
}

// ── Parse AI response into sections ─────────────────────────────
function parseAIResponse(text) {
  const result = {
    recommendation:  "",
    confidence:      "",
    treatmentSummary:"",
    claimSnapshot:   "",
    financials:      "",
    anomalies:       [],
    highAnomalies:   0,
  };
  if (!text) return result;

  // Recommendation
  const recMatch = text.match(/FC4_RECOMMENDATION:\s*(.+)/i)
    || text.match(/FINAL_DECISION:\s*(.+)/i)
    || text.match(/RECOMMENDATION[:\s]+(\w+[\w\s]+)/i);
  if (recMatch) result.recommendation = recMatch[1].trim();

  // Confidence
  const confMatch = text.match(/FC4_CONFIDENCE:\s*([\d.]+)/i)
    || text.match(/CONFIDENCE[:\s]+([\d.]+)/i);
  if (confMatch) result.confidence = `${Math.round(confMatch[1] * 100)}%`;

  // Treatment summary
  const treatStart = text.indexOf("TREATMENT SUMMARY");
  const treatEnd   = text.indexOf("FINANCIAL SUMMARY");
  if (treatStart > -1 && treatEnd > treatStart) {
    result.treatmentSummary = text
      .slice(treatStart + 17, treatEnd)
      .replace(/[-=─]+/g, "")
      .trim();
  }

  // Financial summary
  const finStart = text.indexOf("FINANCIAL SUMMARY");
  const finEnd   = text.indexOf("ANOMALY FLAGS", finStart);
  if (finStart > -1) {
    result.financials = text
      .slice(finStart, finEnd > finStart ? finEnd : finStart + 800)
      .trim();
  }

  // Anomalies — parse structured anomaly blocks
  const anomalyRegex =
    /SEVERITY:\s*(HIGH|MEDIUM|LOW)[^\n]*\n.*?CATEGORY:\s*(\w+).*?\n.*?DESCRIPTION:\s*([^\n]+)/gis;
  let match;
  while ((match = anomalyRegex.exec(text)) !== null) {
    const severity = match[1].toUpperCase();
    result.anomalies.push({
      severity,
      category:    match[2],
      description: match[3].trim(),
      action:      "",
    });
    if (severity === "HIGH") result.highAnomalies++;
  }

  return result;
}

function decisionLabel(d) {
  return {
    APPROVE:  "✓ Approved",
    PARTIAL:  "◑ Partially Approved",
    REJECT:   "✗ Declined",
    QUERY:    "? Query Sent",
  }[d] || d;
}
