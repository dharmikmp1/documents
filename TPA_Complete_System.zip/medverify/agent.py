# medverify/agent.py  (UPDATED — with PDF ingestion)
"""
MedVerify AI — Master Orchestrator
PDFs flow: upload to GCS → read_all_claim_documents() → extract text → agents process text
"""
from __future__ import annotations
import os

from google.adk.agents import LlmAgent

from medverify.tools.policy_tools  import get_session_state, save_session_state
from medverify.tools.pdf_tools     import (
    read_all_claim_documents,
    read_single_pdf_from_gcs_uri,
    list_claim_documents,
    upload_pdf_to_gcs,
)
from medverify.pipelines.cashless    import cashless_pipeline
from medverify.pipelines.enhancement import enhancement_pipeline
from medverify.pipelines.final_claim import final_claim_pipeline

MODEL = os.getenv("GEMINI_PRO_MODEL", "gemini-2.0-flash-001")

root_agent = LlmAgent(
    name="MedVerifyOrchestrator",
    model=MODEL,
    description=(
        "MedVerify AI — Intelligent health insurance TPA replacement system. "
        "Accepts claim requests with PDF document references (GCS URIs or claim_id). "
        "Reads and understands PDFs using Gemini multimodal, then routes to "
        "the correct processing pipeline."
    ),
    instruction="""
You are the MedVerify AI Master Orchestrator for health insurance claim processing.

HOW PDF INPUT WORKS
===================

Users provide PDFs in one of two ways:

WAY 1 — CLAIM ID:
User provides a claim_id. PDFs already uploaded to GCS under
gs://bucket/claims/{claim_id}/

Call: read_all_claim_documents(claim_id=<id>)
This reads ALL PDFs, extracts content using Gemini multimodal,
and returns structured text from every document.

WAY 2 — GCS URI(s):
User provides specific GCS URIs like:
gs://bucket/claims/CLM-001/admission_note.pdf

Call: read_single_pdf_from_gcs_uri(gcs_uri=<uri>) for each URI.

ALWAYS read documents FIRST before routing to any pipeline.
The extracted content tells you: claim type, patient details,
diagnosis, documents present, and quality.

ROUTING LOGIC
=============

After reading documents:

Pre-auth form present + no discharge summary + patient admitted
→ CASHLESS PRE-AUTH → delegate to CashlessPreAuthPipeline

Enhancement requested + session_id provided
→ ENHANCEMENT → load session + delegate to EnhancementPipeline

Discharge summary present + session_id provided
→ CASHLESS FINAL → delegate to FinalClaimPipeline

Discharge summary + PAID receipts + no session_id
→ REIMBURSEMENT → delegate to FinalClaimPipeline

When delegating, always provide:
- claim_id, claim_type, patient name, policy, hospital
- ICD-10 diagnosis code, procedures
- List of documents found and their quality
- Full extracted text from all documents

IF NO INPUT PROVIDED
====================
Ask: "Please provide a claim_id or GCS URI(s) of the PDF documents."
""",
    tools=[
        read_all_claim_documents,
        read_single_pdf_from_gcs_uri,
        list_claim_documents,
        get_session_state,
        save_session_state,
    ],
    sub_agents=[
        cashless_pipeline,
        enhancement_pipeline,
        final_claim_pipeline,
    ],
)
