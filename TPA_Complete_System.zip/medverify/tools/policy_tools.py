# medverify/tools/policy_tools.py
"""
Policy database tool functions.
These are called by agents as tools.
In production: replace mock data with real DB queries.
"""
from __future__ import annotations
import os
from typing import Any
from google.cloud import firestore


PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT", "")
FIRESTORE_DB = os.getenv("FIRESTORE_DATABASE", "(default)")


# ── Policy Lookup ─────────────────────────────────────────────────
def check_policy_status(policy_id: str, admission_date: str) -> dict[str, Any]:
    """
    Check if health insurance policy is active on date of admission.

    Args:
        policy_id: Insurance policy number e.g. HLTH-GRP-4521
        admission_date: Date of admission in DD-Mon-YYYY format

    Returns:
        dict with policy status, annual limit, and validity details
    """
    # In production: query policy management system via API
    # Mock data for prototype demonstration
    POLICIES = {
        "HLTH-GRP-4521": {
            "status": "ACTIVE",
            "member_name": "Rajesh Kumar",
            "sum_insured": 1000000,
            "policy_start": "2024-01-01",
            "renewal_date": "2026-12-31",
            "premium_paid": True,
            "claims_settled_ytd": 0,
            "remaining_limit": 1000000,
        },
        "HLTH-IND-7823": {
            "status": "ACTIVE",
            "member_name": "Meera Nair",
            "sum_insured": 500000,
            "policy_start": "2023-04-01",
            "renewal_date": "2026-03-31",
            "premium_paid": True,
            "claims_settled_ytd": 0,
            "remaining_limit": 500000,
        },
    }

    policy = POLICIES.get(policy_id)
    if not policy:
        return {
            "status": "NOT_FOUND",
            "policy_id": policy_id,
            "message": f"Policy {policy_id} not found in system",
        }

    return {
        "status": "SUCCESS",
        "policy_id": policy_id,
        "policy_status": policy["status"],
        "member_name": policy["member_name"],
        "sum_insured": policy["sum_insured"],
        "remaining_limit": policy["remaining_limit"],
        "policy_start": policy["policy_start"],
        "renewal_date": policy["renewal_date"],
        "premium_paid": policy["premium_paid"],
        "active": policy["status"] == "ACTIVE" and policy["premium_paid"],
    }


def check_hospital_network(hospital_id: str) -> dict[str, Any]:
    """
    Check if hospital is in the insurer's network and return tier.

    Args:
        hospital_id: Hospital identifier e.g. APOLLO-CHN-001

    Returns:
        dict with network status, tier, and hospital details
    """
    NETWORK = {
        "APOLLO-CHN-001": {
            "name": "Apollo Hospitals, Chennai",
            "tier": 1,
            "in_network": True,
            "city": "Chennai",
            "specialties": ["Cardiology", "Oncology", "Transplant"],
            "cath_lab": True,
            "ptca_24x7": True,
            "blacklisted": False,
        },
        "FORTIS-DEL-001": {
            "name": "Fortis Escorts, Delhi",
            "tier": 1,
            "in_network": True,
            "city": "Delhi",
            "specialties": ["Cardiology", "Transplant"],
            "blacklisted": False,
        },
        "RUBY-PUN-001": {
            "name": "Ruby Hall Clinic, Pune",
            "tier": 2,
            "in_network": True,
            "city": "Pune",
            "specialties": ["Cardiology", "Orthopaedics"],
            "blacklisted": False,
        },
        "CITY-CARE-PUN-001": {
            "name": "City Care Hospital, Pune",
            "tier": 2,
            "in_network": False,  # Non-network
            "city": "Pune",
            "blacklisted": False,
        },
        "SUNRISE-MUM-BL": {
            "name": "Sunrise Multi-Speciality Hospital, Mumbai",
            "tier": 1,
            "in_network": False,
            "blacklisted": True,
            "blacklist_reason": "Fraudulent billing — phantom surgeries",
            "blacklisted_since": "2024-06-15",
        },
    }

    hospital = NETWORK.get(hospital_id, {
        "name": hospital_id,
        "tier": 2,
        "in_network": False,
        "blacklisted": False,
    })

    return {
        "status": "SUCCESS",
        "hospital_id": hospital_id,
        "hospital_name": hospital.get("name", hospital_id),
        "tier": hospital.get("tier", 2),
        "in_network": hospital.get("in_network", False),
        "network_status": "IN_NETWORK" if hospital.get("in_network") else "OUT_OF_NETWORK",
        "blacklisted": hospital.get("blacklisted", False),
        "blacklist_reason": hospital.get("blacklist_reason"),
        "cashless_eligible": hospital.get("in_network") and not hospital.get("blacklisted"),
        "reimbursement_copay": 0 if hospital.get("in_network") else 10,
    }


def check_waiting_period(policy_id: str, diagnosis_icd10: str) -> dict[str, Any]:
    """
    Check if diagnosis falls within any policy waiting period.

    Args:
        policy_id: Insurance policy number
        diagnosis_icd10: ICD-10 diagnosis code e.g. I21.9

    Returns:
        dict with waiting period status and applicable clause
    """
    # ICD-10 codes that fall under specific waiting periods
    PED_CONDITIONS = {
        "E11": "Type 2 Diabetes Mellitus (PED — 48 months)",
        "I10": "Hypertension (PED — 48 months)",
        "J45": "Asthma (PED — 48 months)",
        "N18": "Chronic Kidney Disease (PED — 48 months)",
    }

    SPECIFIC_WAITING = {
        "H26": "Cataract (24 months specific waiting)",
        "K40": "Inguinal Hernia (24 months specific waiting)",
        "M17": "Knee Osteoarthritis (24 months specific waiting)",
        "K80": "Gallstones (24 months specific waiting)",
    }

    # Check prefix match
    diag_prefix = diagnosis_icd10[:3]
    diag_prefix_2 = diagnosis_icd10[:2]

    ped = PED_CONDITIONS.get(diag_prefix_2)
    specific = SPECIFIC_WAITING.get(diag_prefix)

    # Acute emergency events are covered even during PED waiting
    EMERGENCY_CODES = ["I21", "I22", "I24", "J18", "N17", "K35", "S"]
    is_emergency = any(diagnosis_icd10.startswith(e) for e in EMERGENCY_CODES)

    if is_emergency:
        return {
            "status": "SUCCESS",
            "waiting_status": "CLEARED",
            "reason": "Acute emergency — waiting period does not apply per policy Section 7.1",
            "covered": True,
        }

    if ped:
        return {
            "status": "SUCCESS",
            "waiting_status": "PED_APPLICABLE",
            "condition": ped,
            "waiting_months": 48,
            "covered": False,
            "note": "PED waiting period applies. Check if 48 months have elapsed since policy start.",
        }

    if specific:
        return {
            "status": "SUCCESS",
            "waiting_status": "SPECIFIC_WAITING",
            "condition": specific,
            "waiting_months": 24,
            "covered": False,
            "note": "Specific illness waiting period applies.",
        }

    return {
        "status": "SUCCESS",
        "waiting_status": "CLEARED",
        "covered": True,
        "reason": "No waiting period applicable for this diagnosis",
    }


def get_annual_limit_status(policy_id: str) -> dict[str, Any]:
    """
    Get remaining annual limit and utilisation for a policy.

    Args:
        policy_id: Insurance policy number

    Returns:
        dict with sum insured, used amount, remaining limit
    """
    # In production: query from claims management system
    LIMITS = {
        "HLTH-GRP-4521": {"sum_insured": 1000000, "used": 0},
        "HLTH-IND-7823":  {"sum_insured": 500000,  "used": 0},
    }

    data = LIMITS.get(policy_id, {"sum_insured": 500000, "used": 0})
    remaining = data["sum_insured"] - data["used"]

    return {
        "status": "SUCCESS",
        "policy_id": policy_id,
        "annual_limit": data["sum_insured"],
        "used_amount": data["used"],
        "remaining_limit": remaining,
        "utilization_pct": round(data["used"] / data["sum_insured"] * 100, 1),
        "limit_status": "EXHAUSTED" if remaining == 0 else (
            "ALERT" if remaining < data["sum_insured"] * 0.15 else
            "WARN" if remaining < data["sum_insured"] * 0.30 else "OK"
        ),
    }


def check_fraud_flags(policy_id: str, hospital_id: str) -> dict[str, Any]:
    """
    Check for active fraud flags on policy or hospital.

    Args:
        policy_id: Insurance policy number
        hospital_id: Hospital identifier

    Returns:
        dict with fraud flag status and risk level
    """
    FRAUD_FLAGS = {
        "SUNRISE-MUM-BL": {
            "flagged": True,
            "type": "BLACKLISTED_HOSPITAL",
            "reason": "Fraudulent billing — phantom surgeries",
            "severity": "HIGH",
        },
    }

    hospital_flag = FRAUD_FLAGS.get(hospital_id, {})
    policy_flag = FRAUD_FLAGS.get(policy_id, {})

    flags = []
    if hospital_flag.get("flagged"):
        flags.append(hospital_flag)
    if policy_flag.get("flagged"):
        flags.append(policy_flag)

    return {
        "status": "SUCCESS",
        "fraud_flags": flags,
        "flagged": len(flags) > 0,
        "risk_level": "HIGH" if flags else "LOW",
        "action_required": "BLOCK_CASHLESS" if flags else "NONE",
    }


def get_sub_limits(item_type: str, hospital_tier: int = 1) -> dict[str, Any]:
    """
    Get applicable sub-limits for a specific item type and hospital tier.

    Args:
        item_type: Type of item e.g. ICU, dialysis, room, ambulance
        hospital_tier: Hospital tier 1, 2, or 3

    Returns:
        dict with applicable sub-limit amount and unit
    """
    SUB_LIMITS = {
        "ICU": {
            1: {"cap": 15000, "unit": "per_day", "max_days": None},
            2: {"cap": 10000, "unit": "per_day", "max_days": None},
            3: {"cap":  7500, "unit": "per_day", "max_days": None},
        },
        "room": {
            1: {"cap": 5000, "unit": "per_day"},
            2: {"cap": 3000, "unit": "per_day"},
            3: {"cap": 1500, "unit": "per_day"},
        },
        "dialysis": {
            1: {"cap": 8000, "unit": "per_session", "max_sessions_per_year": 15},
            2: {"cap": 6000, "unit": "per_session", "max_sessions_per_year": 15},
            3: {"cap": 5000, "unit": "per_session", "max_sessions_per_year": 15},
        },
        "ambulance": {
            1: {"cap": 2000, "unit": "per_episode"},
            2: {"cap": 2000, "unit": "per_episode"},
            3: {"cap": 2000, "unit": "per_episode"},
        },
        "physiotherapy": {
            1: {"cap": 500, "unit": "per_session", "max_sessions_per_year": 20},
            2: {"cap": 500, "unit": "per_session", "max_sessions_per_year": 20},
            3: {"cap": 500, "unit": "per_session", "max_sessions_per_year": 20},
        },
    }

    item_key = item_type.lower().replace(" ", "_").replace("-", "_")
    # Fuzzy match
    for key in SUB_LIMITS:
        if key.lower() in item_key or item_key in key.lower():
            tier_limits = SUB_LIMITS[key].get(hospital_tier, SUB_LIMITS[key][1])
            return {
                "status": "SUCCESS",
                "item": item_type,
                "sub_limit_found": True,
                "cap": tier_limits["cap"],
                "unit": tier_limits["unit"],
                "hospital_tier": hospital_tier,
                **{k: v for k, v in tier_limits.items()
                   if k not in ("cap", "unit")},
            }

    return {
        "status": "SUCCESS",
        "item": item_type,
        "sub_limit_found": False,
        "message": f"No specific sub-limit for {item_type} — covered at actuals",
    }


def check_nppa_cap(device_name: str, billed_price: int) -> dict[str, Any]:
    """
    Check if medical device/implant is within NPPA price cap.

    Args:
        device_name: Name of device/implant e.g. Drug Eluting Stent
        billed_price: Amount billed by hospital in rupees

    Returns:
        dict with NPPA cap, excess amount, and flag status
    """
    NPPA_CAPS = {
        "drug eluting stent":     65000,
        "des":                    65000,
        "bare metal stent":       35000,
        "bms":                    35000,
        "knee implant":           54549,
        "tkr":                    54549,
        "hip implant":            56000,
        "thr":                    56000,
        "pacemaker single":      145000,
        "pacemaker dual":        245000,
        "cardiac valve":          22000,
        "intraocular lens":        1500,
        "iol monofocal":           1500,
        "iol multifocal":          6000,
    }

    device_lower = device_name.lower()
    cap = None
    matched_name = None

    for device_key, price_cap in NPPA_CAPS.items():
        if any(word in device_lower for word in device_key.split()):
            cap = price_cap
            matched_name = device_key
            break

    if cap is None:
        return {
            "status": "SUCCESS",
            "device": device_name,
            "nppa_applicable": False,
            "within_cap": True,
            "covered_amount": billed_price,
            "message": "No NPPA cap for this device — covered at actuals",
        }

    within_cap = billed_price <= cap
    excess = max(0, billed_price - cap)

    return {
        "status": "SUCCESS",
        "device": device_name,
        "matched_device": matched_name,
        "nppa_cap": cap,
        "billed_price": billed_price,
        "covered_amount": cap,
        "excess_amount": excess,
        "nppa_applicable": True,
        "within_cap": within_cap,
        "flagged": not within_cap,
        "patient_liability": excess,
        "flag_message": (
            f"Device billed Rs.{billed_price:,} exceeds NPPA cap "
            f"Rs.{cap:,}. Excess Rs.{excess:,} is patient co-payment."
        ) if not within_cap else None,
    }


# ── Firestore Session Tools ───────────────────────────────────────
def save_session_state(session_id: str, state_data: dict[str, Any]) -> dict[str, Any]:
    """
    Save or update claim session state in Firestore.

    Args:
        session_id: Unique session identifier
        state_data: Dictionary of state fields to save/update

    Returns:
        dict with save confirmation
    """
    try:
        db = firestore.Client(project=PROJECT, database=FIRESTORE_DB)
        doc_ref = db.collection("claim_sessions").document(session_id)

        import datetime
        state_data["last_updated"] = datetime.datetime.utcnow().isoformat()
        doc_ref.set(state_data, merge=True)

        return {
            "status": "SUCCESS",
            "session_id": session_id,
            "saved": True,
            "message": f"Session {session_id} updated successfully",
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "session_id": session_id,
            "saved": False,
            "error": str(e),
        }


def get_session_state(session_id: str) -> dict[str, Any]:
    """
    Retrieve claim session state from Firestore.

    Args:
        session_id: Unique session identifier

    Returns:
        dict with complete session state or not-found message
    """
    try:
        db = firestore.Client(project=PROJECT, database=FIRESTORE_DB)
        doc = db.collection("claim_sessions").document(session_id).get()

        if not doc.exists:
            return {
                "status": "NOT_FOUND",
                "session_id": session_id,
                "message": f"No session found for {session_id}",
            }

        return {
            "status": "SUCCESS",
            "session_id": session_id,
            "data": doc.to_dict(),
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "session_id": session_id,
            "error": str(e),
        }
