# medverify/tools/pdf_tools.py
"""
PDF ingestion tools for MedVerify AI.
Reads PDFs from Google Cloud Storage and extracts structured content
using Gemini's native multimodal PDF understanding.

Two approaches supported:
1. GCS URI approach  — PDF already uploaded to Cloud Storage
2. Inline bytes approach — PDF bytes passed directly to Gemini
3. ADK Artifact approach — PDF stored via ADK artifact service

The agent calls read_claim_documents() which orchestrates all PDF reading
and returns structured extracted content for the pipeline agents.
"""
from __future__ import annotations
import os
import base64
from typing import Any

import vertexai
from google.cloud import storage
from vertexai.generative_models import GenerativeModel, Part

PROJECT  = os.getenv("GOOGLE_CLOUD_PROJECT", "")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
BUCKET   = os.getenv("CLAIMS_BUCKET", "")


def _get_gemini_model() -> GenerativeModel:
    """Get Gemini Flash model for PDF reading (fast, multimodal)."""
    vertexai.init(project=PROJECT, location=LOCATION)
    return GenerativeModel("gemini-2.0-flash-001")


def read_pdf_from_gcs(gcs_uri: str) -> dict[str, Any]:
    """
    Read and extract content from a PDF stored in Google Cloud Storage.
    Uses Gemini's native PDF understanding — no external OCR needed.

    Args:
        gcs_uri: Full GCS URI e.g. gs://bucket-name/claims/CLM-001/admission_note.pdf

    Returns:
        dict with extracted text content, detected document type, and key fields
    """
    try:
        model = _get_gemini_model()

        # Pass PDF directly to Gemini as a Part from GCS URI
        pdf_part = Part.from_uri(uri=gcs_uri, mime_type="application/pdf")

        prompt = """
        You are a medical document analyst for a health insurance company.
        Read this PDF document carefully and extract the following:

        1. DOCUMENT TYPE: What type of document is this?
           (admission_note | discharge_summary | ecg_report | blood_report |
            lab_report | ot_notes | preauth_form | hospital_bill | pharmacy_bill |
            implant_invoice | identity_proof | policy_card | progress_notes |
            ultrasound_report | payment_receipt | claim_form | unknown)

        2. PATIENT NAME: Full name of patient (if found)

        3. DATE: Primary date of this document (DD-Mon-YYYY format)

        4. KEY MEDICAL INFORMATION:
           - Diagnosis (with ICD-10 code if present)
           - Procedures performed (with CPT codes if present)
           - Doctor name and signature present (YES/NO)
           - Hospital stamp present (YES/NO)

        5. KEY FINANCIAL INFORMATION (if bill/invoice):
           - Total amount
           - Payment status

        6. FULL EXTRACTED TEXT: Extract all important text from the document.

        Return your response in this exact format:
        DOC_TYPE: <type>
        PATIENT_NAME: <name or NOT_FOUND>
        DOCUMENT_DATE: <date or NOT_FOUND>
        DIAGNOSIS: <diagnosis and ICD-10 or NOT_APPLICABLE>
        PROCEDURES: <procedures and CPT codes or NOT_APPLICABLE>
        DOCTOR_SIGNED: <YES/NO>
        HOSPITAL_STAMP: <YES/NO>
        FINANCIAL_TOTAL: <amount or NOT_APPLICABLE>
        PAYMENT_STATUS: <PAID/UNPAID/NOT_APPLICABLE>
        LEGIBILITY: <GOOD/POOR/UNREADABLE>
        EXTRACTED_TEXT:
        <full extracted content>
        """

        response = model.generate_content([pdf_part, prompt])
        extracted = response.text

        # Parse the structured response
        lines = extracted.split('\n')
        parsed = {}
        in_text_section = False
        text_lines = []

        for line in lines:
            if line.startswith('EXTRACTED_TEXT:'):
                in_text_section = True
                continue
            if in_text_section:
                text_lines.append(line)
            else:
                for field in ['DOC_TYPE', 'PATIENT_NAME', 'DOCUMENT_DATE',
                              'DIAGNOSIS', 'PROCEDURES', 'DOCTOR_SIGNED',
                              'HOSPITAL_STAMP', 'FINANCIAL_TOTAL',
                              'PAYMENT_STATUS', 'LEGIBILITY']:
                    if line.startswith(f'{field}:'):
                        parsed[field.lower()] = line.split(':', 1)[1].strip()

        parsed['extracted_text'] = '\n'.join(text_lines).strip()
        parsed['source_uri'] = gcs_uri
        parsed['filename'] = gcs_uri.split('/')[-1]

        return {
            "status": "SUCCESS",
            "gcs_uri": gcs_uri,
            "doc_type": parsed.get('doc_type', 'unknown'),
            "patient_name": parsed.get('patient_name', 'NOT_FOUND'),
            "document_date": parsed.get('document_date', 'NOT_FOUND'),
            "diagnosis": parsed.get('diagnosis', 'NOT_APPLICABLE'),
            "procedures": parsed.get('procedures', 'NOT_APPLICABLE'),
            "doctor_signed": parsed.get('doctor_signed', 'UNKNOWN'),
            "hospital_stamp": parsed.get('hospital_stamp', 'UNKNOWN'),
            "financial_total": parsed.get('financial_total', 'NOT_APPLICABLE'),
            "payment_status": parsed.get('payment_status', 'NOT_APPLICABLE'),
            "legibility": parsed.get('legibility', 'GOOD'),
            "extracted_text": parsed.get('extracted_text', extracted),
            "filename": parsed.get('filename', ''),
        }

    except Exception as e:
        return {
            "status": "ERROR",
            "gcs_uri": gcs_uri,
            "error": str(e),
            "doc_type": "unknown",
            "extracted_text": "",
        }


def read_pdf_bytes(
    pdf_bytes: bytes,
    filename: str = "document.pdf",
) -> dict[str, Any]:
    """
    Read and extract content from PDF bytes directly.
    Use this when PDF is passed as raw bytes (not stored in GCS yet).

    Args:
        pdf_bytes: Raw PDF file bytes
        filename: Original filename for reference

    Returns:
        dict with extracted content (same structure as read_pdf_from_gcs)
    """
    try:
        model = _get_gemini_model()

        # Pass PDF bytes directly to Gemini as inline data
        pdf_part = Part.from_data(data=pdf_bytes, mime_type="application/pdf")

        prompt = """
        Read this medical/insurance document and extract:
        1. Document type (admission_note/discharge_summary/bill/lab_report etc.)
        2. Patient name
        3. Date of document
        4. Diagnosis with ICD-10 code if present
        5. Procedures with CPT codes if present
        6. Whether doctor signature is present
        7. Whether hospital stamp is present
        8. Financial amounts if it is a bill
        9. All important text content

        Format: DOC_TYPE, PATIENT_NAME, DOCUMENT_DATE, DIAGNOSIS, PROCEDURES,
        DOCTOR_SIGNED (YES/NO), HOSPITAL_STAMP (YES/NO), FINANCIAL_TOTAL,
        LEGIBILITY (GOOD/POOR/UNREADABLE), then EXTRACTED_TEXT with full content.
        """

        response = model.generate_content([pdf_part, prompt])
        return {
            "status": "SUCCESS",
            "filename": filename,
            "extracted_text": response.text,
            "doc_type": "extracted_from_bytes",
        }

    except Exception as e:
        return {
            "status": "ERROR",
            "filename": filename,
            "error": str(e),
            "extracted_text": "",
        }


def upload_pdf_to_gcs(
    local_path: str,
    claim_id: str,
    filename: str,
) -> dict[str, Any]:
    """
    Upload a local PDF file to Cloud Storage under the claim folder.

    Args:
        local_path: Local file path of the PDF
        claim_id: Claim identifier for folder structure
        filename: Desired filename in GCS

    Returns:
        dict with GCS URI of uploaded file
    """
    try:
        client  = storage.Client(project=PROJECT)
        bucket  = client.bucket(BUCKET)
        blob_path = f"claims/{claim_id}/{filename}"
        blob    = bucket.blob(blob_path)

        blob.upload_from_filename(local_path, content_type="application/pdf")
        gcs_uri = f"gs://{BUCKET}/{blob_path}"

        return {
            "status": "SUCCESS",
            "gcs_uri": gcs_uri,
            "claim_id": claim_id,
            "filename": filename,
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "error": str(e),
            "local_path": local_path,
        }


def list_claim_documents(claim_id: str) -> dict[str, Any]:
    """
    List all PDF documents uploaded for a specific claim in GCS.

    Args:
        claim_id: Claim identifier

    Returns:
        dict with list of GCS URIs for all claim documents
    """
    try:
        client  = storage.Client(project=PROJECT)
        bucket  = client.bucket(BUCKET)
        prefix  = f"claims/{claim_id}/"
        blobs   = list(bucket.list_blobs(prefix=prefix))

        documents = []
        for blob in blobs:
            if blob.name.endswith('.pdf'):
                documents.append({
                    "filename":  blob.name.split('/')[-1],
                    "gcs_uri":   f"gs://{BUCKET}/{blob.name}",
                    "size_bytes": blob.size,
                    "updated":   blob.updated.isoformat() if blob.updated else None,
                })

        return {
            "status": "SUCCESS",
            "claim_id": claim_id,
            "document_count": len(documents),
            "documents": documents,
            "gcs_prefix": f"gs://{BUCKET}/{prefix}",
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "claim_id": claim_id,
            "error": str(e),
            "documents": [],
        }


def read_all_claim_documents(claim_id: str) -> dict[str, Any]:
    """
    Read and extract content from ALL PDF documents for a claim.
    This is the PRIMARY entry point called by the gate agents.
    Reads all PDFs from GCS and returns structured extracted content.

    Args:
        claim_id: Claim identifier (folder in GCS)

    Returns:
        dict with all extracted document content, types, and quality assessment
    """
    # Step 1: List all documents
    listing = list_claim_documents(claim_id)
    if listing["status"] == "ERROR":
        return {
            "status": "ERROR",
            "claim_id": claim_id,
            "error": listing["error"],
            "documents": [],
        }

    if listing["document_count"] == 0:
        return {
            "status": "NO_DOCUMENTS",
            "claim_id": claim_id,
            "message": f"No PDF documents found in GCS for claim {claim_id}",
            "documents": [],
        }

    # Step 2: Read each document
    extracted_docs = []
    doc_types_found = []
    quality_issues  = []

    for doc_info in listing["documents"]:
        result = read_pdf_from_gcs(doc_info["gcs_uri"])
        result["original_filename"] = doc_info["filename"]

        extracted_docs.append(result)
        doc_types_found.append(result.get("doc_type", "unknown"))

        if result.get("legibility") == "POOR":
            quality_issues.append(
                f"{doc_info['filename']}: Low legibility — may affect processing"
            )
        if result.get("legibility") == "UNREADABLE":
            quality_issues.append(
                f"{doc_info['filename']}: UNREADABLE — must be resubmitted"
            )
        if result.get("doctor_signed") == "NO":
            quality_issues.append(
                f"{doc_info['filename']}: No doctor signature detected"
            )

    # Step 3: Build combined content summary
    combined_text = "\n\n".join([
        f"=== {doc.get('original_filename', 'Unknown')} "
        f"({doc.get('doc_type', 'unknown')}) ===\n"
        f"{doc.get('extracted_text', '')}"
        for doc in extracted_docs
        if doc.get("status") == "SUCCESS"
    ])

    return {
        "status": "SUCCESS",
        "claim_id": claim_id,
        "total_documents": len(extracted_docs),
        "successful_reads": sum(1 for d in extracted_docs if d["status"] == "SUCCESS"),
        "failed_reads": sum(1 for d in extracted_docs if d["status"] == "ERROR"),
        "document_types_found": list(set(doc_types_found)),
        "quality_issues": quality_issues,
        "documents": extracted_docs,
        "combined_extracted_text": combined_text[:8000],  # cap for context window
    }


def read_single_pdf_from_gcs_uri(gcs_uri: str) -> dict[str, Any]:
    """
    Read a single PDF document from its GCS URI.
    Use this when you have a specific URI and want to read just that one document.

    Args:
        gcs_uri: Full GCS URI e.g. gs://bucket/claims/CLM-001/discharge_summary.pdf

    Returns:
        dict with extracted content from that document
    """
    return read_pdf_from_gcs(gcs_uri)
