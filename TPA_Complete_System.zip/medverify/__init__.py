# medverify/__init__.py
# ADK requires root_agent to be importable from the package
from medverify.agent import root_agent

__all__ = ["root_agent"]
