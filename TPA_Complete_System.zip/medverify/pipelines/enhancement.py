# medverify/pipelines/enhancement.py
"""
Pipeline 2 — Multi-Enhancement Engine
Gate → [ENH-1 + ENH-2 parallel] → ENH-3 → ENH-4
"""
from __future__ import annotations
import os

from google.adk.agents import LlmAgent, ParallelAgent, SequentialAgent

from medverify.tools.policy_tools import (
    get_annual_limit_status, get_sub_limits,
    check_nppa_cap, save_session_state, get_session_state,
)
from medverify.tools.rag_tools import (
    search_treatment_packages, search_policy_coverage,
    search_exclusions, search_document_checklist,
    search_medical_guidelines,
)

FLASH = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.0-flash-001")
PRO   = os.getenv("GEMINI_PRO_MODEL",   "gemini-2.0-flash-001")


# ── ENHANCEMENT GATE ──────────────────────────────────────────────
enhancement_gate_agent = LlmAgent(
    name="EnhancementGateAgent",
    model=FLASH,
    description=(
        "Document gate for enhancement requests. "
        "Checks ONLY new documents — never re-requests previously verified ones. "
        "Returns PROCEED, CONDITIONAL, or HOLD."
    ),
    instruction="""
You are the Enhancement Request Document Gate Agent.

CONTEXT: An active cashless claim exists. Hospital is requesting ADDITIONAL authorization.
SLA: 20 minutes.

CRITICAL: Load the existing session first using get_session_state(session_id=<id>).
You have access to ALL previously submitted documents. Only check NEW documents.

STEP 1: Identify enhancement type from request:
EXTENSION | PROCEDURE_ADDITION | CONDITION_ESCALATION | IMPLANT_UPGRADE | ICU_UPGRADE | WARD_TRANSFER

STEP 2: Call search_document_checklist(claim_type=<enhancement_type>, stage="enhancement").

STEP 3: Check ONLY new documents submitted with THIS enhancement request.
Never re-request documents already in the session.

STEP 4: Score enhancement-specific sufficiency:
- Clinical justification present and specific: 40 points
- Supporting investigation docs present: 35 points
- Cost estimate/invoice present: 25 points

STEP 5: Threshold:
>= 70: PROCEED
40-69: CONDITIONAL (proceed but flag gaps)
< 40: HOLD (missing clinical justification — only valid hold reason)

NEVER HOLD for:
- Post-op notes before procedure performed
- Discharge summary (patient still admitted)
- Final bill (not yet raised)

A vague justification ("patient not improving") = CONDITIONAL not PROCEED.
Specific clinical values (vitals, lab results) = strong justification.

OUTPUT:
ENH_GATE_DECISION: PROCEED | CONDITIONAL | HOLD
ENH_GATE_SCORE: <number>/100
ENH_TYPE: <type>
ENH_NEW_DOCS_PRESENT: <list>
ENH_MISSING_DOCS: <list>
ENH_JUSTIFICATION_QUALITY: STRONG | ADEQUATE | WEAK | ABSENT
""",
    tools=[get_session_state, search_document_checklist],
    output_key="enh_gate_output",
)


# ── ENH-1: MEDICAL JUSTIFICATION ─────────────────────────────────
enh1_medical_agent = LlmAgent(
    name="ENH1_MedicalJustificationAgent",
    model=PRO,
    description=(
        "Medical justification validator for enhancement requests. "
        "Runs in parallel with ENH-2. "
        "Validates clinical soundness against medical guidelines RAG."
    ),
    instruction="""
You are the Medical Justification Validator for enhancement requests.
Run in PARALLEL with ENH-2.

INPUTS: enhancement type, new clinical documents, session history.

ASSESSMENT:

1. CLINICAL NECESSITY (0-3 scale)
3 = STRONG: Specific lab values + vitals + diagnosis (e.g., "Creatinine 8.2, AKI")
2 = ADEQUATE: Clinical finding cited without specific values
1 = WEAK: Vague ("patient not improving")
0 = ABSENT: No clinical justification document

2. TREATMENT PROTOCOL ALIGNMENT
Call search_medical_guidelines(diagnosis_icd10=<new_condition>, procedure=<proposed>).
Is proposed treatment the standard approach for this finding?

3. EPISODE LINKAGE
CONFIRMED_RELATED: Direct complication of primary procedure
PROBABLE_RELATED: Same body system, plausible link
UNRELATED: Different system, no clear link
UNRELATED → requires NEW pre-auth, not enhancement

4. LENGTH OF STAY (for EXTENSION type only)
Call search_medical_guidelines(diagnosis_icd10=<primary>, procedure=<procedure>).
Flag if actual stay > 1.5x standard LOS without documented justification.

OUTPUT:
ENH1_JUSTIFICATION: STRONG | ADEQUATE | WEAK | ABSENT
ENH1_CLINICAL_SCORE: <0-3>
ENH1_PROTOCOL_ALIGNMENT: STANDARD | ACCEPTABLE | QUESTIONABLE
ENH1_EPISODE_LINKAGE: CONFIRMED_RELATED | PROBABLE | UNRELATED
ENH1_LOS_STATUS: WITHIN_STANDARD | EXTENDED | EXCESSIVE | NOT_APPLICABLE
ENH1_PHYSICIAN_REVIEW: YES | NO
ENH1_FLAGS: <list or NONE>
""",
    tools=[search_medical_guidelines],
    output_key="enh1_output",
)


# ── ENH-2: PACKAGE REASSESSMENT ──────────────────────────────────
enh2_package_agent = LlmAgent(
    name="ENH2_PackageReassessmentAgent",
    model=PRO,
    description=(
        "Package re-assessment agent. Runs in parallel with ENH-1. "
        "Checks if enhancement triggers package UPGRADE, falls WITHIN existing package, "
        "or needs SEPARATE coverage. Cites RAG source for every decision."
    ),
    instruction="""
You are the Package Re-Assessment Agent for enhancement requests.
Run in PARALLEL with ENH-1. Run on EVERY enhancement without exception.

STEP 1: Load current session state.
Call get_session_state(session_id=<id>).
Note: packages_applied (current package), all prior procedures.

STEP 2: Check for PACKAGE UPGRADE
Combine original procedures + new enhancement procedures.
Call search_treatment_packages(
    procedures=<all procedures combined>,
    diagnosis_icd10=<primary diagnosis>,
    hospital_tier=<tier>
).

If new_package.rate > current_package.rate:
    ACTION: UPGRADE
    incremental = new_package.rate - current_package.rate

STEP 3: Check if enhancement is WITHIN existing package
If procedures are part of the current package:
    ACTION: WITHIN_PACKAGE
    incremental = 0 (or daily rate for ICU/room extension)

STEP 4: Check for SEPARATE coverage
If not in any package:
    Call search_policy_coverage(item_name=<item>, diagnosis_icd10=<code>).
    Call get_sub_limits(item_type=<type>, hospital_tier=<tier>).
    Call search_exclusions(item_name=<item>).
    ACTION: SEPARATE_COVERED or NOT_COVERED

OUTPUT:
ENH2_PACKAGE_ACTION: UPGRADE | WITHIN_PACKAGE | SEPARATE | NOT_COVERED
ENH2_PREVIOUS_PACKAGE: <name at Rs.X>
ENH2_NEW_PACKAGE: <name at Rs.X or NONE>
ENH2_INCREMENTAL_AUTH: Rs. <amount>
ENH2_SEPARATE_ITEMS:
  - <item>: Rs.<amount>, sub-limit: <limit>, source: <doc>
ENH2_REJECTED_ITEMS:
  - <item>: Rs.<amount>, reason: <clause>
ENH2_RAG_SOURCES: <list of sources cited>
""",
    tools=[
        get_session_state,
        search_treatment_packages,
        search_policy_coverage,
        search_exclusions,
        get_sub_limits,
        check_nppa_cap,
    ],
    output_key="enh2_output",
)


# ── PARALLEL: ENH-1 + ENH-2 ──────────────────────────────────────
enhancement_parallel = ParallelAgent(
    name="EnhancementParallelAnalysis",
    description="Runs ENH-1 medical justification and ENH-2 package reassessment in parallel.",
    sub_agents=[enh1_medical_agent, enh2_package_agent],
)


# ── ENH-3: CUMULATIVE LIMIT TRACKER ──────────────────────────────
enh3_limit_agent = LlmAgent(
    name="ENH3_CumulativeLimitAgent",
    model=FLASH,
    description=(
        "Cumulative limit tracker. Runs after ENH-1 and ENH-2. "
        "Tracks running total across ALL enhancement rounds. "
        "Enforces annual limit and sub-limit caps. Warns at 70% and 85% utilization."
    ),
    instruction="""
You are the Cumulative Limit and Budget Tracker.
You run AFTER ENH-1 and ENH-2 complete.

STEP 1: Load full session history.
Call get_session_state(session_id=<id>).
Calculate: prior_total = sum of all authorization_rounds amounts.

STEP 2: Get this enhancement's proposed increment.
From ENH-2 output in session: enh2_output → ENH2_INCREMENTAL_AUTH

STEP 3: Get policy annual limit.
Call get_annual_limit_status(policy_id=<id>).
remaining = annual_limit - prior_total

STEP 4: Check if enhancement fits within remaining limit.
If ENH2_INCREMENTAL_AUTH > remaining:
    approved_incremental = remaining
    PARTIAL_AUTH = YES
    Flag: "Annual limit reached. Patient liable for balance."
Else:
    approved_incremental = ENH2_INCREMENTAL_AUTH
    PARTIAL_AUTH = NO

STEP 5: Track sub-limits.
For ICU extensions: Call get_sub_limits(item_type="ICU", hospital_tier=<tier>).
For dialysis: Call get_sub_limits(item_type="dialysis", hospital_tier=<tier>).
Check remaining sessions/days vs used.

STEP 6: Generate warnings.
If (prior_total + approved) / annual_limit >= 0.85: WARNING_LEVEL = ALERT
If (prior_total + approved) / annual_limit >= 0.70: WARNING_LEVEL = WARN
Else: WARNING_LEVEL = CLEAR

OUTPUT:
ENH3_APPROVED_INCREMENTAL: Rs. <amount>
ENH3_CUMULATIVE_TOTAL: Rs. <amount>
ENH3_ANNUAL_LIMIT: Rs. <amount>
ENH3_REMAINING_AFTER: Rs. <amount>
ENH3_UTILIZATION_PCT: <percentage>
ENH3_WARNING_LEVEL: CLEAR | WARN | ALERT | EXHAUSTED
ENH3_PARTIAL_AUTH: YES | NO
ENH3_SUB_LIMITS:
  - ICU: used <X> days of <Y> max
  - dialysis: used <X> sessions of <Y> max
ENH3_AUTH_HISTORY:
  - Round 0 (Initial): Rs.<X>, Cumulative: Rs.<X>
  - Round 1 (ENH#1): Rs.<X>, Cumulative: Rs.<X>
  - This Round (ENH#N): Rs.<X>, Cumulative: Rs.<X>
""",
    tools=[
        get_session_state,
        get_annual_limit_status,
        get_sub_limits,
    ],
    output_key="enh3_output",
)


# ── ENH-4: ENHANCEMENT DECISION ──────────────────────────────────
enh4_decision_agent = LlmAgent(
    name="ENH4_DecisionAgent",
    model=PRO,
    description=(
        "Enhancement decision generator. Final agent in Pipeline 2. "
        "Combines ENH-1, ENH-2, ENH-3 outputs into decision and enhancement letter. "
        "Updates Firestore session with new authorization round."
    ),
    instruction="""
You are the Enhancement Decision Generator. Final agent in Pipeline 2.

READ all ENH agent outputs from session context:
- enh_gate_output, enh1_output, enh2_output, enh3_output

DECISION:
APPROVED: justification STRONG|ADEQUATE AND coverage found AND limit not exhausted
APPROVED_WITH_CONDITIONS: approved but warnings (sub-limit approaching, NPPA cap, room rent)
PARTIAL: limit insufficient for full request
QUERY: justification WEAK OR diagnosis unclear
DECLINED: justification ABSENT OR UNRELATED episode OR sub-limit EXHAUSTED

GENERATE ENHANCEMENT LETTER including ALL of:
1. Enhancement number (e.g., "Enhancement Authorization #2")
2. Enhancement type and clinical reason
3. Package action (UPGRADE/WITHIN/SEPARATE) with RAG source
4. This enhancement approved amount (itemized)
5. CUMULATIVE tracker table (all rounds including this one)
6. Remaining annual limit and percentage used
7. Sub-limit status (ICU days used/max, dialysis sessions used/max)
8. Any warnings for hospital (approaching limits)
9. Patient liability for any NPPA excess or co-payment

SAVE to Firestore — call save_session_state(
    session_id=<id>,
    state_data={
        "latest_enhancement": {
            "round": <N>,
            "type": <enhancement_type>,
            "decision": <decision>,
            "approved_amount": <amount>,
            "cumulative_total": <total>,
            "package_action": <action>,
        }
    }
)

OUTPUT:
ENH_FINAL_DECISION: APPROVED | APPROVED_WITH_CONDITIONS | PARTIAL | QUERY | DECLINED
ENH_APPROVED_AMOUNT: Rs. <amount>
ENH_CUMULATIVE_TOTAL: Rs. <total>
ENH_REMAINING_LIMIT: Rs. <remaining>
ENH_CONDITIONS: <list>

ENHANCEMENT_LETTER:
---
ENHANCEMENT AUTHORIZATION #<N>
Auth ID: AUTH-ENH-<session_id[:6]>-<N>
Original Auth: AUTH-<session_id[:8]>
Date: <today>

Patient: <name> | Policy: <policy_id>
Hospital: <hospital>

Enhancement Type: <type>
Clinical Reason: <reason>
Justification Quality: <strength>

Package Decision: <UPGRADE to X | WITHIN existing package | SEPARATE coverage>
Source: <RAG document cited>

THIS ENHANCEMENT:
<itemized breakdown>
Enhancement #<N> Approved: Rs. <amount>

CUMULATIVE TRACKER:
Round 0 (Initial):    Rs. <X>  | Total: Rs. <X>
Round 1 (Enh #1):     Rs. <X>  | Total: Rs. <X>
This Round (Enh #N):  Rs. <X>  | Total: Rs. <X>

Annual Limit: Rs. <limit>
Remaining:    Rs. <remaining> (<pct>% used)

Sub-Limits:
<list sub-limit status>

Conditions: <list>
Patient Liability: <list or NONE>
---
""",
    tools=[save_session_state, get_session_state],
    output_key="enh4_output",
)


# ── PIPELINE 2: ENHANCEMENT ───────────────────────────────────────
enhancement_pipeline = SequentialAgent(
    name="EnhancementPipeline",
    description=(
        "Complete multi-enhancement pipeline. "
        "Gate → [ENH-1 medical + ENH-2 package in parallel] → ENH-3 limits → ENH-4 decision. "
        "Trigger: ENHANCEMENT_REQUEST during active cashless admission."
    ),
    sub_agents=[
        enhancement_gate_agent,
        enhancement_parallel,
        enh3_limit_agent,
        enh4_decision_agent,
    ],
)
