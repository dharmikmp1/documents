# medverify/pipelines/cashless.py
"""
Pipeline 1 — Cashless Pre-Authorization
Gate → [PA-1 + PA-2 + PA-3 parallel] → PA-4

Uses correct ADK patterns:
- LlmAgent for all reasoning agents
- ParallelAgent for PA-1, PA-2, PA-3
- SequentialAgent for overall pipeline
- output_key to pass state between agents
- session state for cross-agent communication
"""
from __future__ import annotations
import os

from google.adk.agents import LlmAgent, ParallelAgent, SequentialAgent

from medverify.tools.policy_tools import (
    check_policy_status,
    check_hospital_network,
    check_waiting_period,
    get_annual_limit_status,
    check_fraud_flags,
    get_sub_limits,
    check_nppa_cap,
    save_session_state,
    get_session_state,
)
from medverify.tools.rag_tools import (
    search_treatment_packages,
    search_policy_coverage,
    search_exclusions,
    search_document_checklist,
    search_medical_guidelines,
)
from medverify.prompts.cashless_prompts import (
    GATE_AGENT_INSTRUCTION,
    PA1_INSTRUCTION,
    PA2_INSTRUCTION,
    PA3_INSTRUCTION,
    PA4_INSTRUCTION,
)

FLASH_MODEL = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.0-flash-001")
PRO_MODEL   = os.getenv("GEMINI_PRO_MODEL",   "gemini-2.0-flash-001")


# ── GATE AGENT ────────────────────────────────────────────────────
cashless_gate_agent = LlmAgent(
    name="CashlessGateAgent",
    model=FLASH_MODEL,
    description=(
        "Document sufficiency gate for cashless pre-authorization. "
        "Runs first. Checks if submitted documents are sufficient to proceed. "
        "Returns PROCEED, QUERY_PROCEED, or HOLD."
    ),
    instruction=GATE_AGENT_INSTRUCTION,
    tools=[search_document_checklist],
    output_key="gate_output",
)


# ── PA-1: ELIGIBILITY ─────────────────────────────────────────────
pa1_eligibility_agent = LlmAgent(
    name="PA1_EligibilityAgent",
    model=FLASH_MODEL,
    description=(
        "Policy eligibility checker. Runs in parallel with PA-2 and PA-3. "
        "Checks policy status, hospital network, waiting periods, annual limit, fraud flags."
    ),
    instruction=PA1_INSTRUCTION,
    tools=[
        check_policy_status,
        check_hospital_network,
        check_waiting_period,
        get_annual_limit_status,
        check_fraud_flags,
    ],
    output_key="pa1_output",
)


# ── PA-2: COVERAGE RAG ────────────────────────────────────────────
pa2_coverage_agent = LlmAgent(
    name="PA2_CoverageAgent",
    model=PRO_MODEL,
    description=(
        "RAG-powered coverage determination agent. Runs in parallel with PA-1 and PA-3. "
        "Checks treatment packages first (mandatory), then individual coverage. "
        "Every decision cites RAG source document."
    ),
    instruction=PA2_INSTRUCTION,
    tools=[
        search_treatment_packages,
        search_policy_coverage,
        search_exclusions,
        get_sub_limits,
        check_nppa_cap,
    ],
    output_key="pa2_output",
)


# ── PA-3: COST ESTIMATION ─────────────────────────────────────────
pa3_cost_agent = LlmAgent(
    name="PA3_CostAgent",
    model=FLASH_MODEL,
    description=(
        "Cost estimation and limit agent. Runs in parallel with PA-1 and PA-2. "
        "Validates estimated cost, applies 10% buffer, checks room rent and ICU caps."
    ),
    instruction=PA3_INSTRUCTION,
    tools=[
        get_annual_limit_status,
        get_sub_limits,
    ],
    output_key="pa3_output",
)


# ── PARALLEL PHASE: PA-1 + PA-2 + PA-3 ───────────────────────────
cashless_parallel_analysis = ParallelAgent(
    name="CashlessParallelAnalysis",
    description=(
        "Runs PA-1 eligibility, PA-2 coverage RAG, and PA-3 cost estimation "
        "simultaneously for speed. All three write to session state via output_key."
    ),
    sub_agents=[
        pa1_eligibility_agent,
        pa2_coverage_agent,
        pa3_cost_agent,
    ],
)


# ── PA-4: DECISION GENERATOR ──────────────────────────────────────
pa4_decision_agent = LlmAgent(
    name="PA4_DecisionAgent",
    model=PRO_MODEL,
    description=(
        "Pre-authorization decision generator. Runs after parallel analysis completes. "
        "Reads PA-1, PA-2, PA-3 outputs from session state. "
        "Generates final decision and pre-auth letter. Saves to Firestore."
    ),
    instruction=PA4_INSTRUCTION,
    tools=[
        save_session_state,
        get_session_state,
    ],
    output_key="pa4_output",
)


# ── PIPELINE 1: CASHLESS PRE-AUTH ─────────────────────────────────
# Sequence: Gate → Parallel(PA1+PA2+PA3) → PA4
cashless_pipeline = SequentialAgent(
    name="CashlessPreAuthPipeline",
    description=(
        "Complete cashless pre-authorization pipeline. "
        "Gate checks documents → PA1/PA2/PA3 run in parallel → PA4 generates decision. "
        "Trigger: CASHLESS_PREAUTH event from hospital TPA desk."
    ),
    sub_agents=[
        cashless_gate_agent,
        cashless_parallel_analysis,
        pa4_decision_agent,
    ],
)
