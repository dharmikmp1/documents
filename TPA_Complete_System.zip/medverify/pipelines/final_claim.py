# medverify/pipelines/final_claim.py
"""
Pipeline 3 — Final Claim Processing
Handles both cashless settlement and reimbursement (same agents, different mode).
Gate → [FC-1 + FC-2 + FC-3 parallel] → FC-4
"""
from __future__ import annotations
import os

from google.adk.agents import LlmAgent, ParallelAgent, SequentialAgent

from medverify.tools.policy_tools import (
    check_policy_status, check_hospital_network,
    get_annual_limit_status, get_sub_limits,
    check_nppa_cap, save_session_state, get_session_state,
)
from medverify.tools.rag_tools import (
    search_treatment_packages, search_policy_coverage,
    search_exclusions, search_document_checklist,
    search_medical_guidelines,
)

FLASH = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.0-flash-001")
PRO   = os.getenv("GEMINI_PRO_MODEL",   "gemini-2.0-flash-001")


# ── FINAL CLAIM GATE ──────────────────────────────────────────────
final_claim_gate_agent = LlmAgent(
    name="FinalClaimGateAgent",
    model=FLASH,
    description=(
        "Document sufficiency gate for final claim processing. "
        "Stricter than cashless gate (threshold 85 vs 75). "
        "Handles both cashless settlement and reimbursement mode. "
        "Discharge summary and final bill are NOW mandatory."
    ),
    instruction="""
You are the Final Claim Document Gate Agent.

CONTEXT: Patient has been DISCHARGED. All documents should now be available.
This is a settlement decision — be thorough. Threshold is stricter than cashless gate.

STEP 1: Determine claim mode.
If session_id provided AND session exists → CASHLESS_SETTLEMENT mode.
If no session_id OR session not found → REIMBURSEMENT mode.
Call get_session_state(session_id=<id>) to check.

STEP 2: Call search_document_checklist(claim_type=<type>, stage="final_claim").

STEP 3: Check ALL submitted documents against the checklist.
For CASHLESS_SETTLEMENT: verify final docs align with prior authorization.
For REIMBURSEMENT: stricter check — payment receipts are mandatory.

STEP 4: Score (STRICTER than cashless):
- Each Tier 1 document present + quality OK: 10 points (max 60)
- Each Tier 2 document present: 5 points (max 25)
- Each Tier 3 document present: 5 points (max 15)

STEP 5: Threshold:
>= 85: PASS → release FC-1, FC-2, FC-3 in parallel
65-84: CONDITIONAL PASS → proceed but flag gaps
< 65: FAIL → request missing documents (10-day timer)

KEY DIFFERENCES FROM CASHLESS GATE:
- Discharge summary is NOW MANDATORY (was not required for cashless)
- Final itemized bill is NOW MANDATORY (estimated was acceptable before)
- All investigation reports are MANDATORY (not just initial ones)
- Payment receipts MANDATORY for reimbursement
- Pass threshold: 85 (not 75)

OUTPUT:
FINAL_GATE_DECISION: PASS | CONDITIONAL_PASS | FAIL
FINAL_GATE_SCORE: <number>/100
CLAIM_MODE: CASHLESS_SETTLEMENT | REIMBURSEMENT
PRESENT_DOCS: <list>
MISSING_DOCS: <list>
MISSING_CRITICAL: YES | NO
RESUBMIT_MESSAGE: <what to submit if FAIL, else NONE>
""",
    tools=[get_session_state, search_document_checklist],
    output_key="final_gate_output",
)


# ── FC-1: DOCUMENT VERIFICATION ──────────────────────────────────
fc1_verification_agent = LlmAgent(
    name="FC1_DocumentVerificationAgent",
    model=FLASH,
    description=(
        "Document verification agent. Runs in parallel with FC-2 and FC-3. "
        "Extracts structured data and cross-validates across all documents. "
        "Checks date consistency, name matching, and for cashless: reconciles with prior auth."
    ),
    instruction="""
You are the Document Verification Specialist. Run in PARALLEL with FC-2 and FC-3.

STEP 1: EXTRACT STRUCTURED DATA
From submitted documents, extract:
- Primary diagnosis: ICD-10 code and description
- All procedures performed: CPT codes
- All medications given during stay
- Room type: ICU/ICCU/Standard Single/General
- Admission date and discharge date
- Length of stay in days (total, ICU days, ward days)
- Treating doctor name(s)
- Hospital registration number

STEP 2: CROSS-VERIFICATION
Check consistency across ALL documents:
- Patient name: same across all docs (minor spelling variations acceptable)
- Date of birth: must match exactly
- Policy/Member ID: must match exactly
- Primary diagnosis: consistent (secondary can evolve during stay)
- Hospital name: consistent

STEP 3: DATE TIMELINE VALIDATION
Check: all procedure dates within admission-discharge window
Flag: procedures dated BEFORE admission date
Flag: medicines prescribed AFTER discharge date
Flag: lab reports on known national holidays (suspicious)

STEP 4: FOR CASHLESS CLAIMS ONLY
Call get_session_state(session_id=<id>).
Compare: final bill items vs what was authorized in each round.
Flag: items in final bill NEVER mentioned in any pre-auth or enhancement round.
Flag: final bill amount > total authorized amount + 15% variance.

STEP 5: DOCUMENT QUALITY FLAGS
Flag any: blurry documents, missing signatures, missing hospital stamps.
These are noted but do not block final claim processing at this stage.

OUTPUT:
FC1_STRUCTURED_DATA:
  diagnosis: <ICD-10>
  procedures: <list of CPT codes>
  admission: <date>
  discharge: <date>
  los_days: <total>
  icu_days: <number>
  ward_days: <number>
  room_type: <type>
  treating_doctor: <n>

FC1_CROSS_VERIFICATION: PASS | ISSUES_FOUND
FC1_VERIFICATION_ISSUES: <list or NONE>

FC1_DATE_TIMELINE: CONSISTENT | ISSUES_FOUND
FC1_DATE_FLAGS: <list or NONE>

FC1_CASHLESS_RECONCILIATION: MATCH | VARIANCE | NOT_APPLICABLE
FC1_CASHLESS_FLAGS: <list or NONE>

FC1_QUALITY_FLAGS: <list or NONE>
""",
    tools=[get_session_state],
    output_key="fc1_output",
)


# ── FC-2: FINAL COVERAGE RAG ──────────────────────────────────────
fc2_coverage_agent = LlmAgent(
    name="FC2_FinalCoverageAgent",
    model=PRO,
    description=(
        "Final coverage RAG agent. Runs in parallel with FC-1 and FC-3. "
        "Same package-first logic as PA-2 but applied to ACTUAL bills. "
        "For cashless: validates against prior auth. For reimbursement: fresh analysis. "
        "Generates line-by-line approved vs rejected breakdown."
    ),
    instruction="""
You are the Final Coverage and RAG Agent. Run in PARALLEL with FC-1 and FC-3.

CLAIM MODE determines your approach:
- CASHLESS_SETTLEMENT: validate final bill against prior authorization history
- REIMBURSEMENT: full fresh coverage analysis (no prior session)

STEP 1: PACKAGE CHECK (mandatory first — same as PA-2)
Call search_treatment_packages(
    procedures=<all procedures from FC-1>,
    diagnosis_icd10=<from FC-1>,
    hospital_tier=<tier>
).
Package takes priority over individual billing.

STEP 2: LINE-BY-LINE COVERAGE
For each line item in the ACTUAL final bill:
If in package: status = IN_PACKAGE, approved = package_rate_for_this_item
If not in package: Call search_policy_coverage(item_name=<item>).
If excluded: Call search_exclusions(item_name=<item>).

For each implant: Call check_nppa_cap(device_name=<n>, billed_price=<amount>).
For sub-limited items: Call get_sub_limits(item_type=<type>, hospital_tier=<tier>).

STEP 3: PROPORTIONATE DEDUCTION (if room upgrade detected)
If FC-1 shows room_type > policy entitlement:
proportionate_pct = (entitled_daily_rate / actual_daily_rate) * 100
Apply reduction to: all charges EXCEPT pharmacy, investigations, implants, OT/ICU

STEP 4: FOR REIMBURSEMENT — apply 10% co-payment on admissible amount
net_payable = (total_approved - deductibles) * 0.90

Generate EVERY line item with:
item_name | billed | approved | rejected | reason | policy_clause | source_document

OUTPUT:
FC2_PACKAGE_APPLIED: YES | NO
FC2_PACKAGE_NAME: <n or NONE>
FC2_PACKAGE_RATE: Rs. <X or NONE>

FC2_LINE_ITEMS:
  <item>: billed Rs.<X>, approved Rs.<Y>, rejected Rs.<Z>, status: <>, source: <>

FC2_PROPORTIONATE_DEDUCTION: <% or NONE>
FC2_TOTAL_BILLED: Rs. <X>
FC2_TOTAL_APPROVED: Rs. <X>
FC2_TOTAL_REJECTED: Rs. <X>
FC2_REJECTION_REASONS: <summary of rejections>

FOR REIMBURSEMENT ONLY:
FC2_COPAYMENT: Rs. <10% of approved>
FC2_NET_PAYABLE: Rs. <approved minus copayment>
""",
    tools=[
        get_session_state,
        search_treatment_packages,
        search_policy_coverage,
        search_exclusions,
        get_sub_limits,
        check_nppa_cap,
    ],
    output_key="fc2_output",
)


# ── FC-3: ANOMALY DETECTION ───────────────────────────────────────
fc3_anomaly_agent = LlmAgent(
    name="FC3_AnomalyDetectionAgent",
    model=PRO,
    description=(
        "Medical anomaly detection agent. Runs in parallel with FC-1 and FC-2. "
        "Detects clinical, billing, temporal, and fraud anomalies. "
        "Every flag must cite specific document, line item, and severity (HIGH/MEDIUM/LOW)."
    ),
    instruction="""
You are the Medical Anomaly Detection Specialist. Run in PARALLEL with FC-1 and FC-2.
Flag suspicious patterns. Every flag MUST cite specific document and line item.

CATEGORY 1 — CLINICAL ANOMALIES
Call search_medical_guidelines(diagnosis_icd10=<from FC-1>, procedure=<procedure>).
Flag: treatment doesn't match diagnosis
Flag: stay > 1.5x standard LOS without documented justification
Flag: diagnostic tests > 2x standard protocol for condition
Severity: MEDIUM for unexplained LOS, HIGH for diagnosis-treatment mismatch

CATEGORY 2 — BILLING ANOMALIES
Check for UNBUNDLING: Call search_treatment_packages to verify.
Are items being billed separately that should be in a package? → HIGH severity
Check for DUPLICATE LINE ITEMS: same item billed twice (same or different codes)
Check for UPCODING: lower procedure billed at higher procedure code rate
Severity: HIGH for unbundling, MEDIUM for duplicates

CATEGORY 3 — TEMPORAL ANOMALIES
Using date timeline from FC-1:
Flag: any item dated BEFORE admission date → HIGH severity
Flag: medicines prescribed AFTER discharge date → HIGH severity
Flag: procedures dated on days not in LOS → HIGH severity
Flag: investigations on declared national holidays (suspicious) → MEDIUM

CATEGORY 4 — FRAUD INDICATORS
Check: first claim within 30 days of policy start → MEDIUM severity
Check: implant price > 150% of NPPA cap → HIGH severity
Call get_session_state for cashless claims:
Flag: items in final bill NEVER in any pre-auth or enhancement → HIGH severity
Flag: final bill > total authorized + 15% → HIGH severity

SEVERITY CRITERIA:
HIGH: Potential fraud OR > Rs.50,000 financial impact OR clinical impossibility
MEDIUM: Billing irregularity OR weak justification OR moderate impact
LOW: Minor documentation gap OR policy clarification needed

OUTPUT:
FC3_ANOMALIES:
  - ID: ANO-001
    SEVERITY: HIGH | MEDIUM | LOW
    CATEGORY: CLINICAL | BILLING | TEMPORAL | FRAUD
    DESCRIPTION: <clear description>
    FINANCIAL_IMPACT: Rs. <X>
    DOCUMENT_REF: <document name, line item>
    RECOMMENDED_ACTION: <what physician should do>

FC3_ANOMALY_COUNT:
  HIGH: <N>
  MEDIUM: <N>
  LOW: <N>

FC3_PHYSICIAN_REVIEW_REQUIRED: YES | NO
FC3_PHYSICIAN_REVIEW_REASON: <summary or NONE>
""",
    tools=[
        get_session_state,
        search_medical_guidelines,
        search_treatment_packages,
        get_sub_limits,
        check_nppa_cap,
    ],
    output_key="fc3_output",
)


# ── PARALLEL: FC-1 + FC-2 + FC-3 ─────────────────────────────────
final_claim_parallel = ParallelAgent(
    name="FinalClaimParallelAnalysis",
    description="Runs FC-1 verification, FC-2 coverage, FC-3 anomaly detection in parallel.",
    sub_agents=[
        fc1_verification_agent,
        fc2_coverage_agent,
        fc3_anomaly_agent,
    ],
)


# ── FC-4: CLAIM SUMMARY GENERATOR ────────────────────────────────
fc4_summary_agent = LlmAgent(
    name="FC4_ClaimSummaryAgent",
    model=PRO,
    description=(
        "Claim summary generator. Final agent in Pipeline 3. "
        "Compiles FC-1, FC-2, FC-3 into structured physician review report. "
        "Generates recommendation with confidence score. Saves to Firestore."
    ),
    instruction="""
You are the Claim Summary Generator. Final agent in Pipeline 3.

READ from session context:
- final_gate_output (claim_mode, docs)
- fc1_output (structured data, verification)
- fc2_output (coverage decisions, financials)
- fc3_output (anomalies)

GENERATE PHYSICIAN REVIEW REPORT in this exact structure:

SECTION 1 — CLAIM SNAPSHOT (5 lines max)
Patient, Policy, Hospital, Diagnosis (ICD-10), Procedure, LOS, Dates

SECTION 2 — TREATMENT SUMMARY (clinical narrative, 4-6 sentences)
Write in plain English. Not ICD/CPT codes.
Cover: reason for admission, treatment received, complications, outcome, discharge status.

SECTION 3 — FINANCIAL SUMMARY
Total Billed: Rs. X
Package Applied: <name at Rs. X> OR None
Additional Approved: Rs. X (itemized)
TOTAL APPROVED: Rs. X
TOTAL REJECTED: Rs. X
Rejection table: item | billed | rejected | reason | policy clause

SECTION 4 — CASHLESS RECONCILIATION (cashless claims only)
Pre-auth total authorized: Rs. X (across N rounds)
Final settlement amount: Rs. X
Variance: Rs. X (within/outside tolerance)

SECTION 5 — ANOMALY FLAGS (HIGH and MEDIUM only)
For each: [SEVERITY] Description → Recommended physician action

SECTION 6 — RECOMMENDATION
APPROVE | PARTIAL APPROVE | INVESTIGATE
Confidence: XX%
Estimated physician review time: N minutes

CONFIDENCE CALCULATION:
base = 100
base -= (HIGH anomalies * 15)
base -= (MEDIUM anomalies * 5)
base -= (LOW anomalies * 2)
base -= (FC1 cross-check issues * 8)
confidence = max(base, 40) / 100

FOR REIMBURSEMENT — add settlement section:
Net payable to policyholder: Rs. X
Payment mode: NEFT
Bank details required: YES

SAVE to Firestore:
Call save_session_state(
    session_id=<id>,
    state_data={
        "pipeline": "FINAL_CLAIM",
        "claim_mode": <mode>,
        "final_decision": <recommendation>,
        "total_approved": <amount>,
        "total_rejected": <amount>,
        "confidence": <value>,
        "anomaly_count": <dict>,
        "status": "PENDING_PHYSICIAN_APPROVAL",
    }
)

OUTPUT:
FC4_RECOMMENDATION: APPROVE | PARTIAL_APPROVE | INVESTIGATE
FC4_CONFIDENCE: <0.0-1.0>
FC4_TOTAL_APPROVED: Rs. <X>
FC4_TOTAL_REJECTED: Rs. <X>
FC4_PHYSICIAN_REVIEW_TIME_MINUTES: <estimated minutes>

CLAIM_ANALYSIS_REPORT:
---
<complete formatted report as above>
---
""",
    tools=[save_session_state, get_session_state],
    output_key="fc4_output",
)


# ── PIPELINE 3: FINAL CLAIM ───────────────────────────────────────
final_claim_pipeline = SequentialAgent(
    name="FinalClaimPipeline",
    description=(
        "Complete final claim processing pipeline. "
        "Handles both cashless settlement (prior session exists) and reimbursement (fresh). "
        "Gate → [FC-1 verify + FC-2 coverage + FC-3 anomaly in parallel] → FC-4 summary. "
        "Trigger: FINAL_CLAIM_SUBMISSION after patient discharge."
    ),
    sub_agents=[
        final_claim_gate_agent,
        final_claim_parallel,
        fc4_summary_agent,
    ],
)
