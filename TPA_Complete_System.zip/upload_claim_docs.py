#!/usr/bin/env python3
# upload_claim_docs.py
"""
Upload claim PDF documents to GCS before sending to the agent.

Usage:
    # Upload all PDFs in a folder for a claim
    python upload_claim_docs.py --claim-id CLM-2026-089231 --folder ./cashless/

    # Upload specific files
    python upload_claim_docs.py --claim-id CLM-2026-089231 \
        --files doc1.pdf doc2.pdf doc3.pdf

    # Then run the agent:
    adk web
    # Type: "Process cashless pre-auth for claim CLM-2026-089231.
    #        Policy: HLTH-GRP-4521. Hospital: Apollo Chennai."
"""
import os
import sys
import glob
import argparse
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT")
BUCKET  = os.getenv("CLAIMS_BUCKET")


def upload_files(claim_id: str, pdf_paths: list[str]) -> list[dict]:
    """Upload PDFs to GCS and return list of GCS URIs."""
    from google.cloud import storage

    client  = storage.Client(project=PROJECT)
    bucket  = client.bucket(BUCKET)
    results = []

    print(f"\nUploading {len(pdf_paths)} documents for claim {claim_id}")
    print(f"Destination: gs://{BUCKET}/claims/{claim_id}/")
    print("─" * 60)

    for path in pdf_paths:
        if not os.path.exists(path):
            print(f"  ✗ Not found: {path}")
            continue

        filename = os.path.basename(path)
        blob_path = f"claims/{claim_id}/{filename}"
        blob = bucket.blob(blob_path)

        blob.upload_from_filename(path, content_type="application/pdf")
        gcs_uri = f"gs://{BUCKET}/{blob_path}"
        results.append({"filename": filename, "gcs_uri": gcs_uri})
        print(f"  ✓ {filename}")

    print(f"─" * 60)
    print(f"  Uploaded: {len(results)}/{len(pdf_paths)} documents")

    return results


def print_agent_message(claim_id: str, claim_type: str = "cashless"):
    """Print the message to paste into adk web."""
    messages = {
        "cashless": f"""
Process cashless pre-authorization for claim {claim_id}.
All documents have been uploaded to GCS.

Please read all documents for this claim and process the pre-authorization.
""",
        "reimbursement": f"""
Process reimbursement claim {claim_id}.
Patient paid out of pocket at a non-network hospital.
All documents have been uploaded to GCS.

Please read all documents and process the reimbursement claim.
""",
        "enhancement": f"""
Enhancement request for claim {claim_id}.
New documents have been uploaded to GCS.

Please read the new documents and process the enhancement authorization.
""",
    }

    print(f"\n{'='*60}")
    print("  PASTE THIS INTO adk web:")
    print(f"{'='*60}")
    print(messages.get(claim_type, messages["cashless"]))
    print(f"{'='*60}\n")


def main():
    parser = argparse.ArgumentParser(
        description="Upload claim PDFs to GCS for MedVerify AI"
    )
    parser.add_argument(
        "--claim-id", required=True,
        help="Claim identifier e.g. CLM-2026-089231"
    )
    parser.add_argument(
        "--folder",
        help="Folder containing PDF files to upload"
    )
    parser.add_argument(
        "--files", nargs="+",
        help="Specific PDF file paths to upload"
    )
    parser.add_argument(
        "--type", choices=["cashless", "reimbursement", "enhancement"],
        default="cashless",
        help="Claim type for agent message generation"
    )
    args = parser.parse_args()

    if not PROJECT or not BUCKET:
        print("Error: GOOGLE_CLOUD_PROJECT and CLAIMS_BUCKET must be set in .env")
        sys.exit(1)

    # Collect PDF paths
    pdf_paths = []

    if args.folder:
        pdf_paths = sorted(glob.glob(os.path.join(args.folder, "*.pdf")))
        if not pdf_paths:
            print(f"No PDF files found in: {args.folder}")
            sys.exit(1)

    if args.files:
        pdf_paths.extend(args.files)

    if not pdf_paths:
        print("Error: Provide --folder or --files")
        sys.exit(1)

    # Upload
    results = upload_files(args.claim_id, pdf_paths)

    if results:
        print("\nGCS URIs uploaded:")
        for r in results:
            print(f"  {r['gcs_uri']}")

        # Print agent message
        print_agent_message(args.claim_id, args.type)
    else:
        print("No files uploaded successfully")
        sys.exit(1)


if __name__ == "__main__":
    main()
