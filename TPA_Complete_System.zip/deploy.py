#!/usr/bin/env python3
# deploy.py
"""
Deploy MedVerify agents to Vertex AI Agent Engine.

Usage:
    python deploy.py              # deploy
    python deploy.py --query      # test deployed agent
    python deploy.py --delete     # remove deployment

After deployment, test with:
    python deploy.py --query
"""
import os
import sys
import asyncio
import argparse
from dotenv import load_dotenv

load_dotenv()

import vertexai
from vertexai.agent_engines import AdkApp

PROJECT  = os.getenv("GOOGLE_CLOUD_PROJECT")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")


def deploy():
    """Deploy the agent to Vertex AI Agent Engine."""
    from medverify.agent import root_agent

    print(f"Deploying MedVerify AI to Vertex AI Agent Engine...")
    print(f"Project: {PROJECT} | Location: {LOCATION}")

    vertexai.init(project=PROJECT, location=LOCATION)

    app = AdkApp(
        agent=root_agent,
        enable_tracing=True,
    )

    print("Creating Agent Engine deployment (this takes 2-5 minutes)...")
    deployed = app.create(
        display_name="MedVerify TPA Agent",
        requirements=[
            "google-cloud-firestore>=2.18.0",
            "google-cloud-bigquery>=3.25.0",
            "google-cloud-discoveryengine>=0.11.11",
            "google-cloud-storage>=2.18.2",
        ],
    )

    print(f"\n✓ Deployed successfully!")
    print(f"Resource name: {deployed.resource_name}")
    print(f"\nSave this for querying:")
    print(f"AGENT_RESOURCE={deployed.resource_name}")

    # Save resource name
    with open(".agent_resource", "w") as f:
        f.write(deployed.resource_name)

    return deployed.resource_name


async def query_deployed(resource_name: str, message: str):
    """Query the deployed agent."""
    import vertexai.agent_engines as agent_engines

    vertexai.init(project=PROJECT, location=LOCATION)
    app = agent_engines.get(resource_name)

    session = await app.async_create_session(user_id="test_user")
    print(f"Session: {session['id']}")

    print(f"\nQuery: {message[:100]}...")
    print("Response:")
    async for event in app.async_stream_query(
        user_id="test_user",
        session_id=session["id"],
        message=message,
    ):
        content = event.get("content", {})
        parts = content.get("parts", [])
        for part in parts:
            if "text" in part:
                print(part["text"])
            elif "function_call" in part:
                fc = part["function_call"]
                print(f"  → Tool: {fc.get('name', '')}")


def delete_deployment(resource_name: str):
    """Delete a deployed agent."""
    import vertexai.agent_engines as agent_engines

    vertexai.init(project=PROJECT, location=LOCATION)
    app = agent_engines.get(resource_name)
    app.delete(force=True)
    print(f"✓ Deleted: {resource_name}")


def main():
    parser = argparse.ArgumentParser(description="MedVerify AI deployment tool")
    parser.add_argument("--deploy",  action="store_true", help="Deploy to Agent Engine")
    parser.add_argument("--query",   action="store_true", help="Query deployed agent")
    parser.add_argument("--delete",  action="store_true", help="Delete deployment")
    parser.add_argument("--resource", type=str, help="Agent Engine resource name")
    args = parser.parse_args()

    # Load saved resource name
    resource_name = args.resource
    if not resource_name and os.path.exists(".agent_resource"):
        with open(".agent_resource") as f:
            resource_name = f.read().strip()

    if args.deploy or (not args.query and not args.delete):
        resource_name = deploy()

    if args.query:
        if not resource_name:
            print("Error: No resource name. Deploy first or provide --resource")
            sys.exit(1)
        asyncio.run(query_deployed(
            resource_name,
            "Patient Rajesh Kumar admitted at Apollo Chennai with STEMI. "
            "Policy HLTH-GRP-4521. Please process cashless pre-authorization "
            "for PTCA with drug-eluting stent."
        ))

    if args.delete:
        if not resource_name:
            print("Error: No resource name to delete")
            sys.exit(1)
        delete_deployment(resource_name)


if __name__ == "__main__":
    main()
