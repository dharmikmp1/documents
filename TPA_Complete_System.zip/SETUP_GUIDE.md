# MedVerify AI — Complete Setup Guide
# From zero to running in one day

## Architecture Overview

```
PDFs dropped into GCS
        ↓ MANIFEST.json triggers Eventarc
Cloud Run Function (trigger/main.py)
        ↓ calls Agent Engine
Vertex AI Agent Engine (medverify/)
        ↓ reads PDFs, runs pipelines
        ↓ writes results to Firestore
Doctor Review UI (ui/)
        ↓ real-time Firestore listener
Physician approves/rejects
```

---

## STEP 1 — GCP Setup (run once)

```bash
cd medverify_agents/
chmod +x setup.sh
./setup.sh your-project-id
```

---

## STEP 2 — Index RAG Documents in Vertex AI Search

1. Go to GCP Console → Agent Builder → Data Stores
2. For each data store, click Import Documents
3. Select: Cloud Storage
4. Point to: gs://your-project-medverify-rag-corpus/
5. Select the corresponding PDF:
   - treatment-packages → 02_gipsa_treatment_packages.pdf
   - policy-inclusions-exclusions → 01_policy_inclusions_exclusions.pdf
   - hospital-registry → 03_network_hospital_directory.pdf
6. Wait for indexing (~10 min each)

---

## STEP 3 — Deploy the Agent

```bash
pip install -r requirements.txt

# Deploy to Agent Engine
python deploy.py

# Note the resource name printed — looks like:
# projects/123/locations/us-central1/reasoningEngines/456
# Save this as AGENT_ENGINE_RESOURCE
```

---

## STEP 4 — Deploy the GCS Trigger

```bash
cd trigger/
chmod +x deploy_trigger.sh
./deploy_trigger.sh your-project-id "projects/123/.../reasoningEngines/456"
```

---

## STEP 5 — Set Up Firebase for the UI

1. Go to Firebase Console → Add Project (select your GCP project)
2. Enable Firestore Database (Native mode)
3. Add a Web App → copy the config
4. Set Firestore Security Rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /claim_sessions/{claimId} {
      allow read: if true;   // doctors can read all claims
      allow write: if true;  // simplify for prototype
    }
  }
}
```

---

## STEP 6 — Run the Doctor Review UI

```bash
cd ui/

# Copy and fill env file
cp .env.template .env
# Edit .env with your Firebase config

npm install
npm start
# Opens at http://localhost:3000
```

---

## STEP 7 — Test the Full Flow

### Cashless Pre-Auth

```bash
# Upload PDFs
gsutil cp sample_docs/cashless/*.pdf \
  gs://your-project-medverify-claims/claims/cashless/CLM-2026-001/

# Upload MANIFEST last (this fires the trigger!)
gsutil cp trigger/MANIFEST_cashless_example.json \
  gs://your-project-medverify-claims/claims/cashless/CLM-2026-001/MANIFEST.json
```

Watch the UI at http://localhost:3000 — within 60 seconds you should see:
- Claim appears in "Processing" tab
- Moves to "Pending Review" when agent completes
- Click claim → see AI analysis, anomaly flags, financial summary
- Click Approve/Partial/Query/Decline

### Reimbursement Claim

```bash
gsutil cp sample_docs/reimbursement/*.pdf \
  gs://your-project-medverify-claims/claims/reimbursement/CLM-2026-002/

gsutil cp trigger/MANIFEST_reimbursement_example.json \
  gs://your-project-medverify-claims/claims/reimbursement/CLM-2026-002/MANIFEST.json
```

### Enhancement (during active cashless admission)

Create a MANIFEST with claim_type: "enhancement" and the session_id
of the original pre-auth, then upload new clinical documents.

---

## GCS Folder Structure

```
gs://your-project-medverify-claims/
├── claims/
│   ├── cashless/
│   │   └── CLM-2026-001/
│   │       ├── MANIFEST.json          ← upload LAST (triggers pipeline)
│   │       ├── 01_preauth_form.pdf
│   │       ├── 02_admission_note.pdf
│   │       └── ...
│   └── reimbursement/
│       └── CLM-2026-002/
│           ├── MANIFEST.json
│           └── all_documents.pdf...
│
└── rag-corpus/
    ├── 01_policy_inclusions_exclusions.pdf
    ├── 02_gipsa_treatment_packages.pdf
    └── 03_network_hospital_directory.pdf
```

---

## MANIFEST.json Fields Reference

| Field | Required | Description |
|-------|----------|-------------|
| claim_id | YES | Unique claim identifier |
| claim_type | YES | cashless_preauth / enhancement / cashless_final / reimbursement |
| policy_id | YES | Insurance policy number |
| patient_name | YES | Full patient name |
| hospital_id | YES | Hospital identifier |
| hospital_name | YES | Hospital display name |
| hospital_tier | YES | 1, 2, or 3 |
| documents | YES | List of PDF filenames in the same folder |
| diagnosis_icd10 | Recommended | ICD-10 code |
| estimated_cost | Cashless | Estimated cost in rupees |
| session_id | Enhancement | Original pre-auth session |
| total_amount_paid | Reimbursement | Amount paid out of pocket |
| notes | Optional | Additional context for agents |

---

## Troubleshooting

**Trigger not firing:**
- Check Cloud Functions logs in GCP Console
- Verify MANIFEST.json path: claims/{type}/{claim_id}/MANIFEST.json
- Check Eventarc trigger is active

**Agent not responding:**
- Verify AGENT_ENGINE_RESOURCE env var is set correctly
- Check Agent Engine logs in Vertex AI console

**UI not updating:**
- Check Firebase config in ui/.env
- Verify Firestore security rules allow reads
- Open browser console for errors
