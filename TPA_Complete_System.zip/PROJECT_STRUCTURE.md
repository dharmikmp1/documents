# MedVerify AI — Agent System
# Complete GCP Vertex AI ADK Implementation

medverify_agents/
├── .env                          # GCP config
├── requirements.txt              # Dependencies
├── setup.sh                      # One-shot GCP setup
│
├── medverify/                    # Main agent package (ADK requires this structure)
│   ├── __init__.py               # Exports root_agent
│   ├── agent.py                  # Root orchestrator (root_agent lives here)
│   │
│   ├── tools/                    # All tool functions
│   │   ├── __init__.py
│   │   ├── policy_tools.py       # Policy DB, eligibility, limits
│   │   ├── rag_tools.py          # Vertex AI Search wrappers
│   │   ├── document_tools.py     # Vision API, Document AI
│   │   ├── firestore_tools.py    # Session state CRUD
│   │   └── output_tools.py       # Letter generation, routing
│   │
│   ├── pipelines/                # The three pipelines
│   │   ├── __init__.py
│   │   ├── cashless.py           # Pipeline 1 — Gate+PA1+PA2+PA3+PA4
│   │   ├── enhancement.py        # Pipeline 2 — Gate+ENH1+ENH2+ENH3+ENH4
│   │   └── final_claim.py        # Pipeline 3 — Gate+FC1+FC2+FC3+FC4
│   │
│   └── prompts/                  # All agent instructions (clean separation)
│       ├── __init__.py
│       ├── gate_prompts.py
│       ├── cashless_prompts.py
│       ├── enhancement_prompts.py
│       └── final_claim_prompts.py
│
└── tests/
    └── test_runner.py            # Local test with adk web
