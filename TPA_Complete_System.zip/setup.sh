#!/bin/bash
# MedVerify AI — Complete GCP Setup Script
# Run once: ./setup.sh your-project-id
set -e

PROJECT_ID=${1:?Usage: ./setup.sh YOUR_PROJECT_ID}
REGION="us-central1"
CLAIMS_BUCKET="${PROJECT_ID}-medverify-claims"
RAG_BUCKET="${PROJECT_ID}-medverify-rag-corpus"

echo "=================================================="
echo " MedVerify AI — Complete GCP Setup"
echo " Project: $PROJECT_ID | Region: $REGION"
echo "=================================================="

gcloud config set project $PROJECT_ID
PROJECT_NUMBER=$(gcloud projects describe $PROJECT_ID --format="value(projectNumber)")

echo ""
echo "[1/9] Enabling ALL required APIs..."
gcloud services enable \
  aiplatform.googleapis.com \
  discoveryengine.googleapis.com \
  firestore.googleapis.com \
  bigquery.googleapis.com \
  storage.googleapis.com \
  vision.googleapis.com \
  cloudfunctions.googleapis.com \
  cloudbuild.googleapis.com \
  eventarc.googleapis.com \
  run.googleapis.com \
  pubsub.googleapis.com \
  cloudtasks.googleapis.com \
  secretmanager.googleapis.com \
  --quiet
echo "  ✓ All 13 APIs enabled"

echo ""
echo "[2/9] Creating service accounts..."

gcloud iam service-accounts create medverify-agent-sa \
  --display-name="MedVerify Agent" --quiet 2>/dev/null || true
AGENT_SA="medverify-agent-sa@${PROJECT_ID}.iam.gserviceaccount.com"

for ROLE in roles/aiplatform.user roles/discoveryengine.admin \
  roles/datastore.user roles/bigquery.dataEditor \
  roles/storage.objectAdmin roles/cloudtasks.enqueuer; do
  gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:${AGENT_SA}" --role="$ROLE" --quiet > /dev/null
done

gcloud iam service-accounts create medverify-trigger-sa \
  --display-name="MedVerify GCS Trigger" --quiet 2>/dev/null || true
TRIGGER_SA="medverify-trigger-sa@${PROJECT_ID}.iam.gserviceaccount.com"

for ROLE in roles/eventarc.eventReceiver roles/run.invoker \
  roles/datastore.user roles/aiplatform.user roles/storage.objectViewer; do
  gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:${TRIGGER_SA}" --role="$ROLE" --quiet > /dev/null
done

# Allow GCS to publish to Pub/Sub for Eventarc
GCS_SA=$(gsutil kms serviceaccount -p $PROJECT_ID)
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:${GCS_SA}" \
  --role="roles/pubsub.publisher" --quiet > /dev/null

echo "  ✓ Service accounts and IAM configured"

echo ""
echo "[3/9] Creating Cloud Storage buckets..."
gsutil mb -p $PROJECT_ID -l $REGION gs://$CLAIMS_BUCKET 2>/dev/null || true
gsutil mb -p $PROJECT_ID -l $REGION gs://$RAG_BUCKET    2>/dev/null || true
echo "" | gsutil cp - gs://$CLAIMS_BUCKET/claims/cashless/.keep      2>/dev/null || true
echo "" | gsutil cp - gs://$CLAIMS_BUCKET/claims/reimbursement/.keep 2>/dev/null || true
echo "" | gsutil cp - gs://$CLAIMS_BUCKET/claims/enhancement/.keep   2>/dev/null || true
echo "  ✓ Buckets ready: gs://$CLAIMS_BUCKET/"
echo "  ✓ Folders: claims/cashless/ | claims/reimbursement/ | claims/enhancement/"

echo ""
echo "[4/9] Initializing Firestore (Native mode)..."
gcloud firestore databases create --location=$REGION --quiet 2>/dev/null || true
echo "  ✓ Firestore ready — collection: claim_sessions"

echo ""
echo "[5/9] Creating BigQuery audit dataset and table..."
bq --location=$REGION mk --dataset ${PROJECT_ID}:tpa_audit 2>/dev/null || true

cat > /tmp/bq_schema.json << 'SCHEMA'
[
  {"name":"session_id","type":"STRING","mode":"REQUIRED"},
  {"name":"claim_id","type":"STRING","mode":"REQUIRED"},
  {"name":"pipeline","type":"STRING","mode":"NULLABLE"},
  {"name":"agent_name","type":"STRING","mode":"NULLABLE"},
  {"name":"event_type","type":"STRING","mode":"NULLABLE"},
  {"name":"decision","type":"STRING","mode":"NULLABLE"},
  {"name":"confidence","type":"FLOAT64","mode":"NULLABLE"},
  {"name":"amount_approved","type":"INT64","mode":"NULLABLE"},
  {"name":"rag_sources_used","type":"JSON","mode":"NULLABLE"},
  {"name":"anomalies_flagged","type":"JSON","mode":"NULLABLE"},
  {"name":"agent_output","type":"JSON","mode":"NULLABLE"},
  {"name":"processing_time_ms","type":"INT64","mode":"NULLABLE"},
  {"name":"physician_name","type":"STRING","mode":"NULLABLE"},
  {"name":"physician_decision","type":"STRING","mode":"NULLABLE"},
  {"name":"timestamp","type":"TIMESTAMP","mode":"REQUIRED"}
]
SCHEMA

bq mk --table --time_partitioning_field timestamp \
  --schema /tmp/bq_schema.json \
  ${PROJECT_ID}:tpa_audit.agent_decisions 2>/dev/null || true
echo "  ✓ BigQuery: tpa_audit.agent_decisions (date-partitioned)"

echo ""
echo "[6/9] Uploading RAG corpus PDFs to GCS..."
RAG_SOURCE="../sample_docs/rag_corpus"
if [ -d "$RAG_SOURCE" ]; then
  gsutil -m cp ${RAG_SOURCE}/*.pdf gs://$RAG_BUCKET/
  echo "  ✓ RAG PDFs uploaded to gs://$RAG_BUCKET/"
  gsutil ls gs://$RAG_BUCKET/
else
  echo "  ⚠ Not found: $RAG_SOURCE"
  echo "    Run first: cd ../sample_docs/rag_corpus && python gen_policy.py && python gen_gipsa.py && python gen_hospitals.py"
fi

echo ""
echo "[7/9] Creating Vertex AI Search data stores (Discovery Engine)..."
python3 - << 'PYEOF'
import time, os, sys
from google.cloud import discoveryengine_v1 as de

PROJECT  = os.environ.get("PROJECT_ID_PY")
LOCATION = "global"
parent   = f"projects/{PROJECT}/locations/{LOCATION}/collections/default_collection"

STORES = [
    ("treatment-packages",          "GIPSA Treatment Packages"),
    ("policy-inclusions-exclusions","Policy Inclusions & Exclusions"),
    ("hospital-registry",           "Network Hospital Directory"),
    ("document-checklists",         "Document Checklists"),
    ("medical-guidelines",          "Medical Guidelines & LOS"),
]

client = de.DataStoreServiceClient()
for store_id, display in STORES:
    try:
        op = client.create_data_store(request=de.CreateDataStoreRequest(
            parent=parent,
            data_store=de.DataStore(
                display_name=display,
                industry_vertical=de.IndustryVertical.GENERIC,
                solution_types=[de.SolutionType.SOLUTION_TYPE_SEARCH],
                content_config=de.DataStore.ContentConfig.CONTENT_REQUIRED,
            ),
            data_store_id=store_id,
        ))
        op.result(timeout=120)
        print(f"  ✓ Created: {store_id}")
    except Exception as e:
        if "already exists" in str(e).lower():
            print(f"  (exists): {store_id}")
        else:
            print(f"  ✗ Failed {store_id}: {e}")
    time.sleep(2)
PYEOF
PROJECT_ID_PY=$PROJECT_ID python3 - << 'PYEOF'
import os; print(f"  Data stores in project: {os.environ.get('PROJECT_ID_PY')}")
PYEOF

echo ""
echo "[8/9] Importing RAG PDFs into data stores (indexing starts now)..."
PROJECT_ID_PY=$PROJECT_ID RAG_BUCKET_PY=$RAG_BUCKET python3 - << 'PYEOF'
import os, time
from google.cloud import discoveryengine_v1 as de

PROJECT   = os.environ["PROJECT_ID_PY"]
RAG_BUCKET = os.environ["RAG_BUCKET_PY"]
LOCATION  = "global"

IMPORTS = [
    ("treatment-packages",          f"gs://{RAG_BUCKET}/02_gipsa_treatment_packages.pdf"),
    ("policy-inclusions-exclusions",f"gs://{RAG_BUCKET}/01_policy_inclusions_exclusions.pdf"),
    ("hospital-registry",           f"gs://{RAG_BUCKET}/03_network_hospital_directory.pdf"),
    ("document-checklists",         f"gs://{RAG_BUCKET}/01_policy_inclusions_exclusions.pdf"),
    ("medical-guidelines",          f"gs://{RAG_BUCKET}/02_gipsa_treatment_packages.pdf"),
]

client = de.DocumentServiceClient()
for store_id, gcs_uri in IMPORTS:
    parent = (f"projects/{PROJECT}/locations/{LOCATION}"
              f"/collections/default_collection"
              f"/dataStores/{store_id}/branches/default_branch")
    try:
        op = client.import_documents(request=de.ImportDocumentsRequest(
            parent=parent,
            gcs_source=de.GcsSource(input_uris=[gcs_uri], data_schema="content"),
            reconciliation_mode=de.ImportDocumentsRequest.ReconciliationMode.INCREMENTAL,
        ))
        print(f"  ✓ Import started: {store_id}")
        print(f"    From: {gcs_uri}")
    except Exception as e:
        print(f"  ✗ Failed {store_id}: {e}")
    time.sleep(1)

print("")
print("  Indexing runs in background (10-20 min per store).")
print("  Monitor: GCP Console → Agent Builder → Data Stores")
PYEOF

echo ""
echo "[9/9] Writing .env configuration..."
cat > .env << EOF
# MedVerify AI — Generated by setup.sh on $(date)

GOOGLE_CLOUD_PROJECT=${PROJECT_ID}
GOOGLE_CLOUD_LOCATION=${REGION}
GOOGLE_GENAI_USE_VERTEXAI=TRUE

CLAIMS_BUCKET=${CLAIMS_BUCKET}
RAG_CORPUS_BUCKET=${RAG_BUCKET}

DATASTORE_TREATMENT_PACKAGES=treatment-packages
DATASTORE_POLICY_INCLUSIONS=policy-inclusions-exclusions
DATASTORE_HOSPITAL_REGISTRY=hospital-registry
DATASTORE_DOCUMENT_CHECKLISTS=document-checklists
DATASTORE_MEDICAL_GUIDELINES=medical-guidelines

FIRESTORE_DATABASE=(default)
BIGQUERY_DATASET=tpa_audit

GEMINI_PRO_MODEL=gemini-2.0-flash-001
GEMINI_FLASH_MODEL=gemini-2.0-flash-001

AGENT_SA=${AGENT_SA}
TRIGGER_SA=${TRIGGER_SA}

# Set this AFTER running: python deploy.py
# AGENT_ENGINE_RESOURCE=projects/${PROJECT_NUMBER}/locations/${REGION}/reasoningEngines/YOUR_ID
EOF
echo "  ✓ .env written"

echo ""
echo "=================================================="
echo " ✓ Setup Complete!"
echo ""
echo " WHAT WAS CREATED:"
echo "   API: 13 GCP services enabled"
echo "   IAM: medverify-agent-sa + medverify-trigger-sa"
echo "   GCS: gs://$CLAIMS_BUCKET/claims/{cashless|reimbursement|enhancement}/"
echo "   GCS: gs://$RAG_BUCKET/ (RAG PDFs)"
echo "   DB:  Firestore (default) — claim_sessions collection"
echo "   BQ:  tpa_audit.agent_decisions (date-partitioned)"
echo "   RAG: 5 Vertex AI Search data stores (indexing...)"
echo "   ENV: .env file written"
echo ""
echo " NEXT STEPS:"
echo "   1. Wait ~20 min for RAG indexing"
echo "      GCP Console → Agent Builder → Data Stores"
echo ""
echo "   2. pip install -r requirements.txt"
echo ""
echo "   3. Test locally:  adk web"
echo ""
echo "   4. Deploy agent:  python deploy.py"
echo "      (Save the resource name printed)"
echo ""
echo "   5. Deploy trigger:"
echo "      cd trigger/"
echo "      ./deploy_trigger.sh $PROJECT_ID <AGENT_ENGINE_RESOURCE>"
echo ""
echo "   6. Run Doctor UI:"
echo "      cd ui && cp .env.template .env"
echo "      # Fill Firebase config in .env"
echo "      npm install && npm start"
echo ""
echo "   7. Test claim pipeline:"
echo "      gsutil cp sample_docs/cashless/*.pdf gs://$CLAIMS_BUCKET/claims/cashless/CLM-TEST-001/"
echo "      gsutil cp trigger/MANIFEST_cashless_example.json gs://$CLAIMS_BUCKET/claims/cashless/CLM-TEST-001/MANIFEST.json"
echo "=================================================="
