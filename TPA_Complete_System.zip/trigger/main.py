# trigger/main.py
"""
MedVerify AI — GCS Event Trigger
Cloud Run Function triggered by Eventarc when MANIFEST.json is uploaded to GCS.

Trigger path pattern:
  claims/cashless/{claim_id}/MANIFEST.json    → cashless_preauth or enhancement
  claims/reimbursement/{claim_id}/MANIFEST.json → reimbursement

Flow:
  1. Parse CloudEvent from Eventarc (GCS object.finalized)
  2. Check if uploaded file is MANIFEST.json
  3. Read MANIFEST.json from GCS
  4. Determine pipeline type from manifest
  5. Call Agent Engine async
  6. Write initial session to Firestore
  7. Return 200 immediately (agent runs async)
"""
import os
import json
import asyncio
import logging
from datetime import datetime

import functions_framework
from cloudevents.http import CloudEvent

from google.cloud import storage, firestore
import vertexai

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PROJECT   = os.getenv("GOOGLE_CLOUD_PROJECT")
LOCATION  = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
AGENT_RESOURCE = os.getenv("AGENT_ENGINE_RESOURCE")  # set after deploy


@functions_framework.cloud_event
def gcs_trigger(cloud_event: CloudEvent):
    """
    Triggered by Eventarc when any file is finalized in the claims bucket.
    Only processes MANIFEST.json files — ignores all other uploads.
    """
    data = cloud_event.data
    bucket_name = data["bucket"]
    object_name = data["name"]

    logger.info(f"GCS event: gs://{bucket_name}/{object_name}")

    # Only process MANIFEST.json files
    if not object_name.endswith("/MANIFEST.json") and object_name != "MANIFEST.json":
        logger.info(f"Ignoring non-manifest file: {object_name}")
        return "ignored", 200

    # Parse path: claims/{claim_type}/{claim_id}/MANIFEST.json
    parts = object_name.split("/")
    if len(parts) < 3:
        logger.warning(f"Unexpected path structure: {object_name}")
        return "bad path", 400

    folder_claim_type = parts[1] if len(parts) >= 4 else "unknown"
    claim_id_from_path = parts[2] if len(parts) >= 4 else parts[1]

    logger.info(f"Processing manifest for claim: {claim_id_from_path}")

    # Read MANIFEST.json content
    manifest = _read_manifest(bucket_name, object_name)
    if not manifest:
        return "manifest read failed", 500

    # Determine pipeline
    claim_type = manifest.get("claim_type", folder_claim_type)
    claim_id   = manifest.get("claim_id", claim_id_from_path)

    # Create initial Firestore session
    _create_initial_session(claim_id, manifest, object_name)

    # Trigger agent async (don't wait — return 200 immediately)
    asyncio.run(_trigger_agent(claim_id, manifest, bucket_name))

    logger.info(f"Pipeline triggered for {claim_id} ({claim_type})")
    return f"Pipeline triggered: {claim_id}", 200


def _read_manifest(bucket_name: str, object_name: str) -> dict | None:
    """Read and parse MANIFEST.json from GCS."""
    try:
        client = storage.Client(project=PROJECT)
        bucket = client.bucket(bucket_name)
        blob   = bucket.blob(object_name)
        content = blob.download_as_text()
        return json.loads(content)
    except Exception as e:
        logger.error(f"Failed to read manifest: {e}")
        return None


def _create_initial_session(
    claim_id: str,
    manifest: dict,
    manifest_gcs_path: str,
) -> None:
    """Write initial claim session to Firestore when trigger fires."""
    try:
        db = firestore.Client(project=PROJECT)
        doc_ref = db.collection("claim_sessions").document(claim_id)

        doc_ref.set({
            "claim_id":         claim_id,
            "claim_type":       manifest.get("claim_type", "unknown"),
            "policy_id":        manifest.get("policy_id", ""),
            "member_id":        manifest.get("member_id", ""),
            "patient_name":     manifest.get("patient_name", ""),
            "hospital_id":      manifest.get("hospital_id", ""),
            "hospital_name":    manifest.get("hospital_name", ""),
            "hospital_tier":    manifest.get("hospital_tier", 1),
            "diagnosis_icd10":  manifest.get("diagnosis_icd10", ""),
            "documents":        manifest.get("documents", []),
            "status":           "TRIGGER_RECEIVED",
            "pipeline":         manifest.get("claim_type", "unknown"),
            "manifest_path":    manifest_gcs_path,
            "submitted_by":     manifest.get("submitted_by", ""),
            "triggered_at":     datetime.utcnow().isoformat(),
            "last_updated":     datetime.utcnow().isoformat(),
            "agent_processing": True,
        })
        logger.info(f"Initial session created: {claim_id}")
    except Exception as e:
        logger.error(f"Failed to create Firestore session: {e}")


async def _trigger_agent(
    claim_id: str,
    manifest: dict,
    bucket_name: str,
) -> None:
    """Call Agent Engine with claim details. Runs async."""
    if not AGENT_RESOURCE:
        logger.warning("AGENT_ENGINE_RESOURCE not set — skipping agent call")
        _update_session_status(
            claim_id, "ERROR",
            "Agent Engine resource not configured"
        )
        return

    try:
        vertexai.init(project=PROJECT, location=LOCATION)
        import vertexai.agent_engines as ae

        app = ae.get(AGENT_RESOURCE)

        # Create session for this claim
        session = await app.async_create_session(user_id=claim_id)

        # Build message from manifest
        claim_type = manifest.get("claim_type", "cashless_preauth")
        message    = _build_agent_message(manifest, bucket_name)

        logger.info(f"Calling agent for {claim_id}, type: {claim_type}")

        # Update session with agent session ID
        _update_session_status(
            claim_id, "AGENT_PROCESSING",
            agent_session_id=session["id"]
        )

        # Stream agent response
        final_response = ""
        async for event in app.async_stream_query(
            user_id=claim_id,
            session_id=session["id"],
            message=message,
        ):
            content = event.get("content", {})
            parts   = content.get("parts", [])
            for part in parts:
                if "text" in part:
                    final_response += part["text"]

        # Save final response to Firestore
        _save_agent_result(claim_id, final_response, session["id"])
        logger.info(f"Agent completed for {claim_id}")

    except Exception as e:
        logger.error(f"Agent call failed for {claim_id}: {e}")
        _update_session_status(claim_id, "AGENT_ERROR", str(e))


def _build_agent_message(manifest: dict, bucket_name: str) -> str:
    """Build the message to send to the agent based on manifest content."""
    claim_id   = manifest.get("claim_id", "")
    claim_type = manifest.get("claim_type", "")
    docs       = manifest.get("documents", [])

    base_path  = f"gs://{bucket_name}/claims"
    folder     = "cashless" if "cashless" in claim_type else "reimbursement"
    gcs_prefix = f"{base_path}/{folder}/{claim_id}/"
    gcs_uris   = [f"{gcs_prefix}{doc}" for doc in docs]

    type_messages = {
        "cashless_preauth": (
            f"Process CASHLESS PRE-AUTHORIZATION for claim {claim_id}.\n"
            f"Policy: {manifest.get('policy_id')}\n"
            f"Patient: {manifest.get('patient_name')}\n"
            f"Hospital: {manifest.get('hospital_name')} "
            f"(ID: {manifest.get('hospital_id')}, Tier {manifest.get('hospital_tier')})\n"
            f"Diagnosis: {manifest.get('provisional_diagnosis')} "
            f"(ICD-10: {manifest.get('diagnosis_icd10')})\n"
            f"Estimated Cost: Rs. {manifest.get('estimated_cost', 0):,}\n"
            f"Notes: {manifest.get('notes', '')}\n\n"
            f"Documents in GCS:\n" + "\n".join(f"  - {uri}" for uri in gcs_uris)
        ),
        "enhancement": (
            f"ENHANCEMENT REQUEST for claim {claim_id}.\n"
            f"Original Session: {manifest.get('session_id', claim_id)}\n"
            f"Enhancement Type: {manifest.get('enhancement_type', 'Not specified')}\n"
            f"Clinical Reason: {manifest.get('clinical_reason', '')}\n"
            f"New documents:\n" + "\n".join(f"  - {uri}" for uri in gcs_uris)
        ),
        "cashless_final": (
            f"FINAL CLAIM SETTLEMENT for cashless claim {claim_id}.\n"
            f"Policy: {manifest.get('policy_id')}\n"
            f"Patient: {manifest.get('patient_name')}\n"
            f"Discharge Date: {manifest.get('discharge_date', 'Not specified')}\n"
            f"Documents:\n" + "\n".join(f"  - {uri}" for uri in gcs_uris)
        ),
        "reimbursement": (
            f"REIMBURSEMENT CLAIM for {claim_id}.\n"
            f"Policy: {manifest.get('policy_id')}\n"
            f"Patient: {manifest.get('patient_name')}\n"
            f"Hospital: {manifest.get('hospital_name')} (NON-NETWORK)\n"
            f"Diagnosis: {manifest.get('diagnosis')} "
            f"(ICD-10: {manifest.get('diagnosis_icd10')})\n"
            f"Admission: {manifest.get('admission_date')} | "
            f"Discharge: {manifest.get('discharge_date')}\n"
            f"Total Paid: Rs. {manifest.get('total_amount_paid', 0):,}\n"
            f"Bank: {manifest.get('bank_account', 'Not provided')}\n"
            f"All documents:\n" + "\n".join(f"  - {uri}" for uri in gcs_uris)
        ),
    }

    return type_messages.get(claim_type, f"Process claim {claim_id}: {manifest}")


def _update_session_status(
    claim_id: str,
    status: str,
    message: str = "",
    agent_session_id: str = "",
) -> None:
    """Update Firestore session status."""
    try:
        db = firestore.Client(project=PROJECT)
        update = {
            "status":       status,
            "last_updated": datetime.utcnow().isoformat(),
        }
        if message:
            update["status_message"] = message
        if agent_session_id:
            update["agent_session_id"] = agent_session_id

        db.collection("claim_sessions").document(claim_id).update(update)
    except Exception as e:
        logger.error(f"Status update failed for {claim_id}: {e}")


def _save_agent_result(
    claim_id: str,
    agent_response: str,
    agent_session_id: str,
) -> None:
    """Save agent's final output to Firestore and mark as pending review."""
    try:
        db = firestore.Client(project=PROJECT)

        # Parse key fields from agent response
        status = "PENDING_PHYSICIAN_REVIEW"
        amount = 0
        decision = "PENDING"

        if "APPROVED" in agent_response.upper():
            decision = "APPROVED" if "WITH_CONDITIONS" not in agent_response.upper() else "APPROVED_WITH_CONDITIONS"
        elif "DECLINED" in agent_response.upper():
            decision = "DECLINED"
            status   = "DECLINED"
        elif "QUERY" in agent_response.upper():
            decision = "QUERY"

        db.collection("claim_sessions").document(claim_id).update({
            "status":              status,
            "ai_decision":         decision,
            "ai_response":         agent_response[:5000],
            "agent_session_id":    agent_session_id,
            "agent_processing":    False,
            "pending_review":      True,
            "last_updated":        datetime.utcnow().isoformat(),
            "ready_for_physician": True,
        })
    except Exception as e:
        logger.error(f"Failed to save agent result for {claim_id}: {e}")
