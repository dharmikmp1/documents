#!/bin/bash
# trigger/deploy_trigger.sh
# Deploy the GCS → Agent pipeline trigger
# Run AFTER deploying the agent (deploy.py) and getting AGENT_ENGINE_RESOURCE

set -e

PROJECT_ID=${1:?Usage: ./deploy_trigger.sh YOUR_PROJECT_ID YOUR_AGENT_RESOURCE}
AGENT_RESOURCE=${2:?Usage: ./deploy_trigger.sh YOUR_PROJECT_ID YOUR_AGENT_RESOURCE}
REGION="us-central1"
BUCKET="${PROJECT_ID}-medverify-claims"
FUNCTION_NAME="medverify-gcs-trigger"
SA_NAME="medverify-trigger-sa"
SA_EMAIL="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"

echo "================================================"
echo " MedVerify Trigger Deployment"
echo " Project:  $PROJECT_ID"
echo " Bucket:   $BUCKET"
echo " Agent:    $AGENT_RESOURCE"
echo "================================================"

gcloud config set project $PROJECT_ID

# ── Enable APIs ──────────────────────────────────────────────────
echo "[1/5] Enabling APIs..."
gcloud services enable \
  cloudfunctions.googleapis.com \
  cloudbuild.googleapis.com \
  eventarc.googleapis.com \
  run.googleapis.com \
  --quiet
echo "  ✓ APIs enabled"

# ── Service Account ──────────────────────────────────────────────
echo "[2/5] Creating trigger service account..."
gcloud iam service-accounts create $SA_NAME \
  --display-name="MedVerify GCS Trigger" --quiet 2>/dev/null || true

for ROLE in \
  roles/eventarc.eventReceiver \
  roles/run.invoker \
  roles/datastore.user \
  roles/aiplatform.user \
  roles/storage.objectViewer; do
  gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:${SA_EMAIL}" \
    --role="$ROLE" --quiet > /dev/null
done

# Allow GCS to publish to Pub/Sub (for Eventarc)
GCS_SA=$(gsutil kms serviceaccount -p $PROJECT_ID)
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:${GCS_SA}" \
  --role="roles/pubsub.publisher" --quiet > /dev/null

echo "  ✓ Service account ready"

# ── Deploy Cloud Run Function ─────────────────────────────────────
echo "[3/5] Deploying Cloud Run trigger function..."
gcloud functions deploy $FUNCTION_NAME \
  --gen2 \
  --runtime=python312 \
  --region=$REGION \
  --source=. \
  --entry-point=gcs_trigger \
  --trigger-event-filters="type=google.cloud.storage.object.v1.finalized" \
  --trigger-event-filters="bucket=${BUCKET}" \
  --trigger-location=$REGION \
  --service-account=$SA_EMAIL \
  --set-env-vars="GOOGLE_CLOUD_PROJECT=${PROJECT_ID},GOOGLE_CLOUD_LOCATION=${REGION},AGENT_ENGINE_RESOURCE=${AGENT_RESOURCE}" \
  --timeout=540 \
  --memory=512MB \
  --quiet

echo "  ✓ Trigger function deployed"

# ── Test by uploading a manifest ─────────────────────────────────
echo "[4/5] Creating test claim folder structure in GCS..."

# Cashless folder structure
gsutil mb -p $PROJECT_ID gs://${BUCKET}/claims/cashless/ 2>/dev/null || true
gsutil mb -p $PROJECT_ID gs://${BUCKET}/claims/reimbursement/ 2>/dev/null || true

echo "  ✓ Folder structure ready"

echo "[5/5] Setup complete!"
echo ""
echo "================================================"
echo " HOW TO TRIGGER A PIPELINE:"
echo ""
echo " 1. Upload PDFs to GCS:"
echo "    gsutil cp *.pdf gs://${BUCKET}/claims/cashless/CLM-001/"
echo ""
echo " 2. Upload MANIFEST.json last (this fires the trigger):"
echo "    gsutil cp MANIFEST.json gs://${BUCKET}/claims/cashless/CLM-001/"
echo ""
echo " 3. Watch Firestore for real-time updates:"
echo "    → Firebase Console → claim_sessions collection"
echo ""
echo " 4. Doctor review UI:"
echo "    → Run: cd ../ui && npm start"
echo "================================================"
