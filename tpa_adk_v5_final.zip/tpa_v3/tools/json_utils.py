"""
tools/json_utils.py
-------------------
Bullet-proof JSON extraction for LLM responses.

5-layer extraction cascade (stops at first success):
  1. Direct parse of full stripped text.
  2. Parse after stripping ALL markdown fence variants.
  3. Extract LAST {...} block (handles preamble text before JSON).
  4. Greedy first-{ to last-} span (handles partial/truncated responses).
  5. Try [...] array block → wrap in {"items": [...]}.

Repair steps applied before each parse attempt:
  - Strip markdown fences
  - Remove trailing commas before } or ]
  - Remove JavaScript-style comments (// and /* */)
  - Fix unquoted keys (basic heuristic)

Never raises — always returns a dict.
"""

from __future__ import annotations
import json
import logging
import re

logger = logging.getLogger(__name__)


# ── repair helpers ────────────────────────────────────────────────────────────

def _strip_fences(text: str) -> str:
    """Remove ```json, ```python, ``` and similar markdown code fences."""
    text = re.sub(r"```[a-zA-Z0-9_\-]*\s*", "", text)
    text = re.sub(r"```", "", text)
    return text.strip()


def _remove_comments(text: str) -> str:
    """Strip // line-comments and /* */ block-comments (common LLM mistake)."""
    # Block comments
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    # Line comments — only outside strings (simplified: remove // lines)
    text = re.sub(r"//[^\n]*", "", text)
    return text


def _fix_trailing_commas(text: str) -> str:
    """Remove trailing commas before } or ] — common LLM output error."""
    return re.sub(r",\s*([}\]])", r"\1", text)


def _repair(text: str) -> str:
    """Apply all repair steps in sequence."""
    text = _strip_fences(text)
    text = _remove_comments(text)
    text = _fix_trailing_commas(text)
    return text.strip()


def _try_parse(text: str) -> dict | list | None:
    """Attempt JSON parse after repair; return None on failure."""
    repaired = _repair(text)
    if not repaired:
        return None
    try:
        return json.loads(repaired)
    except json.JSONDecodeError:
        return None


def _wrap(result) -> dict | None:
    """Normalise a parsed value to a dict, or None if not parseable."""
    if isinstance(result, dict):
        return result
    if isinstance(result, list):
        return {"items": result}
    return None


# ── public API ────────────────────────────────────────────────────────────────

def parse_llm_json(raw: str, fallback: dict | None = None) -> dict:
    """
    Extract and parse a JSON object from a raw LLM response string.

    Args:
        raw:      Raw text returned by the LLM.
        fallback: Dict to return if all layers fail.
                  Defaults to {"_parse_error": True, "raw": raw[:300]}.

    Returns:
        Parsed dict. Never raises.
    """
    if not raw or not raw.strip():
        logger.warning("[JSON] Empty LLM response received")
        return fallback or {"_parse_error": True, "raw": ""}

    # Layer 1 – direct parse (works when model outputs clean JSON)
    result = _wrap(_try_parse(raw))
    if result is not None:
        return result

    # Layer 2 – strip fences then parse
    stripped = _repair(raw)
    result = _wrap(_try_parse(stripped))
    if result is not None:
        return result

    # Layer 3 – extract LAST {...} block
    #   Handles: "Sure! Here's the JSON: {...} Let me know if you need changes."
    brace_blocks = re.findall(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", stripped, re.DOTALL)
    if brace_blocks:
        result = _wrap(_try_parse(brace_blocks[-1]))
        if result is not None:
            return result

    # Layer 4 – greedy span from first { to last }
    #   Handles deeply nested JSON that layer 3's regex can't fully capture
    first_b = stripped.find("{")
    last_b  = stripped.rfind("}")
    if first_b != -1 and last_b > first_b:
        candidate = stripped[first_b: last_b + 1]
        result = _wrap(_try_parse(candidate))
        if result is not None:
            return result

    # Layer 5 – try array [...]
    first_br = stripped.find("[")
    last_br  = stripped.rfind("]")
    if first_br != -1 and last_br > first_br:
        candidate = stripped[first_br: last_br + 1]
        result = _wrap(_try_parse(candidate))
        if result is not None:
            return result

    logger.error("[JSON] All 5 parse layers failed. raw[:400]=%s", raw[:400])
    return fallback or {"_parse_error": True, "raw": raw[:300]}


# ── type coercion helpers ─────────────────────────────────────────────────────

def safe_float(value, default: float = 0.0) -> float:
    """Coerce any value to float safely."""
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        # Handle strings like "₹1,23,456" or "1.2 lakh"
        cleaned = re.sub(r"[^\d.]", "", str(value))
        try:
            return float(cleaned) if cleaned else default
        except ValueError:
            return default


def safe_bool(value, default: bool = False) -> bool:
    """Coerce any value to bool; handles string 'true'/'false'/'yes'/'no'."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("true", "1", "yes", "y")
    try:
        return bool(value)
    except Exception:
        return default


def safe_list(value, default: list | None = None) -> list:
    """Coerce any value to list safely."""
    if isinstance(value, list):
        return value
    if value is None:
        return default if default is not None else []
    if isinstance(value, str) and value.strip():
        # Try parsing as JSON array
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass
    return [value] if value else (default or [])


def safe_str(value, default: str = "") -> str:
    """Coerce any value to string safely."""
    if value is None:
        return default
    return str(value).strip() or default
