"""
tools/ssl_fix.py
----------------
SSL certificate problem detector and auto-fixer for Vertex AI Workbench.

Root causes handled:
  1. Corporate / enterprise MITM proxy (Zscaler, Netskope, Palo Alto, etc.)
     → intercepts HTTPS, re-signs with their own CA not in the certifi bundle
  2. Stale certifi bundle inside the venv
  3. Custom CA cert path set in environment but not picked up by google-cloud-storage
  4. REQUESTS_CA_BUNDLE / SSL_CERT_FILE not set

Fix strategy (applied in order, stops at first success):
  1. Check system CA store (/etc/ssl/certs/ca-certificates.crt on Debian/Ubuntu)
     and tell requests + google-auth to use it via env vars.
  2. Merge certifi bundle with system CA bundle → write to /tmp/merged_ca.pem
     and point both REQUESTS_CA_BUNDLE and SSL_CERT_FILE at it.
  3. If a custom corporate cert path is provided, append it to the merged bundle.

Usage (call ONCE at startup, before any google-cloud calls):
    from tools.ssl_fix import apply_ssl_fix
    apply_ssl_fix()                          # auto-detect
    apply_ssl_fix(extra_cert_path="/path/to/corp.pem")  # with corporate cert
"""

from __future__ import annotations

import logging
import os
import ssl
import socket
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# ── well-known system CA bundle locations (Debian/Ubuntu/RHEL/Alpine) ─────────
_SYSTEM_CA_CANDIDATES = [
    "/etc/ssl/certs/ca-certificates.crt",       # Debian / Ubuntu (Workbench default)
    "/etc/pki/tls/certs/ca-bundle.crt",         # RHEL / CentOS
    "/etc/ssl/ca-bundle.pem",                   # openSUSE
    "/etc/ssl/cert.pem",                        # Alpine / macOS
    "/usr/local/share/ca-certificates",         # custom added certs dir
]

_MERGED_CA_PATH = "/tmp/merged_gcs_ca.pem"


# ── helpers ───────────────────────────────────────────────────────────────────

def _find_system_ca() -> str | None:
    """Return the first existing system CA bundle path, or None."""
    for path in _SYSTEM_CA_CANDIDATES:
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            return path
    return None


def _certifi_bundle() -> str | None:
    """Return the certifi CA bundle path, or None if certifi not installed."""
    try:
        import certifi
        return certifi.where()
    except ImportError:
        return None


def _read_pem(path: str) -> str:
    """Read a PEM file safely, returning empty string on error."""
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        logger.warning("[SSL] Could not read %s: %s", path, exc)
        return ""


def _build_merged_bundle(extra_cert_path: str | None = None) -> str:
    """
    Merge certifi + system CA + optional extra cert into a single PEM file.
    Returns the path to the merged bundle.
    """
    parts: list[str] = []

    certifi_path = _certifi_bundle()
    if certifi_path:
        parts.append(_read_pem(certifi_path))
        logger.info("[SSL] Added certifi bundle: %s", certifi_path)

    system_ca = _find_system_ca()
    if system_ca:
        parts.append(_read_pem(system_ca))
        logger.info("[SSL] Added system CA: %s", system_ca)

    if extra_cert_path and os.path.isfile(extra_cert_path):
        parts.append(_read_pem(extra_cert_path))
        logger.info("[SSL] Added extra corporate cert: %s", extra_cert_path)

    merged = "\n".join(p.strip() for p in parts if p.strip())
    Path(_MERGED_CA_PATH).write_text(merged, encoding="utf-8")
    logger.info("[SSL] Merged CA bundle written → %s (%d bytes)",
                _MERGED_CA_PATH, len(merged))
    return _MERGED_CA_PATH


def _set_env_vars(ca_path: str) -> None:
    """
    Point all relevant SSL environment variables at *ca_path*.
    This covers: requests, urllib3, google-auth, google-cloud-storage, httplib2.
    """
    os.environ["REQUESTS_CA_BUNDLE"] = ca_path
    os.environ["SSL_CERT_FILE"]      = ca_path
    os.environ["CURL_CA_BUNDLE"]     = ca_path
    # google-auth respects REQUESTS_CA_BUNDLE via google.auth.transport.requests
    logger.info("[SSL] Environment variables set → %s", ca_path)


def _test_connectivity(host: str = "storage.googleapis.com", port: int = 443,
                       timeout: float = 5.0) -> bool:
    """Quick TCP+SSL handshake test to GCS endpoint."""
    try:
        ctx = ssl.create_default_context()
        ca = os.environ.get("REQUESTS_CA_BUNDLE") or os.environ.get("SSL_CERT_FILE")
        if ca and os.path.isfile(ca):
            ctx.load_verify_locations(ca)
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host):
                return True
    except Exception as exc:
        logger.debug("[SSL] Connectivity test failed: %s", exc)
        return False


# ── public API ────────────────────────────────────────────────────────────────

def apply_ssl_fix(extra_cert_path: str | None = None) -> bool:
    """
    Detect and fix SSL certificate issues for google-cloud-storage in Workbench.

    Steps:
      1. Test connectivity with the current SSL config.
      2. If already working → do nothing, return True.
      3. Build a merged CA bundle (certifi + system + optional extra).
      4. Set REQUESTS_CA_BUNDLE, SSL_CERT_FILE, CURL_CA_BUNDLE.
      5. Re-test connectivity.

    Args:
        extra_cert_path: Optional path to a corporate/enterprise PEM certificate
                         to append to the merged bundle (for MITM proxies like
                         Zscaler, Netskope, Palo Alto, etc.)

    Returns:
        True if connectivity to storage.googleapis.com is working after fix.
        False if the problem persists (manual intervention needed).
    """
    logger.info("[SSL] Checking SSL connectivity to storage.googleapis.com …")

    # Step 1 – already working?
    if _test_connectivity():
        logger.info("[SSL] SSL is already working correctly. No fix needed.")
        return True

    logger.warning("[SSL] SSL check failed — applying fix …")

    # Step 2 – honour existing env var if already set
    existing = os.environ.get("REQUESTS_CA_BUNDLE") or os.environ.get("SSL_CERT_FILE")
    if existing and os.path.isfile(existing):
        logger.info("[SSL] Existing CA bundle found at %s — retesting …", existing)
        _set_env_vars(existing)
        if _test_connectivity():
            logger.info("[SSL] Existing bundle works.")
            return True

    # Step 3 – build merged bundle
    merged = _build_merged_bundle(extra_cert_path)
    _set_env_vars(merged)

    # Step 4 – re-test
    if _test_connectivity():
        logger.info("[SSL] ✅ Fix applied successfully using merged CA bundle.")
        return True

    # Step 5 – give up, log actionable instructions
    logger.error(
        "[SSL] ❌ SSL fix failed. Manual steps:\n"
        "  1. Find your corporate CA cert:  openssl s_client -connect storage.googleapis.com:443 2>&1 | openssl x509 -text\n"
        "  2. Export it: openssl s_client -connect storage.googleapis.com:443 </dev/null 2>/dev/null | openssl x509 > /tmp/corp_ca.pem\n"
        "  3. Re-run:    apply_ssl_fix(extra_cert_path='/tmp/corp_ca.pem')\n"
        "  4. Or set:    gcloud config set core/custom_ca_certs_file /tmp/corp_ca.pem"
    )
    return False


def diagnose() -> dict:
    """
    Run a full SSL environment diagnosis and return a report dict.
    Useful for debugging — call this and print the result.
    """
    return {
        "python_version":       sys.version,
        "ssl_version":          ssl.OPENSSL_VERSION,
        "certifi_path":         _certifi_bundle(),
        "system_ca_path":       _find_system_ca(),
        "REQUESTS_CA_BUNDLE":   os.environ.get("REQUESTS_CA_BUNDLE"),
        "SSL_CERT_FILE":        os.environ.get("SSL_CERT_FILE"),
        "CURL_CA_BUNDLE":       os.environ.get("CURL_CA_BUNDLE"),
        "HTTPS_PROXY":          os.environ.get("HTTPS_PROXY"),
        "https_proxy":          os.environ.get("https_proxy"),
        "connectivity_ok":      _test_connectivity(),
    }
