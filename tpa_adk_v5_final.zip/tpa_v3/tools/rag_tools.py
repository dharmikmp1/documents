"""
tools/rag_tools.py
------------------
Vertex AI RAG Engine retrieval — stable vertexai.rag API (not preview).

Correct call (from official docs):
    rag.retrieval_query(
        rag_resources=[rag.RagResource(rag_corpus=corpus_name)],
        text="query",
        rag_retrieval_config=rag.RagRetrievalConfig(
            top_k=10,
            filter=rag.utils.resources.Filter(vector_distance_threshold=0.5),
        ),
    )

Response access:
    response.contexts.contexts  →  list[RagContext]
    ctx.text        (str)
    ctx.source_uri  (str)
    ctx.score       (float)

SSL fix is applied before the vertexai.init call.
"""

from __future__ import annotations
import logging

import vertexai
from vertexai import rag

from tools.ssl_fix import apply_ssl_fix

logger = logging.getLogger(__name__)

_INIT_KEYS: set[str] = set()   # (project, location) pairs already initialised


def _ensure_init(project_id: str, location: str) -> None:
    """Initialise Vertex AI SDK once per (project, location) pair."""
    key = f"{project_id}:{location}"
    if key not in _INIT_KEYS:
        apply_ssl_fix()          # ensure SSL is correct before SDK calls
        vertexai.init(project=project_id, location=location)
        _INIT_KEYS.add(key)


def query_rag_corpus(
    query_text: str,
    rag_corpus_resource: str,
    project_id: str,
    location: str = "us-central1",
    top_k: int = 5,
    vector_distance_threshold: float = 0.5,
) -> dict:
    """
    Retrieve relevant text chunks from a Vertex AI RAG Corpus.

    Uses the stable vertexai.rag API (not vertexai.preview.rag).

    Args:
        query_text: Natural-language search string, e.g. 'appendectomy GIPSA rate'.
        rag_corpus_resource: Full resource name of the RAG corpus.
            Format: projects/<PROJECT>/locations/<LOC>/ragCorpora/<ID>
        project_id: GCP project ID.
        location: Region where the corpus lives, e.g. 'us-central1'.
            Must match the region in rag_corpus_resource.
        top_k: Number of top chunks to retrieve (1–50).
        vector_distance_threshold: Similarity cutoff — lower = stricter.
            0.3 is strict, 0.5 is balanced, 0.8 is permissive.

    Returns:
        dict with:
          - context     (str):       Concatenated text of all retrieved chunks.
          - chunk_count (int):       Number of non-empty chunks returned.
          - sources     (list[str]): Source URIs for each chunk.
          - error       (str|None):  Error message if retrieval failed.
    """
    if not rag_corpus_resource or not rag_corpus_resource.strip():
        return {
            "context":     "",
            "chunk_count": 0,
            "sources":     [],
            "error":       "rag_corpus_resource is empty — skipping RAG retrieval",
        }

    if not query_text or not query_text.strip():
        return {
            "context":     "",
            "chunk_count": 0,
            "sources":     [],
            "error":       "query_text is empty",
        }

    try:
        _ensure_init(project_id, location)

        response = rag.retrieval_query(
            rag_resources=[
                rag.RagResource(rag_corpus=rag_corpus_resource)
            ],
            text=query_text.strip(),
            rag_retrieval_config=rag.RagRetrievalConfig(
                top_k=max(1, min(int(top_k), 50)),
                filter=rag.utils.resources.Filter(
                    vector_distance_threshold=float(vector_distance_threshold)
                ),
            ),
        )

        # ── safe response parsing ─────────────────────────────────────────────
        # response.contexts is a RagContexts proto
        # response.contexts.contexts is repeated RagContext
        contexts_wrapper = getattr(response, "contexts", None)
        if contexts_wrapper is None:
            logger.warning("[RAG] Response has no .contexts attribute")
            return {"context": "", "chunk_count": 0, "sources": [], "error": None}

        raw_contexts = getattr(contexts_wrapper, "contexts", [])

        chunks: list[str] = []
        sources: list[str] = []

        for i, ctx in enumerate(raw_contexts):
            text   = (getattr(ctx, "text",       None) or "").strip()
            source = (getattr(ctx, "source_uri", None) or f"chunk-{i+1}").strip()
            score  = getattr(ctx, "score", None)

            if not text:
                continue   # skip empty chunks

            score_str = f"  score={score:.3f}" if score is not None else ""
            chunks.append(f"[Source: {source}{score_str}]\n{text}")
            sources.append(source)

        combined = "\n\n---\n\n".join(chunks)
        logger.info("[RAG] query=%r → %d chunk(s) from %s",
                    query_text[:60], len(chunks), rag_corpus_resource)

        return {
            "context":     combined,
            "chunk_count": len(chunks),
            "sources":     sources,
            "error":       None,
        }

    except Exception as exc:
        err_msg = str(exc)
        logger.error("[RAG] retrieval_query failed: %s", err_msg)

        # Provide actionable hints for common errors
        if "NOT_FOUND" in err_msg or "404" in err_msg:
            hint = (f"RAG corpus not found. Verify rag_corpus_resource: "
                    f"{rag_corpus_resource!r}. "
                    f"Check location matches corpus region.")
            logger.error("[RAG] Hint: %s", hint)
        elif "PERMISSION_DENIED" in err_msg or "403" in err_msg:
            hint = ("Service account lacks 'Vertex AI User' or 'RAG Engine User' role.")
            logger.error("[RAG] Hint: %s", hint)
        elif "ssl" in err_msg.lower() or "certificate" in err_msg.lower():
            logger.error("[RAG] SSL error on RAG call — run apply_ssl_fix() manually.")

        return {
            "context":     "",
            "chunk_count": 0,
            "sources":     [],
            "error":       err_msg,
        }
