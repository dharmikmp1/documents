"""
tools/gcs_tools.py
------------------
GCS read / write tools with:
  - Automatic SSL fix applied before every client construction
  - Exponential-backoff retry on transient errors (503, ConnectionError, SSLError)
  - Streaming download to avoid memory exhaustion on large PDFs
  - Safe JSON serialisation for the upload path
  - Meaningful error messages that distinguish SSL vs auth vs permission issues

All functions are plain Python callables usable as Google ADK tools.
"""

from __future__ import annotations

import io
import json
import logging
import time
from typing import Any

from google.cloud import storage
from google.cloud.exceptions import GoogleCloudError
from google.api_core import retry as api_retry

# Apply SSL fix before the first GCS client is ever created
from tools.ssl_fix import apply_ssl_fix

logger = logging.getLogger(__name__)

# ── module-level SSL init (idempotent) ────────────────────────────────────────
_SSL_FIXED = False

def _ensure_ssl() -> None:
    global _SSL_FIXED
    if not _SSL_FIXED:
        _SSL_FIXED = apply_ssl_fix()


# ── retry policy ──────────────────────────────────────────────────────────────
# Retries on transient HTTP 429, 500, 502, 503, 504 and connection errors.
_GCS_RETRY = api_retry.Retry(
    predicate=api_retry.if_transient_error,
    initial=1.0,
    maximum=32.0,
    multiplier=2.0,
    deadline=120.0,
)


# ── internal helpers ──────────────────────────────────────────────────────────

def _parse_uri(uri: str) -> tuple[str, str]:
    """
    Split  gs://bucket/some/prefix/  →  ('bucket', 'some/prefix/')
    Raises ValueError for non-gs:// URIs.
    """
    if not uri.startswith("gs://"):
        raise ValueError(f"URI must start with gs://, got: {uri!r}")
    without_scheme = uri[5:]
    parts = without_scheme.split("/", 1)
    bucket_name = parts[0]
    blob_name   = parts[1] if len(parts) > 1 else ""
    return bucket_name, blob_name


def _make_client() -> storage.Client:
    """
    Build an authenticated GCS client.
    SSL fix is always applied first so the client inherits the correct CA bundle
    through the REQUESTS_CA_BUNDLE environment variable picked up by google-auth.
    """
    _ensure_ssl()
    return storage.Client()


def _classify_error(exc: Exception) -> str:
    """Return a human-readable error category for better log messages."""
    msg = str(exc).lower()
    if "ssl" in msg or "certificate" in msg:
        return "SSL_ERROR"
    if "403" in msg or "permission" in msg or "access denied" in msg:
        return "PERMISSION_ERROR"
    if "404" in msg or "not found" in msg:
        return "NOT_FOUND"
    if "401" in msg or "unauthorized" in msg or "credentials" in msg:
        return "AUTH_ERROR"
    if "timeout" in msg or "timed out" in msg:
        return "TIMEOUT"
    return "UNKNOWN_ERROR"


# ── public tool functions ─────────────────────────────────────────────────────

def list_pdfs_in_folder(gcs_folder_uri: str) -> dict:
    """
    List all PDF files inside a GCS folder.

    Handles SSL errors by applying the ssl_fix and retrying once automatically.

    Args:
        gcs_folder_uri: GCS folder URI, e.g. 'gs://bucket/claims/CLAIM-001/'

    Returns:
        dict with keys:
          - pdf_uris  (list[str]): sorted list of gs:// URIs for every PDF found
          - count     (int):       number of PDFs found
          - error     (str|None):  error message if the operation failed
    """
    for attempt in range(2):   # attempt 0 = normal; attempt 1 = after SSL re-fix
        try:
            client = _make_client()
            bucket_name, prefix = _parse_uri(gcs_folder_uri)
            bucket = client.bucket(bucket_name)

            blobs = bucket.list_blobs(prefix=prefix, retry=_GCS_RETRY)
            uris = sorted(
                f"gs://{bucket_name}/{b.name}"
                for b in blobs
                if b.name.lower().endswith(".pdf")
            )
            logger.info("[GCS] %d PDF(s) in %s", len(uris), gcs_folder_uri)
            return {"pdf_uris": uris, "count": len(uris), "error": None}

        except Exception as exc:
            category = _classify_error(exc)
            logger.error("[GCS] list_pdfs attempt %d failed [%s]: %s",
                         attempt + 1, category, exc)

            if category == "SSL_ERROR" and attempt == 0:
                # Force SSL re-diagnosis with extra cert extraction
                logger.warning("[GCS] SSL error detected — forcing re-fix …")
                global _SSL_FIXED
                _SSL_FIXED = False
                _ensure_ssl()
                continue   # retry once

            return {
                "pdf_uris": [],
                "count": 0,
                "error": f"[{category}] {exc}",
            }

    return {"pdf_uris": [], "count": 0, "error": "list_pdfs failed after SSL retry"}


def download_pdf_bytes(gcs_uri: str) -> dict:
    """
    Download a single PDF from GCS and return its raw bytes as a hex string.

    Uses chunked streaming download to handle large files without memory issues.

    Args:
        gcs_uri: Full GCS URI of the PDF, e.g. 'gs://bucket/path/file.pdf'

    Returns:
        dict with keys:
          - hex_bytes  (str):      hex-encoded PDF bytes
          - size_bytes (int):      file size in bytes
          - error      (str|None): error message if the operation failed
    """
    for attempt in range(2):
        try:
            client = _make_client()
            bucket_name, blob_name = _parse_uri(gcs_uri)

            blob = client.bucket(bucket_name).blob(blob_name)

            # Streaming download into BytesIO
            buf = io.BytesIO()
            blob.download_to_file(buf, retry=_GCS_RETRY)
            raw = buf.getvalue()

            logger.info("[GCS] Downloaded %s (%d bytes)", gcs_uri, len(raw))
            return {
                "hex_bytes":  raw.hex(),
                "size_bytes": len(raw),
                "error":      None,
            }

        except Exception as exc:
            category = _classify_error(exc)
            logger.error("[GCS] download attempt %d failed [%s]: %s",
                         attempt + 1, category, exc)

            if category == "SSL_ERROR" and attempt == 0:
                global _SSL_FIXED
                _SSL_FIXED = False
                _ensure_ssl()
                continue

            return {
                "hex_bytes":  "",
                "size_bytes": 0,
                "error":      f"[{category}] {exc}",
            }

    return {"hex_bytes": "", "size_bytes": 0, "error": "download failed after SSL retry"}


def upload_report_to_gcs(report_json: str, output_gcs_uri: str) -> dict:
    """
    Upload a JSON report string to GCS.

    Validates JSON before uploading so corrupt payloads are caught early.

    Args:
        report_json:    JSON string of the final report.
        output_gcs_uri: Destination URI, e.g. 'gs://bucket/output/CLAIM-001/report.json'

    Returns:
        dict with keys:
          - success (bool)
          - uri     (str):      the URI written to
          - error   (str|None)
    """
    # Validate JSON before even opening a GCS connection
    try:
        parsed = json.loads(report_json)
        # Re-serialise with indent for readability
        report_json = json.dumps(parsed, indent=2, ensure_ascii=False)
    except (json.JSONDecodeError, TypeError) as exc:
        logger.error("[GCS] upload_report: invalid JSON — %s", exc)
        return {
            "success": False,
            "uri":     output_gcs_uri,
            "error":   f"Invalid JSON payload: {exc}",
        }

    for attempt in range(2):
        try:
            client = _make_client()
            bucket_name, blob_name = _parse_uri(output_gcs_uri)

            blob = client.bucket(bucket_name).blob(blob_name)
            blob.upload_from_string(
                report_json.encode("utf-8"),
                content_type="application/json",
                retry=_GCS_RETRY,
            )
            logger.info("[GCS] Report uploaded → %s", output_gcs_uri)
            return {"success": True, "uri": output_gcs_uri, "error": None}

        except Exception as exc:
            category = _classify_error(exc)
            logger.error("[GCS] upload attempt %d failed [%s]: %s",
                         attempt + 1, category, exc)

            if category == "SSL_ERROR" and attempt == 0:
                global _SSL_FIXED
                _SSL_FIXED = False
                _ensure_ssl()
                continue

            return {
                "success": False,
                "uri":     output_gcs_uri,
                "error":   f"[{category}] {exc}",
            }

    return {"success": False, "uri": output_gcs_uri,
            "error": "upload failed after SSL retry"}
