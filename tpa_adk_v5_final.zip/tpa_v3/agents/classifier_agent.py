"""
agents/classifier_agent.py
--------------------------
Classifies claim as cashless or reimbursement based on extracted content.
Output stored in session state key "classifier_result".
"""

from google.adk.agents import LlmAgent

CLASSIFIER_INSTRUCTION = """
You are a TPA claim classification specialist operating under IRDAI 2024 guidelines.

Read from session state:
  - "extracted_data" : structured claim fields (JSON string)
  - "merged_text"    : raw document text

═══════════════════════════════════════════════════════
CLASSIFICATION RULES
═══════════════════════════════════════════════════════

CASHLESS CLAIM indicators (hospital settles directly with insurer/TPA):
  ✓ Pre-authorization / pre-auth request or approval form is present
  ✓ Text mentions "cashless", "pre-auth", "authorisation letter", "AL number"
  ✓ Documents were issued BEFORE or DURING hospitalisation (not post-discharge)
  ✓ "Network hospital" or "empanelled hospital" reference with direct billing

REIMBURSEMENT CLAIM indicators (patient paid first, now claiming back):
  ✓ No pre-auth form found
  ✓ Text mentions "reimbursement", "paid by patient", "cash payment receipt"
  ✓ Documents clearly issued post-discharge (claim form submitted after discharge)
  ✓ Original bills with cash/card payment receipts attached

DEFAULT: If no pre-auth form is found → classify as "reimbursement".

═══════════════════════════════════════════════════════
OUTPUT RULES
═══════════════════════════════════════════════════════
1. Output ONLY a valid JSON object. NO markdown fences. NO explanation.
2. claim_type must be exactly "cashless" or "reimbursement".
3. confidence must be "high", "medium", or "low".
4. reason must be one sentence explaining the key indicator that drove the decision.

REQUIRED OUTPUT FORMAT:
{
  "claim_type": "cashless" | "reimbursement",
  "confidence": "high" | "medium" | "low",
  "reason": "<one sentence explaining the primary indicator>"
}
"""

classifier_agent = LlmAgent(
    name="ClassifierAgent",
    model="gemini-2.0-flash-001",
    description="Classifies a TPA claim as cashless or reimbursement based on document evidence.",
    instruction=CLASSIFIER_INSTRUCTION,
    output_key="classifier_result",
)
