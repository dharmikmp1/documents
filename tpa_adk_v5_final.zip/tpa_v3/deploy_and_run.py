"""
deploy_and_run.py
-----------------
All-in-one script for:
  A) SSL diagnosis and fix (run FIRST if you hit SSL errors)
  B) Local testing in Vertex AI Workbench / Jupyter
  C) Deploying to Vertex AI Agent Engine
  D) Querying a deployed Agent Engine instance
  E) Finding your RAG corpus resource name
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 0 – Install (run once in Workbench terminal)                       ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
# pip install -r requirements.txt


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 1 – Your configuration                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

CONFIG = {
    "project_id":          "YOUR_PROJECT_ID",
    "location":            "us-central1",
    "staging_bucket":      "gs://YOUR_STAGING_BUCKET",
    "gcs_claim_folder":    "gs://YOUR_BUCKET/claims/CLAIM-001/",
    # Full resource name — run Section E below to find yours
    "rag_corpus_resource": "projects/YOUR_PROJECT/locations/us-central1/ragCorpora/YOUR_ID",
    "rag_location":        "us-central1",
    # Optional: path to your corporate CA cert (for Zscaler / Netskope / MITM proxies)
    "corporate_cert_path": None,   # e.g. "/tmp/corp_ca.pem"
}


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION A – SSL Diagnosis and Fix  ← RUN THIS FIRST if SSL errors occur   ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

def ssl_diagnose():
    """
    Print a full SSL environment report.
    Call this when you see CERTIFICATE_VERIFY_FAILED or SSL handshake errors.
    """
    import json
    from tools.ssl_fix import diagnose
    report = diagnose()
    print("\n=== SSL Diagnosis Report ===")
    for k, v in report.items():
        print(f"  {k:28s}: {v}")
    print()
    if not report["connectivity_ok"]:
        print("❌ SSL connectivity FAILED — run ssl_fix() below")
    else:
        print("✅ SSL connectivity OK")
    return report

def ssl_fix(corporate_cert_path=None):
    """
    Apply SSL fix. Pass corporate_cert_path if behind a MITM proxy.

    If you are behind Zscaler / Netskope / Palo Alto:
      1. First extract the proxy cert:
         $ openssl s_client -connect storage.googleapis.com:443 </dev/null 2>/dev/null \\
             | openssl x509 > /tmp/corp_ca.pem
      2. Then call:
         ssl_fix(corporate_cert_path='/tmp/corp_ca.pem')
    """
    from tools.ssl_fix import apply_ssl_fix
    ok = apply_ssl_fix(extra_cert_path=corporate_cert_path or CONFIG.get("corporate_cert_path"))
    if ok:
        print("✅ SSL fix applied successfully")
    else:
        print("❌ SSL fix failed — see log above for manual steps")
    return ok

# Run in Jupyter:
#   ssl_diagnose()
#   ssl_fix()                            # auto-detect
#   ssl_fix('/tmp/your_corp_cert.pem')   # with corporate cert


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION B – Local test (Vertex AI Workbench / Jupyter)                     ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

async def run_local_test():
    """
    Run the full pipeline locally.
    In Jupyter:  result = await run_local_test()
    In script:   import asyncio; result = asyncio.run(run_local_test())
    """
    import json
    from agent import run_local

    result = await run_local(
        gcs_folder_uri      = CONFIG["gcs_claim_folder"],
        project_id          = CONFIG["project_id"],
        rag_corpus_resource = CONFIG["rag_corpus_resource"],
        rag_location        = CONFIG["rag_location"],
    )
    print("\n" + "="*60)
    print("FINAL REPORT")
    print("="*60)
    print(json.dumps(result, indent=2))
    return result

# In Jupyter:
#   result = await run_local_test()


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION C – Deploy to Agent Engine                                          ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

def deploy():
    """Deploy to Vertex AI Agent Engine. Returns the remote agent object."""
    from agent import deploy_to_agent_engine
    remote = deploy_to_agent_engine(
        project_id     = CONFIG["project_id"],
        location       = CONFIG["location"],
        staging_bucket = CONFIG["staging_bucket"],
    )
    resource_id = remote.resource_name.split("/")[-1]
    print(f"\n✅ Deployed! Resource ID: {resource_id}")
    print(f"   Full name: {remote.resource_name}")
    print(f"\nSet AGENT_ENGINE_RESOURCE_ID = '{resource_id}' in Section D.")
    return remote

# Uncomment to run:
#   remote_agent = deploy()


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION D – Query deployed Agent Engine                                     ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

AGENT_ENGINE_RESOURCE_ID = "YOUR_RESOURCE_ID"   # from Section C output

async def query_deployed():
    """Query the deployed Agent Engine. In Jupyter: await query_deployed()"""
    import json, vertexai

    vertexai.init(project=CONFIG["project_id"], location=CONFIG["location"])
    client = vertexai.Client(project=CONFIG["project_id"], location=CONFIG["location"])

    resource_name = (
        f"projects/{CONFIG['project_id']}/locations/{CONFIG['location']}"
        f"/reasoningEngines/{AGENT_ENGINE_RESOURCE_ID}"
    )
    remote_agent = client.agent_engines.get(name=resource_name)

    payload = json.dumps({
        "gcs_folder_uri":      CONFIG["gcs_claim_folder"],
        "project_id":          CONFIG["project_id"],
        "rag_corpus_resource": CONFIG["rag_corpus_resource"],
        "rag_location":        CONFIG["rag_location"],
    })

    print(f"Querying: {resource_name}\n")
    async for event in remote_agent.async_stream_query(user_id="tpa-user", message=payload):
        author = event.get("author", "")
        for part in event.get("content", {}).get("parts", []):
            if "text" in part and part["text"].strip():
                print(f"[{author}] {part['text'][:400]}")

# In Jupyter:
#   await query_deployed()


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  SECTION E – Find your RAG corpus resource name                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

def list_rag_corpora():
    """Print all RAG corpus names in your project/location."""
    import vertexai
    from vertexai import rag
    vertexai.init(project=CONFIG["project_id"], location=CONFIG["location"])
    corpora = list(rag.list_corpora())
    if not corpora:
        print("No RAG corpora found in this project/location.")
        return
    print(f"\nRAG Corpora in {CONFIG['project_id']} / {CONFIG['location']}:\n")
    for c in corpora:
        print(f"  resource_name : {c.name}")
        print(f"  display_name  : {c.display_name}")
        print(f"  created       : {getattr(c, 'create_time', 'N/A')}")
        print()

# Uncomment to run:
#   list_rag_corpora()
